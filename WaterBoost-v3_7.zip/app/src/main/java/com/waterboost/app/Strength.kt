package com.waterboost.app

/**
 * How hard a clean pushes. Plain data and arithmetic with no Android classes, so it can be tested on any computer
 * (tools/LogicTest.kt).
 *
 * What "stronger" really means: close more apps in one go (and smaller ones too), and close the same apps again a few seconds
 * later. A sticky service comes back about a second after it is killed, but every further restart within a minute waits four
 * times as long (1 s, 4 s, 16 s, 64 s), so each extra pass keeps the memory free for longer. At every level the launcher,
 * keyboard, SMS, dialer, the next-alarm app, Protected apps, system apps and Google services are left alone, and the strength
 * never force-stops anything. (No setting can raise CPU or GPU speed: Android does not allow that without root.)
 */
enum class Strength(
    val label: String,
    /** Shizuku: apps using less than this many MB are left alone. */
    val minHeavyMb: Long,
    /** Shizuku: most apps closed in one go. */
    val batch: Int,
    /** Auto clean frees this percent of what is missing below its limit (100 = just enough, more = more headroom). */
    val overkillPct: Int,
    /** Extra kill passes, in ms after the first pass. (A first retry after about a second always runs, at every level.) */
    val latePassesMs: LongArray,
    /** Shizuku: also clear every cached background process of the phone (`am kill-all`) when you tap Clean now. */
    val clearCachedManual: Boolean,
    /** Shizuku: ... and when auto clean runs. */
    val clearCachedAuto: Boolean
) {
    // GENTLE is exactly how 3.6 cleaned (40 MB floor, 12 apps, 150 %), so going back changes nothing else.
    GENTLE("Gentle", 40L, 12, 150, longArrayOf(), false, false),
    STRONG("Strong", 30L, 18, 220, longArrayOf(5_000L), true, false),
    MAX("Maximum", 20L, 26, 400, longArrayOf(5_000L, 20_000L), true, true);

    /** Gentle -> Strong -> Maximum -> Gentle ... */
    fun next(): Strength = values()[(ordinal + 1) % values().size]

    /** MB that auto clean should aim to free when [freeMb] is below [limitMb] (0 when it is not). */
    fun needMb(limitMb: Long, freeMb: Long): Long = (limitMb - freeMb).coerceAtLeast(0L) * overkillPct / 100

    /** What this level does, in words for the screen. [shizukuReady]: only changes the wording of the Shizuku part. */
    fun describe(shizukuReady: Boolean): String {
        val shz = if (shizukuReady) "" else " (needs Shizuku)"
        val body = when (this) {
            GENTLE -> "Closes background apps (the heaviest first when Shizuku is on), then once more a second later. " +
                "Lightest on the phone; this is how WaterBoost cleaned before 3.7."
            STRONG -> "Closes more apps, small ones too, and closes them again after 1 s and after 5 s, so apps that restart " +
                "themselves stay closed longer. Clean now also clears cached background processes$shz."
            MAX -> "Everything in Strong, plus another pass after 20 s, and auto clean also clears cached background " +
                "processes$shz. Apps you open next may start a little slower."
        }
        return body + " The launcher, keyboard, messages, dialer, alarm apps and Protected apps are never touched, " +
            "and strength never force-stops anything."
    }

    companion object {
        /** New installs and updates from 3.6 start here: stronger than 3.6, still never force-stops. */
        val DEFAULT = STRONG

        /** The saved number, or [DEFAULT] if it is missing or no longer valid. */
        fun fromOrdinal(i: Int): Strength = values().getOrElse(i) { DEFAULT }

        /**
         * The apps to close, from the memory each one uses ([mem]: package -> MB): the biggest first, each at least [minMb],
         * at most [batch] of them, and stopping as soon as [needMb] is covered (null = no target, take every heavy app).
         */
        fun pick(mem: Map<String, Long>, minMb: Long, batch: Int, needMb: Long?): List<String> {
            val out = ArrayList<String>()
            var sum = 0L
            for (e in mem.entries.filter { it.value >= minMb }.sortedByDescending { it.value }) {
                if (needMb != null && sum >= needMb) break
                if (out.size >= batch) break
                out.add(e.key)
                sum += e.value
            }
            return out
        }
    }
}
