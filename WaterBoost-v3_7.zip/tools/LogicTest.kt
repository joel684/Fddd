// Logic tests for game mode and the side panel, runnable on any computer (no phone, no Gradle):
//   kotlinc app/src/main/java/com/waterboost/app/SessionWatch.kt app/src/main/java/com/waterboost/app/GameHints.kt \
//           app/src/main/java/com/waterboost/app/PanelGeometry.kt app/src/main/java/com/waterboost/app/Strength.kt \\
//           tools/LogicTest.kt -d out
//   java -cp out:<kotlin-stdlib.jar> LogicTestKt
// Covers: Home press, game failing to start, detours to other apps, screen off, second game, which package names count as games,
// the side panel's handle position (also after a rotation), height limit and play-time text, and (3.7) the clean strengths:
// which apps a clean picks, how much auto clean aims to free, the extra kill passes, and the saved setting.
import com.waterboost.app.GameHints
import com.waterboost.app.PanelGeometry
import com.waterboost.app.SessionWatch
import com.waterboost.app.Strength

var failures = 0
fun check(name: String, ok: Boolean) { println((if (ok) "PASS " else "FAIL ") + name); if (!ok) failures++ }

const val OWN = "com.waterboost.app"
const val GAME = "com.dts.freefireth"
const val TICK = 3_000L

/** Runs ticks every 3 s from t0 until [until]; [state] says what the phone reports at time t. Returns the time it ended, or -1. */
fun run(w: SessionWatch, t0: Long, until: Long, state: (Long) -> Triple<Boolean, Boolean, String?>): Long {
    var t = t0 + TICK
    while (t <= until) {
        val (interactive, ui, front) = state(t)
        if (w.update(t, interactive, ui, front, GAME)) return t
        t += TICK
    }
    return -1
}

fun main() {
    val T0 = 1_000_000L

    // 1. Playing normally, no usage access: never ends by itself in an hour.
    run {
        val w = SessionWatch(OWN); w.begin(T0)
        check("1 plays for an hour, no usage access -> keeps going", run(w, T0, T0 + 3_600_000) { Triple(true, false, null) } == -1L)
    }
    // 2. Press Home (WaterBoost home visible) at +60 s: must end after >= 4 s and within ~10 s.
    run {
        val w = SessionWatch(OWN); w.begin(T0)
        val e = run(w, T0, T0 + 200_000) { t -> Triple(true, t >= T0 + 60_000, null) }
        check("2 Home press ends game mode in 4..10 s (took ${(e - (T0 + 60_000)) / 1000.0} s)", e != -1L && e - (T0 + 60_000) in 4_000..10_000)
    }
    // 3. The game fails to appear and Home stays visible: still never ends before the 8 s start guard.
    run {
        val w = SessionWatch(OWN); w.begin(T0)
        val e = run(w, T0, T0 + 60_000) { Triple(true, true, null) }
        check("3 start guard: not before 8 s, but ends by 12 s (ended at +${(e - T0) / 1000.0} s)", e - T0 > 8_000 && e - T0 <= 12_000)
    }
    // 4. Usage access: a 10 s detour to another app and back never ends it.
    run {
        val w = SessionWatch(OWN); w.begin(T0)
        val e = run(w, T0, T0 + 120_000) { t ->
            val away = t in (T0 + 40_000)..(T0 + 50_000)
            Triple(true, false, if (away) "com.whatsapp" else GAME)
        }
        check("4 short detour (10 s) to another app -> keeps going", e == -1L)
    }
    // 5. Usage access: leaves for another app for good -> ends after > 25 s.
    run {
        val w = SessionWatch(OWN); w.begin(T0)
        val e = run(w, T0, T0 + 300_000) { t -> Triple(true, false, if (t >= T0 + 40_000) "com.whatsapp" else GAME) }
        val took = e - (T0 + 40_000)
        check("5 stays in another app -> ends after 25..32 s (took ${took / 1000.0} s)", e != -1L && took in 25_000..32_000)
    }
    // 6. Usage access: a WaterBoost screen in front -> short grace (4 s), not 25 s.
    run {
        val w = SessionWatch(OWN); w.begin(T0)
        val e = run(w, T0, T0 + 300_000) { t -> Triple(true, false, if (t >= T0 + 40_000) OWN else GAME) }
        val took = e - (T0 + 40_000)
        check("6 WaterBoost screen in front -> ends in 4..10 s (took ${took / 1000.0} s)", e != -1L && took in 4_000..10_000)
    }
    // 7. Screen off for 2 min and back: keeps going. Off for 6 min: ends after > 5 min.
    run {
        val w = SessionWatch(OWN); w.begin(T0)
        val e = run(w, T0, T0 + 600_000) { t -> Triple(!(t in (T0 + 60_000)..(T0 + 180_000)), false, null) }
        check("7a screen off 2 min then back -> keeps going", e == -1L)
        val w2 = SessionWatch(OWN); w2.begin(T0)
        val e2 = run(w2, T0, T0 + 900_000) { t -> Triple(t < T0 + 60_000, false, null) }
        val took = e2 - (T0 + 60_000)
        check("7b screen off for good -> ends after 5..5.1 min (took ${took / 1000.0} s)", e2 != -1L && took in 300_000..306_000)
    }
    // 8. Screen off 4 min, on 10 s, off 4 min: the timer restarts, so no end.
    run {
        val w = SessionWatch(OWN); w.begin(T0)
        val e = run(w, T0, T0 + 600_000) { t ->
            val off = t in (T0 + 10_000)..(T0 + 250_000) || t in (T0 + 262_000)..(T0 + 500_000)
            Triple(!off, false, null)
        }
        check("8 off 4 min, on briefly, off 4 min -> timer restarted, keeps going", e == -1L)
    }
    // 9. Usage access reports the game but the screen is off: the away rule must not fire.
    run {
        val w = SessionWatch(OWN); w.begin(T0)
        val e = run(w, T0, T0 + 200_000) { t -> Triple(t < T0 + 20_000, false, "com.android.systemui") }
        check("9 screen off + stale front app -> only the 5 min rule applies", e == -1L)
    }
    // 10. Before begin() nothing ends.
    run {
        val w = SessionWatch(OWN)
        check("10 update before begin() never ends", !w.update(T0, true, true, OWN, GAME))
    }
    // 11. begin() again (second game) clears the old away/home timers.
    run {
        val w = SessionWatch(OWN); w.begin(T0)
        // 20 s away so far (not over yet), then the second game starts
        run(w, T0, T0 + 20_000) { Triple(true, false, "com.whatsapp") }
        w.begin(T0 + 21_000)
        val e = run(w, T0 + 21_000, T0 + 120_000) { Triple(true, false, GAME) }
        check("11 second game start resets the timers", e == -1L)
    }

    // ---- known games
    val yes = listOf("com.dts.freefireth", "com.dts.freefiremax", "com.pubg.imobile", "com.tencent.ig", "com.supercell.brawlstars",
        "com.activision.callofduty.shooter", "com.miHoYo.GenshinImpact", "com.mojang.minecraftpe", "com.roblox.client",
        "com.gameloft.android.ANMP.GloftA9HM", "com.mobile.legends", "com.HoYoverse.hkrpgoversea", "com.tencent.tmgp.pubgmhd",
        "com.innersloth.spacemafia", "com.garena.game.codm", "com.king.candycrushsaga", "com.ludo.king", "com.axlebolt.standoff2")
    val no = listOf("com.tencent.mm", "com.whatsapp", "com.google.android.youtube", "com.android.chrome", "com.instagram.android",
        "com.netease.cloudmusic", "com.kingsoft.office", "com.dtsx.audio", "com.king", "com.garenax.app", "com.google.android.apps.maps",
        "org.telegram.messenger", "com.spotify.music", "com.facebook.katana", "com.waterboost.app")
    check("12 known games recognised (${yes.count { GameHints.looksLikeGame(it) }}/${yes.size})", yes.all { GameHints.looksLikeGame(it) })
    check("13 normal apps NOT recognised (${no.count { !GameHints.looksLikeGame(it) }}/${no.size})", no.none { GameHints.looksLikeGame(it) })


    // ---- side panel geometry
    check("14 handle at top/bottom/middle", PanelGeometry.yFor(0f, 1080, 160) == 0 && PanelGeometry.yFor(1f, 1080, 160) == 920 && PanelGeometry.yFor(0.5f, 1080, 160) == 460)
    check("15 fraction out of range is clamped", PanelGeometry.yFor(-3f, 1080, 160) == 0 && PanelGeometry.yFor(9f, 1080, 160) == 920)
    check("16 view taller than screen sits at 0 (no negative y)", PanelGeometry.yFor(0.7f, 600, 900) == 0)
    check("17 drag result survives rotation (portrait 2408 -> landscape 1080)", run {
        val f = PanelGeometry.fracFor(1000, 2408, 168)          // dragged to y=1000 in portrait
        val y2 = PanelGeometry.yFor(f, 1080, 168)               // same place after rotating
        f in 0.44f..0.46f && y2 in 400..420
    })
    check("18 fracFor with no room is 0, and always within 0..1", PanelGeometry.fracFor(50, 100, 200) == 0f && PanelGeometry.fracFor(-50, 1000, 100) == 0f && PanelGeometry.fracFor(5000, 1000, 100) == 1f)
    check("19 panel height: content fits / is capped to screen minus margin / tiny screen", PanelGeometry.panelHeight(700, 1080, 40) == 700 && PanelGeometry.panelHeight(1500, 1080, 40) == 1040 && PanelGeometry.panelHeight(500, 30, 40) == 0)
    check("20 play time text", PanelGeometry.playTime(0) == "0:00" && PanelGeometry.playTime(61_000) == "1:01" && PanelGeometry.playTime(754_000) == "12:34" && PanelGeometry.playTime(3_723_000) == "1:02:03" && PanelGeometry.playTime(-5) == "0:00")


    // ---- clean strength (3.7)
    check("21 Gentle is exactly how 3.6 cleaned; Strong and Maximum only add",
        Strength.GENTLE.minHeavyMb == 40L && Strength.GENTLE.batch == 12 && Strength.GENTLE.overkillPct == 150 &&
            Strength.GENTLE.latePassesMs.isEmpty() && !Strength.GENTLE.clearCachedManual && !Strength.GENTLE.clearCachedAuto &&
            Strength.STRONG.minHeavyMb < Strength.GENTLE.minHeavyMb && Strength.MAX.minHeavyMb < Strength.STRONG.minHeavyMb &&
            Strength.STRONG.batch > Strength.GENTLE.batch && Strength.MAX.batch > Strength.STRONG.batch &&
            Strength.STRONG.overkillPct > Strength.GENTLE.overkillPct && Strength.MAX.overkillPct > Strength.STRONG.overkillPct)

    val mem = mapOf("big" to 300L, "mid" to 120L, "small" to 45L, "tiny" to 28L, "dust" to 12L)
    check("22a pick: biggest first, floor and batch respected",
        Strength.pick(mem, 40, 12, null) == listOf("big", "mid", "small") &&
            Strength.pick(mem, 30, 18, null) == listOf("big", "mid", "small") &&
            Strength.pick(mem, 20, 26, null) == listOf("big", "mid", "small", "tiny") &&
            Strength.pick(mem, 20, 2, null) == listOf("big", "mid"))
    check("22b pick: stops once the target is covered; a target of 0 or nothing heavy picks nothing",
        Strength.pick(mem, 20, 26, 250) == listOf("big") && Strength.pick(mem, 20, 26, 400) == listOf("big", "mid") &&
            Strength.pick(mem, 20, 26, 0) == emptyList<String>() && Strength.pick(mem, 500, 26, null) == emptyList<String>() &&
            Strength.pick(emptyMap(), 20, 26, null) == emptyList<String>())
    check("23 auto clean aims for 150% / 220% / 400% of the shortfall, and 0 when RAM is fine",
        Strength.GENTLE.needMb(800, 500) == 450L && Strength.STRONG.needMb(800, 500) == 660L &&
            Strength.MAX.needMb(800, 500) == 1200L && Strength.STRONG.needMb(800, 800) == 0L && Strength.STRONG.needMb(800, 900) == 0L)
    check("24 saved setting: default is Strong, bad numbers fall back to it, next() cycles through all three and back",
        Strength.DEFAULT == Strength.STRONG && Strength.fromOrdinal(0) == Strength.GENTLE && Strength.fromOrdinal(2) == Strength.MAX &&
            Strength.fromOrdinal(-1) == Strength.DEFAULT && Strength.fromOrdinal(3) == Strength.DEFAULT &&
            Strength.GENTLE.next() == Strength.STRONG && Strength.STRONG.next() == Strength.MAX && Strength.MAX.next() == Strength.GENTLE)
    check("25 extra passes come after the always-on 1.2 s retry, in order, and all finish within 30 s",
        Strength.values().all { st ->
            val a = st.latePassesMs
            a.all { it > 1_200L && it <= 30_000L } && a.indices.all { i -> i == 0 || a[i] > a[i - 1] }
        } && Strength.STRONG.latePassesMs.size == 1 && Strength.MAX.latePassesMs.size == 2)
    check("26 cached-process clearing: never at Gentle, taps only at Strong, taps and auto at Maximum",
        !Strength.GENTLE.clearCachedManual && Strength.STRONG.clearCachedManual && !Strength.STRONG.clearCachedAuto &&
            Strength.MAX.clearCachedManual && Strength.MAX.clearCachedAuto)
    check("27 descriptions: every level says nothing protected is touched; the Shizuku note shows only when it is not ready",
        Strength.values().all { it.describe(true).contains("never touched") && it.describe(true).contains("never force-stops") } &&
            !Strength.STRONG.describe(true).contains("needs Shizuku") && Strength.STRONG.describe(false).contains("needs Shizuku") &&
            Strength.MAX.describe(false).contains("needs Shizuku") && !Strength.GENTLE.describe(false).contains("needs Shizuku"))

    // ---- more known games (3.7)
    val yes2 = listOf("com.riotgames.league.wildrift", "com.kitkagames.fallbuddies", "com.outfit7.mytalkingtomfree", "com.netmarble.lineageII",
        "com.nexon.maplestory", "com.scopely.monopolygo", "com.mobilityware.solitaire", "com.bandainamcoent.dblegends_ww",
        "com.sega.sonicdash", "com.square_enix.android_googleplay.ffbeww", "com.com2us.smon.normal.freefull.google.kr.android.common",
        "com.fgol.HungrySharkEvolution", "com.appsomniacs.da2")
    val no2 = listOf("com.netease.cloudmusic", "com.nintendo.znca", "com.sega", "com.nexonx.app", "com.riotgamesx.app",
        "com.segway.ninebot", "com.outfit7x.tool", "com.google.android.gms")
    check("28 added publishers recognised (${yes2.count { GameHints.looksLikeGame(it) }}/${yes2.size})", yes2.all { GameHints.looksLikeGame(it) })
    check("29 look-alike names are NOT recognised (${no2.count { !GameHints.looksLikeGame(it) }}/${no2.size})", no2.none { GameHints.looksLikeGame(it) })

    println(if (failures == 0) "\nALL PASSED" else "\n$failures FAILED")
    kotlin.system.exitProcess(if (failures == 0) 0 else 1)
}
