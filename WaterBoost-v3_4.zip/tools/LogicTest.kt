// Logic tests for game mode, runnable on any computer (no phone, no Gradle):
//   kotlinc app/src/main/java/com/waterboost/app/SessionWatch.kt app/src/main/java/com/waterboost/app/GameHints.kt tools/LogicTest.kt -d out
//   java -cp out:<kotlin-stdlib.jar> LogicTestKt
// Covers: Home press, game failing to start, detours to other apps, screen off, second game, and which package names count as games.
import com.waterboost.app.GameHints
import com.waterboost.app.SessionWatch

var failures = 0
fun check(name: String, ok: Boolean) { println((if (ok) "PASS " else "FAIL ") + name); if (!ok) failures++ }

const val OWN = "com.waterboost.app"
const val GAME = "com.dts.freefireth"
const val TICK = 3_000L

/** Runs ticks every 3 s from t0 until [until]; [state] says what the phone reports at time t. Returns the time it ended, or -1. */
fun run(w: SessionWatch, t0: Long, until: Long, state: (Long) -> Triple<Boolean, Boolean, String?>): Long {
    var t = t0 + TICK
    while (t <= until) {
        val (interactive, ui, front) = state(t)
        if (w.update(t, interactive, ui, front, GAME)) return t
        t += TICK
    }
    return -1
}

fun main() {
    val T0 = 1_000_000L

    // 1. Playing normally, no usage access: never ends by itself in an hour.
    run {
        val w = SessionWatch(OWN); w.begin(T0)
        check("1 plays for an hour, no usage access -> keeps going", run(w, T0, T0 + 3_600_000) { Triple(true, false, null) } == -1L)
    }
    // 2. Press Home (WaterBoost home visible) at +60 s: must end after >= 4 s and within ~10 s.
    run {
        val w = SessionWatch(OWN); w.begin(T0)
        val e = run(w, T0, T0 + 200_000) { t -> Triple(true, t >= T0 + 60_000, null) }
        check("2 Home press ends game mode in 4..10 s (took ${(e - (T0 + 60_000)) / 1000.0} s)", e != -1L && e - (T0 + 60_000) in 4_000..10_000)
    }
    // 3. The game fails to appear and Home stays visible: still never ends before the 8 s start guard.
    run {
        val w = SessionWatch(OWN); w.begin(T0)
        val e = run(w, T0, T0 + 60_000) { Triple(true, true, null) }
        check("3 start guard: not before 8 s, but ends by 12 s (ended at +${(e - T0) / 1000.0} s)", e - T0 > 8_000 && e - T0 <= 12_000)
    }
    // 4. Usage access: a 10 s detour to another app and back never ends it.
    run {
        val w = SessionWatch(OWN); w.begin(T0)
        val e = run(w, T0, T0 + 120_000) { t ->
            val away = t in (T0 + 40_000)..(T0 + 50_000)
            Triple(true, false, if (away) "com.whatsapp" else GAME)
        }
        check("4 short detour (10 s) to another app -> keeps going", e == -1L)
    }
    // 5. Usage access: leaves for another app for good -> ends after > 25 s.
    run {
        val w = SessionWatch(OWN); w.begin(T0)
        val e = run(w, T0, T0 + 300_000) { t -> Triple(true, false, if (t >= T0 + 40_000) "com.whatsapp" else GAME) }
        val took = e - (T0 + 40_000)
        check("5 stays in another app -> ends after 25..32 s (took ${took / 1000.0} s)", e != -1L && took in 25_000..32_000)
    }
    // 6. Usage access: a WaterBoost screen in front -> short grace (4 s), not 25 s.
    run {
        val w = SessionWatch(OWN); w.begin(T0)
        val e = run(w, T0, T0 + 300_000) { t -> Triple(true, false, if (t >= T0 + 40_000) OWN else GAME) }
        val took = e - (T0 + 40_000)
        check("6 WaterBoost screen in front -> ends in 4..10 s (took ${took / 1000.0} s)", e != -1L && took in 4_000..10_000)
    }
    // 7. Screen off for 2 min and back: keeps going. Off for 6 min: ends after > 5 min.
    run {
        val w = SessionWatch(OWN); w.begin(T0)
        val e = run(w, T0, T0 + 600_000) { t -> Triple(!(t in (T0 + 60_000)..(T0 + 180_000)), false, null) }
        check("7a screen off 2 min then back -> keeps going", e == -1L)
        val w2 = SessionWatch(OWN); w2.begin(T0)
        val e2 = run(w2, T0, T0 + 900_000) { t -> Triple(t < T0 + 60_000, false, null) }
        val took = e2 - (T0 + 60_000)
        check("7b screen off for good -> ends after 5..5.1 min (took ${took / 1000.0} s)", e2 != -1L && took in 300_000..306_000)
    }
    // 8. Screen off 4 min, on 10 s, off 4 min: the timer restarts, so no end.
    run {
        val w = SessionWatch(OWN); w.begin(T0)
        val e = run(w, T0, T0 + 600_000) { t ->
            val off = t in (T0 + 10_000)..(T0 + 250_000) || t in (T0 + 262_000)..(T0 + 500_000)
            Triple(!off, false, null)
        }
        check("8 off 4 min, on briefly, off 4 min -> timer restarted, keeps going", e == -1L)
    }
    // 9. Usage access reports the game but the screen is off: the away rule must not fire.
    run {
        val w = SessionWatch(OWN); w.begin(T0)
        val e = run(w, T0, T0 + 200_000) { t -> Triple(t < T0 + 20_000, false, "com.android.systemui") }
        check("9 screen off + stale front app -> only the 5 min rule applies", e == -1L)
    }
    // 10. Before begin() nothing ends.
    run {
        val w = SessionWatch(OWN)
        check("10 update before begin() never ends", !w.update(T0, true, true, OWN, GAME))
    }
    // 11. begin() again (second game) clears the old away/home timers.
    run {
        val w = SessionWatch(OWN); w.begin(T0)
        // 20 s away so far (not over yet), then the second game starts
        run(w, T0, T0 + 20_000) { Triple(true, false, "com.whatsapp") }
        w.begin(T0 + 21_000)
        val e = run(w, T0 + 21_000, T0 + 120_000) { Triple(true, false, GAME) }
        check("11 second game start resets the timers", e == -1L)
    }

    // ---- known games
    val yes = listOf("com.dts.freefireth", "com.dts.freefiremax", "com.pubg.imobile", "com.tencent.ig", "com.supercell.brawlstars",
        "com.activision.callofduty.shooter", "com.miHoYo.GenshinImpact", "com.mojang.minecraftpe", "com.roblox.client",
        "com.gameloft.android.ANMP.GloftA9HM", "com.mobile.legends", "com.HoYoverse.hkrpgoversea", "com.tencent.tmgp.pubgmhd",
        "com.innersloth.spacemafia", "com.garena.game.codm", "com.king.candycrushsaga", "com.ludo.king", "com.axlebolt.standoff2")
    val no = listOf("com.tencent.mm", "com.whatsapp", "com.google.android.youtube", "com.android.chrome", "com.instagram.android",
        "com.netease.cloudmusic", "com.kingsoft.office", "com.dtsx.audio", "com.king", "com.garenax.app", "com.google.android.apps.maps",
        "org.telegram.messenger", "com.spotify.music", "com.facebook.katana", "com.waterboost.app")
    check("12 known games recognised (${yes.count { GameHints.looksLikeGame(it) }}/${yes.size})", yes.all { GameHints.looksLikeGame(it) })
    check("13 normal apps NOT recognised (${no.count { !GameHints.looksLikeGame(it) }}/${no.size})", no.none { GameHints.looksLikeGame(it) })

    println(if (failures == 0) "\nALL PASSED" else "\n$failures FAILED")
    kotlin.system.exitProcess(if (failures == 0) 0 else 1)
}
