# WaterBoost

Tiny Android RAM monitor. A water-filled circle shows how much RAM is used; "Clean now" (or auto mode)
asks Android to stop background processes of your apps.

* **Clean now** - stops background processes of launchable user apps, reports MB actually freed.
* **Auto clean** - foreground service checks every 30 s; cleans when free RAM < limit (cooldown adapts).
* **Protected apps** - apps that are never touched (launcher, keyboard, SMS, dialer are always protected).
* **Shizuku (optional)** - measures each app's real memory, closes only the heaviest ones and stops once
  enough is freed. Also shows a "Top memory apps" list. Falls back to normal mode if Shizuku isn't running.
* **Launcher** - WaterBoost can be your home screen: Ghibli-style painted sea (horizon height = RAM used; sky, sun, clouds and waves shift blue ->
  sunset gold -> rose red as RAM runs low, livelier waves when memory is tight, stays level when you tilt the phone), clock,
  dock, searchable app drawer, long-press app menu. Falls back to a 2D wave if the GPU can't run the shader.
* **Deep clean (Shizuku)** - force-stops chosen apps (or all non-protected ones) and clears every app's cache
  (`pm trim-caches`). Auto mode runs when you reach the home screen and RAM is low. Never touches app data.
* **Realme / OPPO tuning** (tested target: Realme Narzo 50A Prime, 4 GB, Android 11, Realme UI) - default
  limit scales with RAM, Google/Realme system helpers are never closed, auto mode pauses with the screen
  off, "Keep running in background" opens Realme UI's auto-start screen. Device code lives in Device.kt.
* **Game booster (Game Space)** - one tap cleans RAM and starts your game, then game mode keeps WaterBoost quiet and (optionally)
  silences notifications until you stop playing. Extreme boost, battery-saver-off and a live heat readout (3.3) go further.
* Build: push to GitHub, run the "Build APK" workflow, download the debug APK artifact.

## 2.1 fixes (auto mode stopping + lag)
* Back-off no longer climbs to 15 min (max 3 min) and resets when the screen turns on.
* A stuck clean/shell call can no longer block cleaning forever (timeouts + busy watchdog).
* App list is cached, no more loading every app label on each clean.
* Kill batches capped to the 12 heaviest apps; auto deep clean throttled to once per 5 min.
* Service loop survives errors, restarts via an alarm if Realme UI kills it, survives swiping from recents.
* Launcher water renders at 1/3 resolution and ~22 fps.

## 2.2 Ghibli water
* New cheap toon shader: pastel sky, sun, drifting clouds, five flat wave layers with foam lines and sparkles.
* Whole scene palette follows RAM: calm blue -> golden sunset -> rose-red dusk.
* Rendering pauses while the app drawer covers the screen.

## 2.3 Built-in Control Panel
* The launcher now has its own Control Panel tile: always first in the app drawer and permanently first in the dock
  (a round water-drop badge). Tap it to open the settings/cleaner screen; long-press for "Open control panel" / "Clean RAM now".
* The separate WaterBoost entry no longer shows up as a normal app in the drawer. Dock holds the Control Panel plus up to 4 apps.

## 2.4 Shizuku connection card
* Control Panel has a "SHIZUKU CONNECTION" card: live status (connected / permission needed / not running / not installed),
  a hint for the next step, and one button that does it (get Shizuku, open it to start, ask permission, or connect and test).
* Updates instantly when Shizuku starts or stops.

## 2.5 Tuned for realme narzo 50A Prime (Unisoc T612, Mali-G57, 4 GB, 1080x2408)
* Water renders at ~360 px wide with no depth buffer, and steps down by itself (30 -> 24 -> 20 fps, lower resolution)
  if the measured frame rate falls behind. Battery saver caps it at 20 fps and halves the auto-clean check rate.
* Cleaning and app loading run at background thread priority so they never fight the UI on the A55 cores.
* Default RAM trigger is 22% of total (~800 MB). Shizuku itself is never closed.
* Control Panel shows chip and RAM, and has a "Battery: allow unrestricted" button (Realme UI kills optimised apps).
* Android 12+ refusing a background foreground-start no longer crashes the service.
* Build now makes an optimised, shrunk release APK next to the debug one. If the release APK ever misbehaves,
  install the debug APK from the same artifact.

## 2.6 Cyberpunk
* New look for the launcher and the Control Panel: neon cyan / magenta / yellow on near-black, cut corners, monospace type, faint scanlines.
* Home screen is now a HUD: glitch-style clock, date line, and a RAM panel with a segmented bar (tap it to clean, long-press for the Control Panel).
* Background is a neon city and sea. The horizon height is still your RAM level. Palette: cyan + magenta (fine) -> yellow (low) -> red alert with a little screen glitch (almost out).
* Dock, "ALL_APPS" button, app drawer search and the Control Panel tile were restyled to match. Rendering cost is about the same as 2.5.

## 2.7 Force-stop helper (no Shizuku, no root)
* Android only lets the shell (Shizuku / root) force-stop other apps silently. Without them there are two options, and WaterBoost now uses both:
  * **Quiet clean** (always on, nothing on screen): stops background processes of your apps, skips apps that are already stopped, and
    kills twice about a second apart so sticky services restart later.
  * **Force-stop helper** (new, optional): an Accessibility service that opens each app's App info page in Settings and taps
    Force stop and OK, the way you would. Turn it on in Control Panel > FORCE-STOP HELPER, then switch on
    "WaterBoost force-stop helper" in Accessibility settings (Android 13+: first App info > three dots > Allow restricted settings).
* It is used by **Deep clean now** and by **auto deep clean when you reach home** whenever Shizuku is not ready, with the same
  "Pick apps to force-stop" list / scope and the same Protected apps list.
* It cannot run invisibly: the screen must be on and unlocked, and a cover screen (tap it to cancel) hides Settings for about 2-3 s per app.
  Max 8 apps per sweep; apps already in the stopped state are skipped, so later sweeps move on to the next ones; apps whose Force stop button
  is greyed out are remembered and skipped. It will not start during a call or on the lock screen, auto mode also skips while music plays and waits
  at least 10 min between sweeps, and a sweep aborts after two failures in a row. The Control Panel shows the result of the last sweep.
* It acts only while Settings is the top window and presses only Force stop, OK and Back. WaterBoost still has no internet permission.

## 2.7.2 Bug fixes (no new features, look unchanged)
* **Auto clean switch now really switches it off.** Before, the restart alarm stayed armed and could bring the service (and its
  notification) back a few minutes later with the switch showing off. Turning it off now cancels the alarm, and a stale alarm
  is ignored when auto mode is off.
* **Updates install over the old version.** Debug and release APKs are now signed with one fixed key (`app/waterboost.p12`).
  The automatic debug key was created fresh on every GitHub run, so each APK had a different signature and Android refused the
  update. **Uninstall WaterBoost once before installing 2.7.2**; every build after that updates in place.
  (The key and its password are public in this project. To use your own, replace the file and the `signingConfigs` block in `app/build.gradle.kts`.)
* **Launcher:** apps installed or removed while the home screen was in the background (Play Store, Settings) now show up when you
  come back. Tapping ALL_APPS while the drawer is still sliding away no longer leaves it hidden. App info / Uninstall can no longer
  crash the launcher. The `v2.x` label now follows the real version.
* **Water:** the glitch effect starts when RAM is nearly full (about 80% used); it used to begin around 56%, which is the
  normal level on a 4 GB phone. A short pause (or the drawer) no longer counts as slow frames, so the quality ladder isn't
  tripped by it. Shader objects are released after linking.
* **Cleaning:** two cleans can no longer overlap (deep clean gets a longer lock, and a run that timed out can't release a
  newer run's lock). If a clean is skipped because one is already running, you now get "Already cleaning" instead of
  "Nothing more to free" / "freed 0 MB", and it no longer starts the auto-mode cooldown.
* **Force-stop helper:** an app whose Force stop button was grey is tried again after 6 h (it used to be skipped until
  WaterBoost restarted), and an app that is simply not running is not blacklisted. The Control Panel says why a sweep did
  not start, and Settings' button labels are re-read for each sweep, so a language change is picked up.
* **Control Panel:** the app pickers open without freezing and only list apps WaterBoost can actually touch (system apps are
  never touched). The Shizuku test counts real processes instead of accepting an empty reply.

## 2.8 Final fixes (no new features, look unchanged)
* **Auto deep clean never cuts music or a call.** With the helper it already waited while music played; now it also waits
  during calls and voice chats, and the same check applies when Shizuku does the force-stop.
* **Your next alarm is safe.** The app that owns your next alarm joins the always-protected apps (launcher, keyboard, SMS,
  dialer), because force-stopping an app cancels its alarms. It is looked up at most once a minute.
* **Cancel means cancel.** If you tap the cover screen to stop a force-stop sweep, auto deep clean now waits an hour before
  trying again (it used to come back after 10 minutes).
* **Auto mode survives an update.** Installing a new WaterBoost stops the running service; it is now restarted by itself
  (also after a "fast boot") if Auto clean was on.
* **Shizuku:** a shell command that hangs can no longer leave its reader stuck. Shizuku restarts WaterBoost's helper
  process once because of this.
* **Control Panel:** the Auto clean switch follows the notification's "Turn off" button while the panel is open, the app
  lists can't crash if you rotate the phone while they load, and the dock icons have names for TalkBack.
* A clean with nothing to kill no longer waits for its second pass.
* Coming from 2.7.1 or older: uninstall WaterBoost once (the signing key changed in 2.7.2). From 2.7.2 on, updates install in place.

## 2.9 Neon notification
* The "auto mode on" notification now matches the HUD look: a translucent dark panel with a neon cyan edge (and a faint
  magenta ghost edge), glowing mono text, a live segmented RAM bar that turns yellow and red as memory runs low, and
  "FREE xxx MB // CLEANS BELOW yyy MB". Expand it to see the last clean result and the Shizuku / helper status.
* New notification icon (the drop with two scan-line slits) and a neon cyan accent colour for it.
* It refreshes every 30 s while the screen is on (60 s in battery saver) and is not brought back if you swipe it away
  (Android 14+). "Turn off" works as before.
* Android draws the notification card and its round icon itself, so those can't be made see-through; the panel inside is
  what is styled. The panel is more transparent in dark mode and more solid in light mode so the text stays readable.
  If the neon layout can't be built for any reason, the plain notification is shown instead.

## 3.0 Smoothness (same look)
Tuned for budget phones like the Realme Narzo 50A Prime (Unisoc T612, Mali-G57 MP1, 60 Hz screen). Install
**app-release.apk**: it is minified and non-debuggable. (The debug APK is now non-debuggable too, so it is no longer slower.)
* **App drawer:** the blurred shadow on every label is gone (it cost the GPU a blur pass per label per frame while
  scrolling, and was invisible on the dark panel). The drawer is fully opaque, and the home page and the full-screen
  scanlines underneath are not drawn while it is open. It is laid out once at start, so the first open doesn't build the
  cells. It slides as a cached layer with snappier easing. Search no longer rebinds every cell when nothing changed.
* **Icons** are GPU-resident bitmaps (Android 9+), so scrolling never waits for an upload and there is no second copy in
  RAM. An app whose package, activity and update time are unchanged keeps its icon: a burst of Play Store updates no longer
  redraws every icon. Apps open by growing out of the icon you tapped.
* **Water:** paced by the screen's vsync (30 fps = every 2nd vsync) instead of a 33 ms timer that drifted against it, so
  every second or few a frame was dropped or shown twice. Its animation clock is the vsync time. The GL context is kept when you leave the home
  screen, so coming back is immediate. It pauses while the notification shade has the focus (so the shade animates freely),
  and the tilt sensor only runs while the water moves. The big clock's glow is cached in a GPU layer instead of re-blurred
  every frame. Quality ladder: 30 fps, then 20 fps, then 20 fps at a lower resolution.
* **Coming home** does no heavy work during the return animation: the service isn't poked every time, the notification (bar
  bitmap and layouts) is built on a background thread, and the sensor and service check start 0.4 s later.
* **Auto clean waits while you are swiping** (2.5 s after your last touch): killing apps loads the whole phone, and that is
  when a frame would drop.
* **Control Panel:** status lines are only re-laid out when their text changes; the RAM gauge is time-based and vsync-locked.
* **Starts dark** (no grey flash while the app starts).
* **New: Control Panel > SPEED > Optimize WaterBoost code (Shizuku).** A sideloaded app is installed only "verified": its code
  is interpreted and JIT-compiled until Android's idle job gets to it, and every update resets that. This asks Android to
  compile all of WaterBoost now (about 20 s). Do it once after each update, then restart WaterBoost (the button offers to).

## 3.1 Start-up fix (same look)
Checked against the Realme Narzo 50A Prime (Unisoc T612, 4 GB, Android 11+ Realme UI).
* **Fixed: the launcher crashed as soon as it started.** In 3.0 the app drawer's adapter read the screen density while the
  home screen's Activity object was still being constructed, before Android had given it any resources, so it threw a
  NullPointerException and the launcher closed right away. It now reads the density the first time a cell is
  built. Nothing else in the app touches resources that early (checked in the compiled code of every Activity, Service and Receiver).
* **Cold start:** the app list is read once instead of twice (the second read only ran the same scan again right after the first).
* **Control Panel:** dragging the limit slider now only updates its label. It used to run a full refresh (several system calls and a
  re-layout of the status cards) on every step of the drag.
* **Auto clean / deep clean:** the "last run" timers can no longer get stuck if the phone's clock is set back (a time in the future
  now counts as long ago).
* **"Keep running in background" on Realme UI:** some Realme UI versions don't let other apps open the Safe Centre auto-start screens.
  When that happens it now falls back to WaterBoost's App info page (where Realme UI keeps "Auto launch" and "Allow background activity") before the
  generic battery list. "Battery: allow unrestricted" still covers that list.
* Updating: same signing key as 2.7.2 onwards, so 3.1 installs over 3.0 without uninstalling. An update resets Android's compiled
  copy of the app, so run Control Panel > SPEED > Optimize WaterBoost code once more (needs Shizuku), or from a computer:
  `adb shell cmd package compile -m speed -f com.waterboost.app`.

## 3.2 Game booster (Game Space)
Your Realme Narzo 50A Prime has no game booster of its own, so WaterBoost now has one. It does what a normal app really can do
without root, and it keeps its own footprint tiny while you play. (It cannot raise CPU or GPU clocks: Android
does not allow that for normal apps, and anything claiming to is not telling the truth.)

* **Game Space** - a new button on the home screen (under the RAM panel) and in the Control Panel (GAME BOOSTER). It lists your games;
  tap one to **clean RAM, then start it**. The game starts as soon as the quick clean is done (about half a second) and never later than
  2.5 s, so a slow moment can't make a tap feel stuck.
* **Which apps are games** - the ones Android knows as games, plus any you add: Game Space > Pick games, or long-press any app on the
  WaterBoost home screen > Add to Game Space. Not every game tells Android that it is one, so check the list once. Detect games again
  returns to the automatic list.
* **Open a game from the home screen, drawer, search or dock and it boosts too** (switch it off in Game Space > Options).
* **Boost RAM now** - the same clean without starting a game.
* **What the clean does** - the same safe rules as Clean now: it never closes the launcher, keyboard, SMS, dialer, the app with your next
  alarm, Protected apps, system apps, Google services or the game itself. Apps that are already stopped are skipped. With Shizuku
  connected it also closes the heaviest apps still running. A second quiet pass a second later beats apps that restart themselves.
* **Hard boost (Shizuku, optional)** - force-stops the heaviest apps instead of just closing them. Off by default; it asks before it
  turns on, and it falls back to the gentle clean while music or a call is playing.
* **Game mode** - starts when you open a game through WaterBoost. A quiet notification with a play timer and an End button shows
  while it is on. During game mode WaterBoost's auto clean and auto deep clean are paused and its own notification stops redrawing,
  so nothing of WaterBoost's competes with the game. Game mode checks every 3 s on a low-priority thread (every 15 s with the screen off).
* **It ends by itself** - a few seconds after you return to a WaterBoost screen (home screen included), 25 s after you leave the game
  for another app (needs Usage access, see below), after 5 minutes with the screen off, or when you tap End.
* **Silence notifications while I play (optional)** - uses Do Not Disturb "Priority only", so calls and alarms you allowed there still
  come through. Android asks you once to allow WaterBoost under Do Not Disturb access. It is switched off again when game mode ends.
  If Do Not Disturb was already on, WaterBoost leaves it exactly as it was; if you change it yourself while playing, it does not touch
  it afterwards. If WaterBoost is killed or updated mid-game, the next time any WaterBoost screen opens (or after a reboot) it puts
  Do Not Disturb back, so it can't stay on by mistake.
* **Usage access (optional)** - lets game mode see which app is in front, so it ends exactly when you leave the game. Without it, game mode
  ends when you return to the WaterBoost home screen (WaterBoost as your home app is the best setup). Nothing leaves the phone;
  WaterBoost still has no internet permission.
* **Realme UI** - Game Space has the same "Battery: allow unrestricted" and "Keep running in background" shortcuts as the Control Panel;
  they stop Realme UI from closing game mode while you play.
* **Android 13+**: allow notifications once (Game Space asks the first time you open it), otherwise game mode still works but its
  notification is hidden.
* Updating: same signing key as 2.7.2 onwards, so 3.2 installs over 3.1 without uninstalling. An update resets Android's compiled copy of the app, so run
  Control Panel > SPEED > Optimize WaterBoost code once more (needs Shizuku).
* New permissions: Usage access is optional and granted by you in Settings (`PACKAGE_USAGE_STATS`). Nothing else was added.

## 3.3 Extreme game boost
"No app can raise your CPU or GPU speed" is still true, and that includes this one: on a phone that is not rooted, Android does not let
any app, even with Shizuku, set the CPU or GPU clocks. What 3.3 adds is everything that really does change how fast your games run.

* **Extreme boost (Shizuku, optional)** - after the normal clean it also clears every *cached* process on the phone, system and Realme
  apps included (`am kill-all`). These are apps that are not doing anything and that Android would close anyway when memory runs low;
  this just does it before the game starts. It is the only way to reach their memory, and nothing is force-stopped, so alarms,
  notifications and music are not touched. A few apps may open a little slower right after.
* **Battery saver off while you play (Shizuku, optional)** - battery saver limits what the phone may do. If it is on when game mode
  starts, it is switched off for the session and switched back on afterwards, and only if it was on. If WaterBoost is killed or updated
  mid-game, the next time a WaterBoost screen opens it puts battery saver back (like Do Not Disturb in 3.2).
* **Heat watch** - the T612 slows itself down when it gets hot, and no app can stop that, so WaterBoost tells you in time: the phone
  temperature shows live in the game-mode notification (and in Game Space together with Android's own thermal state), and a hot phone
  (42 degrees or Android's "moderate" thermal status) gets one warning on screen. Lowering the in-game graphics and taking the case off
  helps more than any app can.
* **Optimize game code (Shizuku)** - long-press a game in Game Space. It asks Android to compile the game's app code now (up to about 3
  minutes, some storage). It helps games with a lot of Java/Kotlin code start faster; most 3D games are mostly native code and gain little.
* **Not included, on purpose** - forcing the CPU/GPU governors to "performance" (needs root, and on a phone this size it makes it hot
  sooner, so it usually ends up *slower* after a few minutes), and any app that claims a "CPU/GPU boost" without root.
* Updating: this version changes the Shizuku helper, so Shizuku restarts it once by itself; if the new options say Shizuku is not
  connected, open the Control Panel and press Connect.

## 3.4 Final tuning (launcher + game booster)
**Game booster**
* **Faster start** - the game now starts right after the quick clean (about a tenth of a second) instead of waiting 0.35 s to measure the
  result first. That first part runs at normal priority, because you are waiting for it; everything after it (the Shizuku steps, the
  second pass, the measuring) runs at background priority so it never competes with the game while it loads.
* **No rescan before launch** - the boost reuses the last app list instead of reading every app again right when you tap. (The list is
  refreshed afterwards, before the Shizuku steps, where alarm owner and keyboard matter.)
* **You can see that it ran** - every boost ends with a message ("~N MB freed", or "RAM was already clear"), and Game Space shows
  "Last boost: ~N MB freed (mode)".
* **More games recognised** - many popular games never tell Android they are games, so tapping them would not boost. A short list of
  well-known game publishers and titles (Free Fire, BGMI/PUBG, Call of Duty, Genshin, Minecraft, Roblox, Supercell and others) is now
  recognised by name, in addition to what Android reports. Anything else: Game Space > Pick games, or long-press the app.
* **Tested** - the rules for when game mode ends were moved into their own class and run through 14 scenarios on a computer
  (`tools/LogicTest.kt`): pressing Home, the game failing to start, a short detour to another app, leaving for good, screen off and on,
  a second game, plus which package names count as games (and that WeChat and other normal apps do not).

**Launcher**
* The once-a-second RAM readout no longer touches the screen when its numbers did not change, so nothing is laid out or redrawn on the
  main thread in those seconds.
* Everything else that makes a launcher lag was already handled and is unchanged: the water is drawn at one third of the screen size
  at 30 fps paced by the display's own vsync (and steps itself down if the GPU can't keep up), it stops completely while the drawer,
  another app or the notification shade is in front, icons are GPU-resident bitmaps with a cache, the app list is only rebuilt when
  apps really changed, and auto cleaning waits while you swipe.
* For the smoothest result after installing: run Control Panel > SPEED > Optimize WaterBoost code once (Shizuku), and set
  Battery: allow unrestricted.
