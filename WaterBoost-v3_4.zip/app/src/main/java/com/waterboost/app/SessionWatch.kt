package com.waterboost.app

/**
 * Decides when game mode is over. Plain logic (times in, yes/no out, no Android classes) so it can be tested on any computer;
 * [GameService] feeds it what the phone reports every few seconds. All times are milliseconds on one monotonic clock.
 *
 * Game mode ends when, for long enough:
 *  - a WaterBoost screen (usually the home screen) is in front: you pressed Home;
 *  - another app is in front and usage access tells us so: you did not come back to the game;
 *  - the screen is off: you put the phone down.
 * The first seconds after the game was started never end it: that is the game starting up.
 */
class SessionWatch(private val ownPackage: String) {
    companion object {
        const val HOME_GRACE = 4_000L            // a WaterBoost screen this long in front = left the game
        const val AWAY_GRACE = 25_000L           // another app this long in front = left the game
        const val START_GUARD = 8_000L           // the game is starting: never end in this time
        const val SCREEN_OFF_LIMIT = 5 * 60_000L // screen off this long = done playing
        private const val NONE = -1L
    }

    private var start = NONE
    private var uiSince = NONE
    private var awaySince = NONE
    private var offSince = NONE

    /** A game was (re)started now. */
    fun begin(now: Long) {
        start = now; uiSince = NONE; awaySince = NONE; offSince = NONE
    }

    /**
     * @param front the app that last came to the front, or null when usage access is off (that rule is then skipped)
     * @return true when game mode should end now
     */
    fun update(now: Long, interactive: Boolean, uiVisible: Boolean, front: String?, game: String): Boolean {
        if (start == NONE) return false
        var over = false

        if (interactive) offSince = NONE else if (offSince == NONE) offSince = now
        if (offSince != NONE && now - offSince > SCREEN_OFF_LIMIT) over = true

        if (uiVisible) { if (uiSince == NONE) uiSince = now } else uiSince = NONE
        if (uiSince != NONE && now - uiSince > HOME_GRACE && now - start > START_GUARD) over = true

        if (interactive && front != null) {
            if (front == game) awaySince = NONE else if (awaySince == NONE) awaySince = now
            val grace = if (front == ownPackage) HOME_GRACE else AWAY_GRACE
            if (awaySince != NONE && now - awaySince > grace && now - start > START_GUARD) over = true
        }
        return over
    }
}
