package com.waterboost.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.graphics.drawable.Icon
import android.os.BatteryManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.Process
import android.os.SystemClock
import android.widget.Toast

/**
 * "Game mode": runs from the moment a game is opened through WaterBoost until you stop playing.
 *
 *  - WaterBoost's auto cleaner stays quiet meanwhile ([running] is checked by it), so it never drops a frame.
 *  - If you chose so, Do Not Disturb is on while you play and is switched off again afterwards ([Games.applyDnd]).
 *  - It ends by itself when you leave the game for good (see [tick]), or when you tap "End" in its notification.
 *
 * While nothing happens it costs next to nothing: one check every 3 s on a low-priority thread (15 s with the screen off).
 */
class GameService : Service() {
    companion object {
        const val ACTION_STOP = "com.waterboost.app.GAME_STOP"
        private const val EXTRA_PKG = "pkg"
        private const val EXTRA_LABEL = "label"
        private const val CHANNEL = "g1"
        private const val NOTIF_ID = 2

        private const val TICK_MS = 3_000L
        private const val TICK_OFF_MS = 15_000L
        private const val HOT_TENTHS = 420               // 42.0 C battery temperature: the chip starts to slow itself down around here
        private const val COOL_TENTHS = 400              // below 40.0 C the warning can be shown again

        /** True while game mode is on. The auto cleaner and the auto notification look at it. */
        @Volatile var running = false
        @Volatile var gamePkg: String? = null

        fun start(c: Context, pkg: String, label: String) {
            val app = c.applicationContext
            val i = Intent(app, GameService::class.java).putExtra(EXTRA_PKG, pkg).putExtra(EXTRA_LABEL, label)
            try {
                if (Build.VERSION.SDK_INT >= 26) app.startForegroundService(i) else app.startService(i)
            } catch (e: Exception) {
                // Android refused a foreground start: the game still runs, just without game mode.
            }
        }

        fun stop(c: Context) {
            val app = c.applicationContext
            try { app.stopService(Intent(app, GameService::class.java)) } catch (e: Exception) { }
        }
    }

    private val main = Handler(Looper.getMainLooper())
    private var worker: HandlerThread? = null
    private var wh: Handler? = null
    private lateinit var openPi: PendingIntent
    private lateinit var stopPi: PendingIntent
    private var failed = false
    @Volatile private var gameLabel = ""
    @Volatile private var sinceWall = 0L         // when the play timer in the notification starts (it must not restart on every update)
    @Volatile private var heatNote = ""         // "Phone 38 C. " (+ a warning when hot), shown first in the notification
    private val notifyLock = Any()
    private var live = true                     // guarded by notifyLock: a late update must not bring the notification back

    // Everything below is touched only by the worker thread.
    private var ticking = false
    private lateinit var watch: SessionWatch   // decides when the game is over (see SessionWatch, which is tested on its own)
    private var heatKey = ""               // what the notification currently says about the heat
    private var heatWarned = false
    private var front: String? = null      // last app seen coming to the front (usage access)
    private var eventsFrom = 0L            // wall-clock start of the next usage query

    // ------------------------------------------------------------------ notification

    private fun builder(): Notification.Builder =
        if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CHANNEL) else Notification.Builder(this)

    private fun notification(label: String): Notification {
        val text = heatNote + (
            if (Games.dndWanted(this) && Games.dndAccess(this)) "Auto clean paused, notifications silenced. Tap End when you are done."
            else "Auto clean paused while you play. Tap End when you are done."
        )
        return builder()
            .setSmallIcon(R.drawable.ic_stat_neon)
            .setColor(Cyber.MAGENTA)
            .setContentTitle("GAME MODE // $label")
            .setContentText(text)
            .setStyle(Notification.BigTextStyle().bigText(text))   // the whole text when you pull the notification open
            .setContentIntent(openPi)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setUsesChronometer(true)   // shows how long you have been playing; drawn by the system, costs nothing here
            .setWhen(if (sinceWall != 0L) sinceWall else System.currentTimeMillis())
            .addAction(Notification.Action.Builder(Icon.createWithResource(this, R.drawable.ic_stat_neon), "End", stopPi).build())
            .build()
    }

    /** Re-posts the notification with new text. Safe from the worker thread, and a no-op once the service is going away. */
    private fun refreshNotification() {
        synchronized(notifyLock) {
            if (!live || failed) return
            try {
                getSystemService(NotificationManager::class.java).notify(NOTIF_ID, notification(gameLabel))
            } catch (e: Exception) {
                // the notification is only information
            }
        }
    }

    private fun enterForeground(label: String) {
        if (failed) return
        try {
            val n = notification(label)
            if (Build.VERSION.SDK_INT >= 34) startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
            else startForeground(NOTIF_ID, n)
        } catch (e: Throwable) {
            // Android 12+ can refuse a foreground start from the background.
            failed = true
            stopSelf()
        }
    }

    // ------------------------------------------------------------------ lifecycle

    override fun onCreate() {
        super.onCreate()
        running = true   // set first: Games.recoverStale() must never mistake a live session for a stale one
        if (Build.VERSION.SDK_INT >= 26) {
            getSystemService(NotificationManager::class.java).createNotificationChannel(
                NotificationChannel(CHANNEL, "Game mode", NotificationManager.IMPORTANCE_LOW)
            )
        }
        openPi = PendingIntent.getActivity(
            this, 10, Intent(this, GameActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK), PendingIntent.FLAG_IMMUTABLE
        )
        stopPi = PendingIntent.getService(
            this, 11, Intent(this, GameService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE
        )
        watch = SessionWatch(packageName)
        worker = HandlerThread("wb-game", Process.THREAD_PRIORITY_BACKGROUND).also { it.start() }
        wh = Handler(worker!!.looper)
    }

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        val pkg = i?.getStringExtra(EXTRA_PKG)
        val stopping = i?.action == ACTION_STOP || pkg == null
        // A stop request carries no name: keep the one on the notification until it disappears.
        if (!stopping) {
            gameLabel = i?.getStringExtra(EXTRA_LABEL) ?: pkg ?: ""
            sinceWall = System.currentTimeMillis()
        }
        // Always go to the foreground first, even if we are about to stop: Android insists on it after startForegroundService.
        enterForeground(gameLabel)
        if (failed) return START_NOT_STICKY
        if (stopping) {
            end()
            return START_NOT_STICKY
        }
        gamePkg = pkg
        Games.applyDnd(this)   // on this thread, like the restore in onDestroy
        wh?.post { beginSession(pkg!!) }
        return START_NOT_STICKY   // a session belongs to one game: if Android kills us, there is nothing to resume
    }

    override fun onDestroy() {
        running = false
        gamePkg = null
        wh?.removeCallbacksAndMessages(null)
        worker?.quitSafely()
        Games.restoreDnd(this)
        Games.psaveRestoreAsync(this)   // talks to Shizuku, which can take a moment: not on this thread
        synchronized(notifyLock) {
            live = false
            runCatching { (getSystemService(NotificationManager::class.java)).cancel(NOTIF_ID) }
        }
        super.onDestroy()
    }

    override fun onBind(i: Intent?): IBinder? = null

    /** Stops the service from any thread. [onDestroy] then switches Do Not Disturb off. */
    private fun end() {
        main.post {
            try { stopForeground(STOP_FOREGROUND_REMOVE) } catch (e: Exception) { }
            stopSelf()
        }
    }

    // ------------------------------------------------------------------ watching the game (worker thread)

    private fun beginSession(pkg: String) {
        watch.begin(SystemClock.elapsedRealtime())
        front = pkg
        eventsFrom = System.currentTimeMillis() - 1_000
        Games.psaveOff(this)   // no-op unless you asked for it and battery saver is on; may take a moment (worker thread)
        if (!ticking) {
            ticking = true
            wh?.postDelayed(tick, TICK_MS)
        }
    }

    private val tick = object : Runnable {
        override fun run() {
            var over = false
            var interactive = true
            try {
                val game = gamePkg
                if (game == null) { over = true; return }
                interactive = (getSystemService(Context.POWER_SERVICE) as PowerManager).isInteractive
                if (interactive) heatCheck()
                // With usage access we also know which app is in front (and not just whether a WaterBoost screen is).
                val usage = interactive && Games.usageAccess(this@GameService)
                if (usage) pollFront()
                over = watch.update(SystemClock.elapsedRealtime(), interactive, Games.uiVisible, if (usage) front else null, game)
            } catch (e: Throwable) {
                // One failed check must not end the session or kill the loop.
            } finally {
                if (over) end() else wh?.postDelayed(this, if (interactive) TICK_MS else TICK_OFF_MS)
            }
        }
    }

    /**
     * The chip of this phone slows itself down when it gets hot, and no app can prevent that. What an app can do is tell you
     * in time: the temperature shows live in the notification, and a hot phone gets one warning on screen.
     */
    private fun heatCheck() {
        val tenths = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            ?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, -1) ?: -1
        val status = if (Build.VERSION.SDK_INT >= 29)
            (getSystemService(Context.POWER_SERVICE) as PowerManager).currentThermalStatus else 0
        val throttling = status >= PowerManager.THERMAL_STATUS_MODERATE
        val hot = tenths >= HOT_TENTHS || throttling

        val key = "${tenths / 10}|$status"
        if (key != heatKey) {   // only when the shown degree (or Android's own thermal status) changed
            heatKey = key
            heatNote = buildString {
                if (tenths >= 0) append("Phone ${tenths / 10}\u00B0C").append(if (hot) " - HOT, it is slowing down. " else ". ")
                else if (hot) append("Phone is hot, it is slowing down. ")
            }
            refreshNotification()
        }
        if (hot && !heatWarned) {
            heatWarned = true
            val app = applicationContext
            main.post {
                Toast.makeText(app, "Phone is hot: it will slow down. Lower the graphics or take a short break.", Toast.LENGTH_LONG).show()
            }
        } else if (!hot && heatWarned && tenths in 0 until COOL_TENTHS) {
            heatWarned = false
        }
    }

    /**
     * Reads the app-switch events since the last look. Only "came to the front" events count: the screen turning off also
     * sends "went to the back" for the game, and that must not look like leaving it.
     */
    private fun pollFront() {
        val usm = getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val now = System.currentTimeMillis()
        val ev = usm.queryEvents(eventsFrom, now) ?: return
        val e = UsageEvents.Event()
        while (ev.hasNextEvent()) {
            ev.getNextEvent(e)
            @Suppress("DEPRECATION")
            if (e.eventType == UsageEvents.Event.MOVE_TO_FOREGROUND) front = e.packageName
        }
        eventsFrom = now - 2_000   // a little overlap: events can arrive a moment late (replaying one is harmless)
    }
}
