package com.waterboost.app

import android.app.Activity
import android.app.AppOpsManager
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.os.Process
import android.widget.Toast
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Game booster, the part that is not a screen: which apps are games, "clean, then launch", and Do Not Disturb.
 *
 * What it can really do without root: close background apps right before the game starts (so the game gets the RAM),
 * keep WaterBoost's own auto cleaner quiet while you play (see [GameService]), and silence notifications. It cannot
 * raise the CPU or GPU clocks - Android does not let normal apps do that.
 */
object Games {
    // Settings keys (same SharedPreferences file as the rest of WaterBoost).
    private const val K_LIST = "games"        // the games you chose; missing = use auto-detection
    const val K_AUTO = "gameAuto"             // boost when a game is opened from the WaterBoost home screen (default on)
    const val K_DND = "gameDnd"               // silence notifications while playing
    const val K_HARD = "gameHard"             // also force-stop the heaviest apps (Shizuku only)
    const val K_EXTREME = "gameExtreme"       // also clear every cached process on the phone, system apps included (Shizuku only)
    const val K_PSAVE = "gamePsave"           // switch battery saver off while playing (Shizuku only)
    private const val K_PSAVE_HELD = "psaveHeld"  // WaterBoost turned battery saver off and still has to turn it back on
    const val K_DND_ASK = "gameDndAsk"        // the user went to grant Do Not Disturb access: switch it on when they come back
    private const val K_DND_HELD = "dndHeld"  // WaterBoost turned Do Not Disturb on and still has to turn it off

    /**
     * True while any WaterBoost screen (home, Control Panel, Game Space) is in front. Game mode reads it: seeing one of
     * them for a few seconds means you left the game, even without usage access.
     */
    @Volatile var uiVisible = false

    /** The game is never held back longer than this by the cleaning step. */
    private const val LAUNCH_WAIT_MS = 2_500L

    // Two separate locks: editing the game list can follow a slow scan of all apps, and the Do Not Disturb code runs on the
    // main thread when a game starts, so it must never wait for that.
    private val listLock = Any()
    private val dndLock = Any()
    private val psaveLock = Any()   // held across a Shizuku call (can take seconds): background threads only

    fun autoBoost(c: Context): Boolean = Cleaner.prefs(c).getBoolean(K_AUTO, true)
    fun dndWanted(c: Context): Boolean = Cleaner.prefs(c).getBoolean(K_DND, false)
    fun hardWanted(c: Context): Boolean = Cleaner.prefs(c).getBoolean(K_HARD, false)
    fun extremeWanted(c: Context): Boolean = Cleaner.prefs(c).getBoolean(K_EXTREME, false)
    fun psaveWanted(c: Context): Boolean = Cleaner.prefs(c).getBoolean(K_PSAVE, false)

    // ------------------------------------------------------------------ which apps are games

    /** Apps that declare themselves as games (`isGame` / `appCategory="game"`), plus well-known games that never do (see [GameHints]). */
    private fun isAutoGame(pm: PackageManager, pkg: String): Boolean = try {
        val ai = pm.getApplicationInfo(pkg, 0)
        @Suppress("DEPRECATION")
        val flagged = (ai.flags and ApplicationInfo.FLAG_IS_GAME) != 0
        flagged || (Build.VERSION.SDK_INT >= 26 && ai.category == ApplicationInfo.CATEGORY_GAME) || GameHints.looksLikeGame(pkg)
    } catch (e: Exception) {
        GameHints.looksLikeGame(pkg)
    }

    /** Cheap enough for the main thread (one package lookup, or a settings read). */
    fun isGame(c: Context, pkg: String): Boolean {
        val saved = Cleaner.prefs(c).getStringSet(K_LIST, null)
        return if (saved != null) pkg in saved else isAutoGame(c.packageManager, pkg)
    }

    /** Package names of all games. Reads every app (unless [apps] is given): call from a background thread. */
    fun packages(c: Context, apps: List<Cleaner.App>? = null): Set<String> {
        val saved = Cleaner.prefs(c).getStringSet(K_LIST, null)
        if (saved != null) return HashSet(saved)
        val pm = c.packageManager
        return (apps ?: Cleaner.launchableApps(c)).filter { isAutoGame(pm, it.pkg) }.map { it.pkg }.toHashSet()
    }

    /** The installed games, sorted by name. Background thread only. */
    fun installed(c: Context): List<Cleaner.App> {
        val all = Cleaner.launchableApps(c)
        val set = packages(c, all)
        return all.filter { it.pkg in set }
    }

    /** Adds or removes one app. May read every app (the first time), so call it from a background thread. */
    fun setListed(c: Context, pkg: String, on: Boolean) {
        val auto = packages(c)   // the slow part, outside the lock; only used if you have no list of your own yet
        synchronized(listLock) {
            val p = Cleaner.prefs(c)
            val set = (p.getStringSet(K_LIST, null) ?: auto).toMutableSet()
            if (on) set.add(pkg) else set.remove(pkg)
            p.edit().putStringSet(K_LIST, HashSet(set)).apply()
        }
    }

    fun saveList(c: Context, pkgs: Set<String>) {
        synchronized(listLock) { Cleaner.prefs(c).edit().putStringSet(K_LIST, HashSet(pkgs)).apply() }
    }

    /** Back to auto-detection. */
    fun resetList(c: Context) {
        synchronized(listLock) { Cleaner.prefs(c).edit().remove(K_LIST).apply() }
    }

    fun launchIntent(c: Context, pkg: String): Intent? =
        c.packageManager.getLaunchIntentForPackage(pkg)
            ?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)

    /** A small copy of an app's icon (the original can be a big adaptive icon). Background thread. */
    fun icon(c: Context, pkg: String, sizePx: Int): Drawable? = try {
        val src = c.packageManager.getApplicationIcon(pkg)
        val bmp = Bitmap.createBitmap(sizePx, sizePx, Bitmap.Config.ARGB_8888)
        src.setBounds(0, 0, sizePx, sizePx)
        src.draw(Canvas(bmp))
        BitmapDrawable(c.resources, bmp)
    } catch (e: Throwable) {
        null
    }

    // ------------------------------------------------------------------ boost and launch

    /**
     * Cleans background apps, then starts the game and turns game mode on. [go] is the game's launch intent.
     * Call it on the main thread. The game starts as soon as the quick part of the clean is done, and in any case
     * within [LAUNCH_WAIT_MS], so a slow phone can never make tapping a game feel stuck.
     */
    fun boostAndLaunch(from: Context, go: Intent, pkg: String, label: String, opts: Bundle? = null) {
        val app = from.applicationContext
        val main = Handler(Looper.getMainLooper())
        val once = AtomicBoolean(false)
        val start = Runnable {
            if (!once.compareAndSet(false, true)) return@Runnable
            try {
                // An Activity that is still showing is the safest thing to start from; otherwise the app context.
                val a = (from as? Activity)?.takeIf { !it.isFinishing && !it.isDestroyed }
                if (a != null) a.startActivity(go, opts) else app.startActivity(go, opts)
                GameService.start(app, pkg, label)
            } catch (e: Exception) {
                Toast.makeText(app, "Can't open $label", Toast.LENGTH_SHORT).show()
            }
        }
        main.postDelayed(start, LAUNCH_WAIT_MS)
        val shizuku = ShizukuHelper.state() == ShizukuHelper.State.READY
        val hard = hardWanted(app) && shizuku
        val extreme = extremeWanted(app) && shizuku
        Cleaner.boost(app, pkg, hard, extreme, ready = { main.removeCallbacks(start); start.run() }) { freed ->
            // Always say something, so you can see it ran (nothing at all is only for "skipped" and "failed").
            if (freed > 0) Toast.makeText(app, "GAME BOOST: ~$freed MB freed", Toast.LENGTH_SHORT).show()
            else if (freed == 0L) Toast.makeText(app, "GAME MODE ON: RAM was already clear", Toast.LENGTH_SHORT).show()
        }
    }

    // ------------------------------------------------------------------ Do Not Disturb

    fun dndAccess(c: Context): Boolean = try {
        c.getSystemService(NotificationManager::class.java).isNotificationPolicyAccessGranted
    } catch (e: Exception) {
        false
    }

    /**
     * Switches Do Not Disturb to "Priority only" (your own rules for who may still reach you, alarms included).
     * Only if it was fully off: if you already use Do Not Disturb, it is your choice and is left alone, also afterwards.
     * Main thread only (same thread as [restoreDnd]), so a start and a stop can never cross.
     */
    fun applyDnd(c: Context) {
        if (!dndWanted(c) || !dndAccess(c)) return
        synchronized(dndLock) { applyDndLocked(c) }
    }

    private fun applyDndLocked(c: Context) {
        try {
            val p = Cleaner.prefs(c)
            if (p.getBoolean(K_DND_HELD, false)) return   // already ours (a second game in the same session)
            val nm = c.getSystemService(NotificationManager::class.java)
            if (nm.currentInterruptionFilter != NotificationManager.INTERRUPTION_FILTER_ALL) return
            // On disk before anything changes: if WaterBoost dies now, the next start still knows it has to switch it off.
            p.edit().putBoolean(K_DND_HELD, true).commit()
            nm.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_PRIORITY)
        } catch (e: Exception) {
            // access was withdrawn in the meantime: nothing was changed
        }
    }

    /** Turns Do Not Disturb off again, unless you changed it yourself while playing. */
    fun restoreDnd(c: Context) {
        synchronized(dndLock) { restoreDndLocked(c) }
    }

    private fun restoreDndLocked(c: Context) {
        val p = Cleaner.prefs(c)
        if (!p.getBoolean(K_DND_HELD, false)) return
        try {
            val nm = c.getSystemService(NotificationManager::class.java)
            if (nm.isNotificationPolicyAccessGranted &&
                nm.currentInterruptionFilter == NotificationManager.INTERRUPTION_FILTER_PRIORITY
            ) {
                nm.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_ALL)
            }
        } catch (e: Exception) {
            // nothing more we can do
        }
        p.edit().putBoolean(K_DND_HELD, false).apply()
    }

    /**
     * If WaterBoost was killed or updated while game mode was on, Do Not Disturb would stay on for good. Every start of
     * a WaterBoost screen (and the boot receiver) calls this to put it right. Cheap: one settings read.
     */
    fun recoverStale(c: Context) {
        if (GameService.running) return
        val p = Cleaner.prefs(c)
        if (p.getBoolean(K_DND_HELD, false)) restoreDnd(c)
        if (p.getBoolean(K_PSAVE_HELD, false)) psaveRestoreAsync(c)
    }

    // ------------------------------------------------------------------ battery saver (Shizuku)

    /**
     * Battery saver limits what the phone may do, which is the opposite of what a game needs. If it is on when game mode
     * starts and you asked for it, it is switched off for the session. Blocking (talks to Shizuku): background thread only.
     */
    fun psaveOff(c: Context) {
        if (!psaveWanted(c)) return
        try {
            val pm = c.getSystemService(Context.POWER_SERVICE) as PowerManager
            if (!pm.isPowerSaveMode || ShizukuHelper.state() != ShizukuHelper.State.READY) return
            synchronized(psaveLock) {
                // Game mode may have ended while we waited for the lock: then nobody would switch it back on.
                if (!GameService.running) return
                val p = Cleaner.prefs(c)
                if (p.getBoolean(K_PSAVE_HELD, false)) return   // already ours (a second game in the same session)
                val sh = ShizukuHelper.connect(c) ?: return
                // On disk before anything changes, so a kill in the middle can still be put right later.
                p.edit().putBoolean(K_PSAVE_HELD, true).commit()
                try {
                    sh.setBatterySaver(false)
                } catch (e: Throwable) {
                    p.edit().putBoolean(K_PSAVE_HELD, false).apply()
                }
            }
        } catch (e: Throwable) {
            // Shizuku went away: battery saver was not touched
        }
    }

    /** Switches battery saver back on if WaterBoost switched it off. Blocking: background thread only. */
    fun psaveRestore(c: Context) {
        synchronized(psaveLock) {
            val p = Cleaner.prefs(c)
            if (!p.getBoolean(K_PSAVE_HELD, false)) return
            var back = false
            try {
                val pm = c.getSystemService(Context.POWER_SERVICE) as PowerManager
                if (pm.isPowerSaveMode) {
                    back = true   // you or Android already switched it on again
                } else {
                    val sh = ShizukuHelper.connect(c)
                    if (sh != null) { sh.setBatterySaver(true); back = true }
                }
            } catch (e: Throwable) {
                // handled below
            }
            p.edit().putBoolean(K_PSAVE_HELD, false).apply()
            if (!back) {
                val app = c.applicationContext
                Handler(Looper.getMainLooper()).post {
                    Toast.makeText(app, "Battery saver was off for the game. Switch it on again in Settings if you want it.", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    fun psaveRestoreAsync(c: Context) {
        val app = c.applicationContext
        Thread {
            Process.setThreadPriority(Process.THREAD_PRIORITY_BACKGROUND)
            psaveRestore(app)
        }.start()
    }

    // ------------------------------------------------------------------ usage access (optional)

    /** "Usage access" lets WaterBoost see which app is in front, so game mode ends exactly when you leave the game. */
    fun usageAccess(c: Context): Boolean = try {
        val ops = c.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        val mode = if (Build.VERSION.SDK_INT >= 29)
            ops.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), c.packageName)
        else
            @Suppress("DEPRECATION")
            ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), c.packageName)
        if (mode == AppOpsManager.MODE_DEFAULT)
            c.checkCallingOrSelfPermission("android.permission.PACKAGE_USAGE_STATS") == PackageManager.PERMISSION_GRANTED
        else
            mode == AppOpsManager.MODE_ALLOWED
    } catch (e: Exception) {
        false
    }
}
