package com.waterboost.app

/**
 * Recognises well-known games by package name. Android only lists an app as a game if the app says so itself, and many
 * popular games do not, so tapping them would not boost. This list is deliberately narrow: whole publishers that only make
 * games, plus a few single titles. Never a broad prefix such as "com.tencent." (that is also WeChat).
 * No Android classes in here, so it can be tested on any computer.
 */
object GameHints {
    private val publishers = listOf(
        "com.supercell.", "com.gameloft.", "com.activision.", "com.mihoyo.", "com.hoyoverse.", "com.garena.", "com.dts.",
        "com.king.", "com.miniclip.", "com.kiloo.", "com.roblox.", "com.mojang.", "com.nianticlabs.", "com.krafton.",
        "com.pubg.", "com.moonton.", "com.lilithgame.", "com.igg.android.", "com.epicgames.", "com.rockstargames.",
        "com.ubisoft.", "com.halfbrick.", "com.imangi.", "com.firsttouchgames.", "com.playrix.", "com.rovio.",
        "com.zynga.", "com.ea.games.", "com.ea.gp.", "com.levelinfinite.", "com.proximabeta.", "com.tencent.tmgp.",
        "com.axlebolt.", "com.nekki.", "com.fingersoft.", "com.innersloth.", "com.criticalforceentertainment."
    )

    private val titles = setOf(
        "com.tencent.ig",            // PUBG Mobile
        "com.mobile.legends",        // Mobile Legends
        "com.ludo.king",             // Ludo King
        "jp.konami.pesam",           // eFootball
        "com.wb.goog.mkx",           // Mortal Kombat
        "com.supercell.clashofclans"
    )

    fun looksLikeGame(pkg: String): Boolean {
        val p = pkg.lowercase()
        return p in titles || publishers.any { p.startsWith(it) }
    }
}
