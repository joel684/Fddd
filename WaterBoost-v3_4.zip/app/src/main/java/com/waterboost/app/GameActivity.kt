package com.waterboost.app

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.drawable.Drawable
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.os.Process
import android.os.SystemClock
import android.provider.Settings
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.CompoundButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

/**
 * Game Space: your games, one tap to "clean RAM, then play", and the game mode options. Plain views, no GL and no
 * animation, so the launcher's water pauses behind it and the phone's resources go to the game you are about to start.
 */
class GameActivity : Activity() {
    private val h = Handler(Looper.getMainLooper())
    private lateinit var ramInfo: TextView
    private lateinit var ramBar: HudBar
    private lateinit var sessionLine: TextView
    private lateinit var heatLine: TextView
    private lateinit var endBtn: Button
    private lateinit var boostBtn: Button
    private lateinit var listBox: LinearLayout
    private lateinit var listHint: TextView
    private lateinit var autoSw: Switch
    private lateinit var dndSw: Switch
    private lateinit var hardSw: Switch
    private lateinit var extremeSw: Switch
    private lateinit var psaveSw: Switch
    private lateinit var dndHint: TextView
    private lateinit var usageStatus: TextView
    private lateinit var usageHint: TextView
    private lateinit var usageBtn: Button
    private lateinit var batteryBtn: Button

    private var loadGen = 0            // a list load that is not the newest one is thrown away
    private var playLockUntil = 0L     // a double tap must not start the game twice
    private var optimizing = false     // one code optimization at a time
    private var shownPkg: String? = null
    private var shownName = ""

    private val tick = object : Runnable {
        override fun run() { refresh(); h.postDelayed(this, 1000) }
    }

    private fun px(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_LONG).show()
    private fun alive() = !isFinishing && !isDestroyed

    private fun section(root: LinearLayout, title: String) {
        root.addView(TextView(this).apply {
            text = "// $title"; setTextColor(Cyber.MAGENTA); textSize = 12f
            typeface = Cyber.MONO; letterSpacing = 0.12f
            setPadding(0, px(26), 0, px(6))
        })
        root.addView(Cyber.neonLine(this), LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, px(1)))
    }

    private fun button(root: LinearLayout, label: String, accent: Int = Cyber.CYAN, onClick: () -> Unit): Button {
        val b = Button(this).apply { text = label; setOnClickListener { onClick() } }
        Cyber.styleButton(b, accent)
        root.addView(b, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = px(8) })
        return b
    }

    private fun hint(root: LinearLayout, top: Int = 0): TextView {
        val t = TextView(this).apply {
            setTextColor(Cyber.DIM); textSize = 13f
            setPadding(0, px(top), 0, px(6))
        }
        root.addView(t)
        return t
    }

    private fun switchRow(root: LinearLayout, label: String): Switch {
        val s = Switch(this).apply {
            text = label
            setPadding(0, px(14), 0, px(4))
            Cyber.styleSwitch(this)
        }
        root.addView(s)
        return s
    }

    // ---------------------------------------------------------------- build

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(px(24), px(48), px(24), px(24))
        }
        root.addView(TextView(this).apply {
            text = "GAME_SPACE // BOOST"
            typeface = Cyber.MONO; textSize = 14f; letterSpacing = 0.18f
            setTextColor(Cyber.MAGENTA); setShadowLayer(14f, 0f, 0f, Cyber.MAGENTA)
            setPadding(0, 0, 0, px(14))
        })

        ramInfo = TextView(this).apply { setTextColor(Cyber.TEXT); textSize = 14f; typeface = Cyber.MONO }
        root.addView(ramInfo)
        ramBar = HudBar(this)
        root.addView(ramBar, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, px(10)).apply {
            topMargin = px(8); bottomMargin = px(10)
        })
        sessionLine = TextView(this).apply { textSize = 14f; typeface = Cyber.MONO }
        root.addView(sessionLine)
        heatLine = TextView(this).apply { textSize = 12f; typeface = Cyber.MONO; setPadding(0, px(4), 0, 0) }
        root.addView(heatLine)
        endBtn = button(root, "End game mode", Cyber.RED) {
            GameService.stop(this)
            h.postDelayed({ if (alive()) refresh() }, 400)   // the service reports "off" a moment after it is told to stop
        }
        endBtn.visibility = View.GONE
        boostBtn = button(root, "Boost RAM now", Cyber.CYAN) { boostNow() }

        // ---- games
        section(root, "YOUR_GAMES")
        listBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(listBox, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = px(10) })
        listHint = hint(root, 8)
        button(root, "Pick games") { pickGames() }
        button(root, "Detect games again") {
            Games.resetList(this)
            toast("Using the games Android knows about")
            loadGames()
        }

        // ---- options
        section(root, "OPTIONS")
        autoSw = switchRow(root, "Boost automatically when I open a game from the WaterBoost home screen")
        dndSw = switchRow(root, "Silence notifications while I play")
        dndHint = hint(root)
        hardSw = switchRow(root, "Hard boost: also force-stop the heaviest apps (Shizuku)")
        hint(root).text = "Closes more memory, but those apps stop sending notifications until you open them again. " +
            "Add messaging and music apps to Protected apps first."
        extremeSw = switchRow(root, "Extreme boost: also clear every cached process, system apps included (Shizuku)")
        hint(root).text = "Reaches the memory that only Shizuku can: cached processes of system and Realme apps. " +
            "Nothing is force-stopped; Android restarts what it needs, so a few apps may open a little slower right after."
        psaveSw = switchRow(root, "Turn battery saver off while I play (Shizuku)")
        hint(root).text = "Battery saver limits how much the phone may do. It is switched back on when you stop playing, " +
            "and only if it was on."

        // ---- detection
        section(root, "GAME EXIT DETECTION  (optional)")
        usageStatus = TextView(this).apply { textSize = 15f; typeface = Cyber.MONO; setPadding(0, px(10), 0, px(2)) }
        root.addView(usageStatus)
        usageHint = hint(root)
        usageBtn = button(root, "Open usage access settings") { openUsageAccess() }
        batteryBtn = button(root, "Battery: allow unrestricted") {
            if (Device.ignoringBattery(this)) toast("Already unrestricted") else Device.requestIgnoreBattery(this)
        }
        // Realme / OPPO only: their background manager is the thing that ends game mode early.
        if (Device.isColorOsFamily) {
            button(root, "Keep running in background") { toast(Device.openKeepAlive(this)) }
        }
        hint(root, 6).text = "Realme UI closes apps it thinks are idle. Unrestricted battery and background activity keep game mode alive while you play."

        root.addView(TextView(this).apply {
            setTextColor(Cyber.DIM); textSize = 12f; gravity = Gravity.CENTER
            setPadding(0, px(20), 0, 0)
            text = Device.summary(this@GameActivity)
        })

        window.statusBarColor = Cyber.BG
        window.navigationBarColor = Cyber.BG
        setContentView(ScrollView(this).apply {
            setBackgroundColor(Cyber.BG)
            isFillViewport = true
            addView(root)
        })

        // Android 13+ hides notifications until allowed. Ask once, here, never while a game is starting.
        val p = Cleaner.prefs(this)
        if (Build.VERSION.SDK_INT >= 33 && !p.getBoolean("gameNotifAsked", false) &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            p.edit().putBoolean("gameNotifAsked", true).apply()
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 2)
        }
    }

    // ---------------------------------------------------------------- list

    private fun loadGames() {
        val gen = ++loadGen
        // Reading every app's name and icon takes a moment on a budget phone: do it off the UI thread, at low priority.
        Thread {
            Process.setThreadPriority(Process.THREAD_PRIORITY_BACKGROUND)
            val games = try { Games.installed(this) } catch (e: Throwable) { emptyList() }
            val size = px(44)
            val icons = games.map { Games.icon(this, it.pkg, size) }
            runOnUiThread { if (alive() && gen == loadGen) showGames(games, icons) }
        }.start()
    }

    private fun showGames(games: List<Cleaner.App>, icons: List<Drawable?>) {
        listBox.removeAllViews()
        games.forEachIndexed { i, g ->
            val row = gameRow(g, icons[i])
            listBox.addView(row, LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = px(8) })
        }
        listHint.text = if (games.isEmpty())
            "No games yet. Android only knows some games as games: tap Pick games and tick yours. " +
                "You can also long-press any app on the WaterBoost home screen."
        else "Tap a game to clean RAM and play. Long-press one to remove it or open its App info."
    }

    private fun gameRow(g: Cleaner.App, icon: Drawable?): View {
        val d = resources.displayMetrics.density
        val r = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(px(12), px(10), px(12), px(10))
            background = Cyber.cut(Cyber.FIELD, Cyber.MAGENTA, d, 1.2f, 8f)
            contentDescription = "Boost and play ${g.label}"
            setOnClickListener { play(g) }
            setOnLongClickListener { rowMenu(g); true }
        }
        r.addView(ImageView(this).apply { setImageDrawable(icon) }, LinearLayout.LayoutParams(px(44), px(44)))
        r.addView(TextView(this).apply {
            text = g.label.uppercase()
            typeface = Cyber.MONO; textSize = 13f; setTextColor(Cyber.TEXT)
            maxLines = 1; ellipsize = TextUtils.TruncateAt.END
            setPadding(px(12), 0, px(8), 0)
        }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        r.addView(TextView(this).apply {
            text = "\u25B6 PLAY"
            typeface = Cyber.MONO; textSize = 12f; setTextColor(Cyber.MAGENTA)
        })
        return r
    }

    private fun rowMenu(g: Cleaner.App) {
        AlertDialog.Builder(this).setTitle(g.label)
            .setItems(arrayOf("Remove from Game Space", "App info", "Optimize game code (Shizuku)")) { _, which ->
                if (which == 2) {
                    optimizeGame(g)
                } else if (which == 0) {
                    Thread {
                        Process.setThreadPriority(Process.THREAD_PRIORITY_BACKGROUND)
                        Games.setListed(this, g.pkg, false)
                        runOnUiThread { if (alive()) loadGames() }
                    }.start()
                } else {
                    try {
                        startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${g.pkg}")))
                    } catch (e: Exception) { toast("Can't open App info") }
                }
            }.show()
    }

    private fun optimizeGame(g: Cleaner.App) {
        if (optimizing) { toast("Another optimization is still running"); return }
        if (ShizukuHelper.state() != ShizukuHelper.State.READY) {
            toast("Start Shizuku and connect it in the Control Panel first")
            return
        }
        AlertDialog.Builder(this)
            .setTitle("Optimize ${g.label}?")
            .setMessage(
                "Asks Android to compile the game's app code now. It takes up to about 3 minutes and uses some storage; " +
                    "you can keep using the phone. It helps games with a lot of Java/Kotlin code start faster and stutter less. " +
                    "Most 3D games run mostly native code and gain little."
            )
            .setPositiveButton("Start") { _, _ ->
                optimizing = true
                val app = applicationContext
                val main = Handler(Looper.getMainLooper())
                toast("Optimizing ${g.label}...")
                Thread {
                    Process.setThreadPriority(Process.THREAD_PRIORITY_BACKGROUND)
                    val out = try { ShizukuHelper.connect(app)?.compileApp(g.pkg) } catch (e: Throwable) { null }
                    main.post {
                        optimizing = false
                        val ok = out != null && out.contains("Success", ignoreCase = true)
                        Toast.makeText(app, if (ok) "${g.label} optimized" else "Could not optimize ${g.label}", Toast.LENGTH_LONG).show()
                    }
                }.start()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun pickGames() {
        Thread {
            Process.setThreadPriority(Process.THREAD_PRIORITY_BACKGROUND)
            val apps = Cleaner.launchableApps(this)
            val have = apps.map { it.pkg }.toHashSet()
            val sel = HashSet(Games.packages(this, apps).filter { it in have })
            runOnUiThread { if (alive()) showPicker(apps, sel) }
        }.start()
    }

    private fun showPicker(apps: List<Cleaner.App>, sel: HashSet<String>) {
        val checked = BooleanArray(apps.size) { apps[it].pkg in sel }
        AlertDialog.Builder(this)
            .setTitle("These apps are games")
            .setMultiChoiceItems(apps.map { it.label }.toTypedArray(), checked) { _, i, on ->
                if (on) sel.add(apps[i].pkg) else sel.remove(apps[i].pkg)
            }
            .setPositiveButton("Save") { _, _ ->
                Games.saveList(this, sel)
                loadGames()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // ---------------------------------------------------------------- actions

    private fun play(g: Cleaner.App) {
        val now = SystemClock.elapsedRealtime()
        if (now < playLockUntil) return
        val go = Games.launchIntent(this, g.pkg)
        if (go == null) { toast("Can't open ${g.label}"); return }
        playLockUntil = now + 3_000
        toast("Boosting ${g.label}...")
        Games.boostAndLaunch(this, go, g.pkg, g.label)
    }

    private fun boostNow() {
        boostBtn.isEnabled = false
        toast("Boosting...")
        val hard = Games.hardWanted(this) && ShizukuHelper.state() == ShizukuHelper.State.READY
        val extreme = Games.extremeWanted(this) && ShizukuHelper.state() == ShizukuHelper.State.READY
        Cleaner.boost(this, null, hard, extreme, ready = {}) { freed ->
            if (!alive()) return@boost
            boostBtn.isEnabled = true
            toast(Cleaner.special(freed)
                ?: if (freed > 0) "GAME BOOST: ~$freed MB freed" else "Nothing more to free - Android is already managing memory well")
            refresh()
        }
    }

    private fun openUsageAccess() {
        try {
            startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
        } catch (e: Exception) {
            try { startActivity(Intent(Settings.ACTION_SETTINGS)) } catch (e2: Exception) { toast("Open Settings > Apps > Special access > Usage access") }
        }
    }

    private fun askDndAccess() {
        AlertDialog.Builder(this)
            .setTitle("Allow Do Not Disturb access")
            .setMessage(
                "To silence notifications while you play, Android needs you to switch on WaterBoost in the " +
                    "Do Not Disturb access list. Tap Continue, find WaterBoost, switch it on, then come back here."
            )
            .setPositiveButton("Continue") { _, _ ->
                Cleaner.prefs(this).edit().putBoolean(Games.K_DND_ASK, true).apply()
                try {
                    startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
                } catch (e: Exception) {
                    Cleaner.prefs(this).edit().putBoolean(Games.K_DND_ASK, false).apply()
                    try {
                        startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
                        toast("Open Notifications > Do Not Disturb access")
                    } catch (e2: Exception) { toast("Open Settings > Notifications > Do Not Disturb access") }
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // ---------------------------------------------------------------- state

    private val autoListener = CompoundButton.OnCheckedChangeListener { _, on ->
        Cleaner.prefs(this).edit().putBoolean(Games.K_AUTO, on).apply()
    }
    private val dndListener = CompoundButton.OnCheckedChangeListener { _, on ->
        if (!on) {
            Cleaner.prefs(this).edit().putBoolean(Games.K_DND, false).apply()
        } else if (Games.dndAccess(this)) {
            Cleaner.prefs(this).edit().putBoolean(Games.K_DND, true).apply()
        } else {
            h.post { syncSwitches() }   // stays off until the access is granted
            askDndAccess()
        }
    }
    private val hardListener = CompoundButton.OnCheckedChangeListener { _, on ->
        val p = Cleaner.prefs(this)
        if (!on) {
            p.edit().putBoolean(Games.K_HARD, false).apply()
        } else if (ShizukuHelper.state() != ShizukuHelper.State.READY) {
            toast("Start Shizuku and connect it in the Control Panel first")
            h.post { syncSwitches() }
        } else {
            h.post { syncSwitches() }   // switched on only if the user confirms
            AlertDialog.Builder(this)
                .setTitle("Force-stop heavy apps before a game?")
                .setMessage(
                    "A force-stopped app stops getting notifications until you open it again, and its alarms, " +
                        "reminders and music stop. Apps in Protected apps are never touched, and nothing is stopped " +
                        "while music or a call is playing."
                )
                .setPositiveButton("Turn on") { _, _ ->
                    p.edit().putBoolean(Games.K_HARD, true).apply()
                    syncSwitches()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
    }

    /** Shared by the two "needs Shizuku" options: on only if Shizuku is connected and the user confirms. */
    private fun shizukuOption(key: String, on: Boolean, title: String, message: String?) {
        val p = Cleaner.prefs(this)
        if (!on) {
            p.edit().putBoolean(key, false).apply()
        } else if (ShizukuHelper.state() != ShizukuHelper.State.READY) {
            toast("Start Shizuku and connect it in the Control Panel first")
            h.post { syncSwitches() }
        } else if (message == null) {
            p.edit().putBoolean(key, true).apply()
        } else {
            h.post { syncSwitches() }   // switched on only if the user confirms
            AlertDialog.Builder(this).setTitle(title).setMessage(message)
                .setPositiveButton("Turn on") { _, _ -> p.edit().putBoolean(key, true).apply(); syncSwitches() }
                .setNegativeButton("Cancel", null)
                .show()
        }
    }
    private val extremeListener = CompoundButton.OnCheckedChangeListener { _, on ->
        shizukuOption(
            Games.K_EXTREME, on, "Clear every cached process before a game?",
            "Cached processes are apps that are not doing anything; Android would close them anyway when memory runs low. " +
                "This does it now, for every app including system ones. Alarms, notifications and music are not affected."
        )
    }
    private val psaveListener = CompoundButton.OnCheckedChangeListener { _, on ->
        shizukuOption(Games.K_PSAVE, on, "", null)
    }

    private fun syncSwitches() {
        val p = Cleaner.prefs(this)
        autoSw.setOnCheckedChangeListener(null)
        autoSw.isChecked = Games.autoBoost(this)
        autoSw.setOnCheckedChangeListener(autoListener)
        dndSw.setOnCheckedChangeListener(null)
        dndSw.isChecked = p.getBoolean(Games.K_DND, false) && Games.dndAccess(this)
        dndSw.setOnCheckedChangeListener(dndListener)
        hardSw.setOnCheckedChangeListener(null)
        hardSw.isChecked = p.getBoolean(Games.K_HARD, false)
        hardSw.setOnCheckedChangeListener(hardListener)
        extremeSw.setOnCheckedChangeListener(null)
        extremeSw.isChecked = p.getBoolean(Games.K_EXTREME, false)
        extremeSw.setOnCheckedChangeListener(extremeListener)
        psaveSw.setOnCheckedChangeListener(null)
        psaveSw.isChecked = p.getBoolean(Games.K_PSAVE, false)
        psaveSw.setOnCheckedChangeListener(psaveListener)
        dndHint.stable = if (Games.dndAccess(this))
            "Uses Priority only: calls and alarms you allow in Do Not Disturb still come through. It is switched off again when you stop playing."
        else "Needs Do Not Disturb access (Android asks you once)."
    }

    private fun updateDetection() {
        if (Games.usageAccess(this)) {
            usageStatus.stable = "\u25CF Usage access is on"
            usageStatus.setTextColor(Cyber.GREEN)
            usageHint.stable = "Game mode ends by itself a few seconds after you leave the game."
            usageBtn.stable = "Open usage access settings"
        } else {
            usageStatus.stable = "\u25CF Usage access is off"
            usageStatus.setTextColor(Cyber.YELLOW)
            usageHint.stable = "Without it, game mode ends when you return to the WaterBoost home screen, " +
                "or when you tap End. Turn it on for exact detection (find WaterBoost in the list)."
            usageBtn.stable = "Turn on usage access"
        }
        batteryBtn.stable = if (Device.ignoringBattery(this)) "Battery: unrestricted \u2713" else "Battery: allow unrestricted"
    }

    /** Temperature, battery saver and Android's own thermal state: what decides how fast the chip may run right now. */
    private fun updateHeat() {
        val tenths = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            ?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, -1) ?: -1
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        val saver = pm.isPowerSaveMode
        val status = if (Build.VERSION.SDK_INT >= 29) pm.currentThermalStatus else 0
        val thermal = when (status) {
            0 -> ""
            1 -> "  \u2022  Thermal: light"
            2 -> "  \u2022  Thermal: moderate, slowing down"
            else -> "  \u2022  Thermal: severe, slowing down a lot"
        }
        val temp = if (tenths >= 0) "Phone ${tenths / 10}\u00B0C" else "Phone temperature unknown"
        heatLine.stable = "$temp  \u2022  Battery saver ${if (saver) "ON (slows the phone)" else "off"}$thermal"
        heatLine.setTextColor(
            when {
                status >= 2 || tenths >= 450 -> Cyber.RED
                saver || tenths >= 420 || status == 1 -> Cyber.YELLOW
                else -> Cyber.GREEN
            }
        )
    }

    private fun gameName(pkg: String): String = try {
        packageManager.getApplicationInfo(pkg, 0).loadLabel(packageManager).toString()
    } catch (e: Exception) { pkg }

    private fun refresh() {
        val m = Cleaner.info(this)
        val used = 1f - m.availMem.toFloat() / m.totalMem
        ramBar.value = used
        val p = Cleaner.prefs(this)
        val last = p.getLong("freed", -1L)
        val lastMode = p.getString("mode", null)
        ramInfo.stable = "Free ${m.availMem shr 20} MB of ${m.totalMem shr 20} MB" +
            if (last >= 0 && lastMode != null) "\nLast boost: ~$last MB freed ($lastMode)" else ""
        ramInfo.setTextColor(Cyber.alertColor(used))
        updateHeat()
        if (GameService.running) {
            val pkg = GameService.gamePkg
            if (pkg != shownPkg) { shownPkg = pkg; shownName = if (pkg == null) "" else gameName(pkg) }
            sessionLine.stable = "\u25CF GAME MODE ON" + if (shownName.isEmpty()) "" else "  //  $shownName"
            sessionLine.setTextColor(Cyber.GREEN)
            endBtn.visibility = View.VISIBLE
        } else {
            sessionLine.stable = "\u25CF Game mode is off. Open a game below."
            sessionLine.setTextColor(Cyber.DIM)
            endBtn.visibility = View.GONE
        }
        updateDetection()
    }

    override fun onResume() {
        super.onResume()
        Games.uiVisible = true
        Games.recoverStale(this)
        val p = Cleaner.prefs(this)
        // Back from the Do Not Disturb access screen: switch the option on if the access was granted there.
        if (p.getBoolean(Games.K_DND_ASK, false)) {
            p.edit().putBoolean(Games.K_DND_ASK, false).apply()
            if (Games.dndAccess(this)) {
                p.edit().putBoolean(Games.K_DND, true).apply()
                toast("Notifications will be silenced while you play")
            }
        }
        syncSwitches()
        refresh()
        loadGames()
        h.postDelayed(tick, 1000)
    }

    override fun onPause() {
        Games.uiVisible = false
        h.removeCallbacks(tick)
        super.onPause()
    }
}
