package com.waterboost.app

import android.content.ComponentName
import android.content.Context
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.os.IBinder
import rikka.shizuku.Shizuku

object ShizukuHelper {
    enum class State { NOT_RUNNING, NEEDS_PERMISSION, READY }

    const val PKG = "moe.shizuku.privileged.api"
    private const val REQ = 4242

    @Volatile private var shell: IShell? = null
    @Volatile private var binding = false

    private val conn = object : ServiceConnection {
        override fun onServiceConnected(n: ComponentName?, b: IBinder?) {
            shell = if (b != null && b.pingBinder()) IShell.Stub.asInterface(b) else null
            binding = false
        }
        override fun onServiceDisconnected(n: ComponentName?) { shell = null; binding = false }
    }

    fun isInstalled(c: Context): Boolean =
        runCatching { c.packageManager.getPackageInfo(PKG, 0); true }.getOrDefault(false)

    fun state(): State = try {
        when {
            !Shizuku.pingBinder() -> State.NOT_RUNNING
            Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED -> State.READY
            else -> State.NEEDS_PERMISSION
        }
    } catch (e: Throwable) {
        State.NOT_RUNNING
    }

    fun requestPermission() { runCatching { Shizuku.requestPermission(REQ) } }

    /** Blocking (up to ~4 s) - call from a background thread. Returns null if Shizuku isn't usable. */
    fun connect(c: Context): IShell? {
        shell?.let { if (it.asBinder().pingBinder()) return it }
        if (state() != State.READY) return null
        if (!binding) {
            binding = true
            try {
                Shizuku.bindUserService(
                    Shizuku.UserServiceArgs(ComponentName(c.packageName, ShellService::class.java.name))
                        .processNameSuffix("shell")
                        .daemon(false)
                        .version(6),   // bump when ShellService/IShell change so Shizuku restarts it
                    conn
                )
            } catch (e: Throwable) {
                binding = false
                return null
            }
        }
        repeat(40) {
            Thread.sleep(100)
            shell?.let { return it }
        }
        binding = false
        return null
    }

    /** package -> real RSS memory in MB, for the given packages only. */
    fun memoryByPackage(sh: IShell, pkgs: Set<String>): Map<String, Long> {
        val kb = HashMap<String, Long>()
        for (line in sh.processList().lineSequence()) {
            val parts = line.trim().split(Regex("\\s+"))
            if (parts.size < 2) continue
            val rss = parts[0].toLongOrNull() ?: continue     // skips the header line
            val pkg = parts[1].substringBefore(':')            // "com.app:service" -> "com.app"
            if (pkg in pkgs) kb[pkg] = (kb[pkg] ?: 0L) + rss
        }
        return kb.mapValues { it.value / 1024 }
    }
}
