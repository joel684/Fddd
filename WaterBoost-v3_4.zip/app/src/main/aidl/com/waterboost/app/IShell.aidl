package com.waterboost.app;

// Runs inside Shizuku's shell-privileged process. Deliberately narrow: no "run any command" method.
interface IShell {
    void destroy() = 16777114;          // transaction id reserved by Shizuku
    String processList() = 1;           // "RSS(KB) NAME" per running process
    void killPackages(in String[] pkgs) = 2;     // am kill        (safe: only expendable processes)
    void forceStop(in String[] pkgs) = 3;        // am force-stop  (hard stop)
    void trimCaches() = 4;                       // pm trim-caches (clears cache of all apps)
    void killAllBackground() = 6;                // am kill-all  (every cached background process; foreground apps, music and calls are untouched)
    void setBatterySaver(boolean on) = 7;        // settings put global low_power 1|0  (battery saver throttles the phone)
    String compileApp(in String pkg) = 5;        // cmd package compile -m speed -f  (fully precompiles one app's code)
}
