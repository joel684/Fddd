package com.waterboost.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** Restarts auto mode after a reboot if the user had it switched on. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        if (i.action == Intent.ACTION_BOOT_COMPLETED && Cleaner.prefs(c).getBoolean("auto", false)) {
            CleanerService.start(c)
        }
    }
}
