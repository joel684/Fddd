package com.waterboost.app

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.provider.Telephony
import android.telecom.TelecomManager

object Cleaner {
    private const val MIN_COOLDOWN = 60_000L
    private const val MAX_COOLDOWN = 15 * 60_000L
    private const val USEFUL_MB = 50L          // a clean that frees less than this is "not worth it"
    private const val MIN_HEAVY_MB = 40L       // Shizuku mode ignores apps using less than this
    private const val MIN_STOP_MB = 20L         // deep clean only force-stops apps that really are running
    private const val TRIM_EVERY = 30 * 60_000L // cache trimming is slow and apps rebuild caches, so rarely

    @Volatile private var busy = false

    class App(val pkg: String, val label: String, val isSystem: Boolean)

    fun prefs(c: Context): SharedPreferences = c.getSharedPreferences("p", 0)

    fun info(c: Context): ActivityManager.MemoryInfo {
        val m = ActivityManager.MemoryInfo()
        (c.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager).getMemoryInfo(m)
        return m
    }

    // Default trigger = 28% of total RAM (about 1000 MB on a 4 GB phone like the Narzo 50A Prime).
    fun defaultLimitMb(c: Context): Int =
        ((info(c).totalMem shr 20) * 28 / 100).toInt().coerceIn(300, 1500)

    fun userLimit(c: Context): Int = prefs(c).getInt("limit", defaultLimitMb(c)).coerceIn(300, 1500)

    // Lower of the slider value and 45% of total RAM, so 2 GB phones work.
    fun limitMb(c: Context): Long {
        val total = info(c).totalMem shr 20
        return minOf(userLimit(c).toLong(), total * 45 / 100)
    }

    // Never closed: Google services that deliver notifications, plus Realme/OPPO/Unisoc system helpers.
    private val neverKill = setOf("com.google.android.gms", "com.google.android.gsf", "com.android.vending")
    private val vendorPrefixes = listOf(
        "com.coloros.", "com.oplus.", "com.oppo.", "com.realme.", "com.heytap.", "com.nearme.",
        "com.unisoc.", "com.sprd."
    )

    /** Every app that has a launcher icon (except WaterBoost itself), sorted by name. */
    fun launchableApps(c: Context): List<App> {
        val pm = c.packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return pm.queryIntentActivities(intent, 0)
            .map {
                val f = it.activityInfo.applicationInfo.flags
                val pureSystem = (f and ApplicationInfo.FLAG_SYSTEM) != 0 &&
                    (f and ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) == 0
                App(it.activityInfo.packageName, it.loadLabel(pm).toString(), pureSystem)
            }
            .filter { it.pkg != c.packageName }
            .distinctBy { it.pkg }
            .sortedBy { it.label.lowercase() }
    }

    fun protectedApps(c: Context): Set<String> = HashSet(prefs(c).getStringSet("prot", emptySet())!!)

    fun forcePicked(c: Context): Set<String> = HashSet(prefs(c).getStringSet("fsel", emptySet())!!)

    fun forceAll(c: Context): Boolean = prefs(c).getString("fsMode", "picked") == "all"

    // Apps that would break the phone experience if killed: launcher, keyboard, SMS, dialer.
    private fun critical(c: Context): Set<String> {
        val s = HashSet<String>()
        runCatching {
            c.packageManager.resolveActivity(
                Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME),
                PackageManager.MATCH_DEFAULT_ONLY
            )?.activityInfo?.packageName?.let { s.add(it) }
        }
        runCatching {
            Settings.Secure.getString(c.contentResolver, Settings.Secure.DEFAULT_INPUT_METHOD)
                ?.substringBefore('/')?.let { s.add(it) }
        }
        runCatching { Telephony.Sms.getDefaultSmsPackage(c)?.let { s.add(it) } }
        runCatching {
            (c.getSystemService(Context.TELECOM_SERVICE) as? TelecomManager)
                ?.defaultDialerPackage?.let { s.add(it) }
        }
        return s
    }

    private fun targets(c: Context): List<String> {
        val skip = critical(c) + protectedApps(c)
        return launchableApps(c)
            .filter { a ->
                !a.isSystem && a.pkg !in skip && a.pkg !in neverKill &&
                    vendorPrefixes.none { a.pkg.startsWith(it) }
            }
            .map { it.pkg }
    }

    /**
     * Shizuku mode: measure each app's real memory use, then close only the heaviest ones,
     * stopping once roughly [needMb] has been covered (null = close every heavy app).
     * Returns false if Shizuku isn't usable, so the caller falls back to the normal method.
     */
    private fun smartKill(c: Context, pkgs: List<String>, needMb: Long?): Boolean {
        val sh = ShizukuHelper.connect(c) ?: return false
        return try {
            val mem = ShizukuHelper.memoryByPackage(sh, pkgs.toSet())
            if (mem.isEmpty()) return false
            val chosen = ArrayList<String>()
            var sum = 0L
            for (e in mem.entries.filter { it.value >= MIN_HEAVY_MB }.sortedByDescending { it.value }) {
                if (needMb != null && sum >= needMb) break
                chosen.add(e.key); sum += e.value
            }
            if (chosen.isNotEmpty()) sh.killPackages(chosen.toTypedArray())
            true
        } catch (e: Throwable) {
            false
        }
    }

    /** Shizuku only: the heaviest apps by real memory use (name, MB), or null if Shizuku isn't ready. */
    fun topApps(c: Context): List<Pair<String, Long>>? {
        val sh = ShizukuHelper.connect(c) ?: return null
        return try {
            val names = launchableApps(c).associate { it.pkg to it.label }
            ShizukuHelper.memoryByPackage(sh, names.keys)
                .entries.sortedByDescending { it.value }.take(15)
                .map { (names[it.key] ?: it.key) to it.value }
        } catch (e: Throwable) {
            null
        }
    }

    /**
     * Stops background processes of the chosen apps and clears our own cache. Never touches app data.
     * [done] is called on the main thread with the MB of RAM that actually became free.
     */
    fun clean(c: Context, needMb: Long? = null, done: ((Long) -> Unit)? = null) {
        if (busy) return
        busy = true
        val ctx = c.applicationContext
        Thread {
            try {
                val before = info(ctx).availMem
                val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
                val list = targets(ctx)
                val smart = prefs(ctx).getBoolean("shizuku", false) && smartKill(ctx, list, needMb)
                if (!smart) list.forEach { am.killBackgroundProcesses(it) }
                ctx.cacheDir.deleteRecursively()
                ctx.externalCacheDir?.deleteRecursively()

                Thread.sleep(1500)   // give the system a moment to reclaim the memory
                val freed = ((info(ctx).availMem - before) shr 20).coerceAtLeast(0)

                // Adaptive back-off: if cleaning achieves little (apps just restart), wait longer next time.
                val p = prefs(ctx)
                val cool = p.getLong("cool", MIN_COOLDOWN)
                val next = if (freed < USEFUL_MB) minOf(cool * 2, MAX_COOLDOWN) else MIN_COOLDOWN
                p.edit().putLong("freed", freed).putLong("cool", next)
                    .putString("mode", if (smart) "Shizuku" else "standard").apply()

                Handler(Looper.getMainLooper()).post { done?.invoke(freed) }
            } finally {
                busy = false
            }
        }.start()
    }

    // Apps eligible for force-stop: the user's own list, or every non-protected app if scope is "all".
    private fun forceTargets(c: Context): List<String> {
        val all = targets(c)
        if (forceAll(c)) return all
        val picked = forcePicked(c)
        return all.filter { it in picked }
    }

    /**
     * Deep clean (needs Shizuku): force-stops the chosen apps that are running and, if enabled,
     * clears the cache of all apps. Without Shizuku it falls back to a normal clean.
     * [canRun] is checked right before anything is stopped, so an app the user just opened is never hit.
     * [done] gets the MB freed, on the main thread.
     */
    fun deepClean(c: Context, canRun: () -> Boolean = { true }, done: ((Long) -> Unit)? = null) {
        if (busy) return
        busy = true
        val ctx = c.applicationContext
        Thread {
            try {
                val p = prefs(ctx)
                val before = info(ctx).availMem
                var deep = false
                val sh = ShizukuHelper.connect(ctx)
                if (sh != null && canRun()) {
                    try {
                        val running = ShizukuHelper.memoryByPackage(sh, forceTargets(ctx).toSet())
                        val stop = running.filter { it.value >= MIN_STOP_MB }.keys.toTypedArray()
                        if (stop.isNotEmpty() && canRun()) sh.forceStop(stop)
                        val now = System.currentTimeMillis()
                        if (p.getBoolean("trim", false) && now - p.getLong("lastTrim", 0) > TRIM_EVERY) {
                            sh.trimCaches()
                            p.edit().putLong("lastTrim", now).apply()
                        }
                        deep = true
                    } catch (e: Throwable) {
                        deep = false
                    }
                }
                if (!deep && canRun()) {
                    val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
                    targets(ctx).forEach { am.killBackgroundProcesses(it) }
                }
                Thread.sleep(1500)
                val freed = ((info(ctx).availMem - before) shr 20).coerceAtLeast(0)
                p.edit().putLong("freed", freed)
                    .putString("mode", if (deep) "deep clean" else "standard").apply()
                Handler(Looper.getMainLooper()).post { done?.invoke(freed) }
            } finally {
                busy = false
            }
        }.start()
    }

    /** Called by the launcher shortly after you reach the home screen. Acts only if RAM is actually low. */
    fun autoDeep(c: Context, canRun: () -> Boolean) {
        val p = prefs(c)
        if (!p.getBoolean("autoDeep", false)) return
        val now = System.currentTimeMillis()
        if ((info(c).availMem shr 20) >= limitMb(c)) return
        if (now - p.getLong("lastDeep", 0) < 2 * 60_000) return
        p.edit().putLong("lastDeep", now).apply()
        deepClean(c, canRun)
    }

    // Cleans only if free RAM is under the limit and the (adaptive) cooldown has passed.
    fun auto(c: Context) {
        // Nothing to gain while the screen is off, and Realme UI already trims apps then.
        if (!(c.getSystemService(Context.POWER_SERVICE) as PowerManager).isInteractive) return
        val p = prefs(c)
        val now = System.currentTimeMillis()
        val free = info(c).availMem shr 20
        val cool = p.getLong("cool", MIN_COOLDOWN)
        if (free < limitMb(c) && now - p.getLong("last", 0) > cool) {
            p.edit().putLong("last", now).apply()
            clean(c, needMb = (limitMb(c) - free) * 3 / 2)   // only close about as much as we're short
        }
    }
}
