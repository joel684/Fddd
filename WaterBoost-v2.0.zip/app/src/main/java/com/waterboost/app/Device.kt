package com.waterboost.app

import android.app.Activity
import android.content.ComponentName
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings

/** Everything device-specific lives here, so other phones can be added without touching the rest. */
object Device {
    /** Realme and OPPO share the ColorOS / Realme UI background manager that kills apps aggressively. */
    val isColorOsFamily: Boolean by lazy {
        val m = "${Build.MANUFACTURER} ${Build.BRAND}".lowercase()
        "realme" in m || "oppo" in m
    }

    fun name(): String = "${Build.MANUFACTURER} ${Build.MODEL}"

    // Realme UI / ColorOS screens for auto-start & background permission. Names differ between versions,
    // so we try each one and fall back to standard Android settings.
    private val oemScreens = listOf(
        "com.coloros.safecenter" to "com.coloros.safecenter.permission.startup.StartupAppListActivity",
        "com.coloros.safecenter" to "com.coloros.safecenter.startupapp.StartupAppListActivity",
        "com.oppo.safe" to "com.oppo.safe.permission.startup.StartupAppListActivity",
        "com.coloros.oppoguardelf" to "com.coloros.powermanager.fuelgaue.PowerUsageModelActivity"
    )

    /** Opens the best "let this app keep running" screen and returns a hint about what to do there. */
    fun openKeepAlive(a: Activity): String {
        if (isColorOsFamily) {
            for ((pkg, cls) in oemScreens) {
                try {
                    a.startActivity(Intent().setComponent(ComponentName(pkg, cls)))
                    return "Allow WaterBoost to auto-start and run in background"
                } catch (e: Exception) {
                    // not on this Realme UI version - try the next one
                }
            }
        }
        try {
            a.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            return "Find WaterBoost and choose Don't optimize"
        } catch (e: Exception) {
            // fall through
        }
        a.startActivity(
            Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${a.packageName}"))
        )
        return "Open Battery and allow background activity"
    }
}
