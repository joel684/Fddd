package com.waterboost.app

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.widget.*
import rikka.shizuku.Shizuku

class MainActivity : Activity() {
    private lateinit var wave: WaveView
    private lateinit var info: TextView
    private lateinit var limitLabel: TextView
    private lateinit var sw: Switch
    private lateinit var shizukuSw: Switch
    private lateinit var cleanBtn: Button
    private lateinit var scopeBtn: Button
    private val h = Handler(Looper.getMainLooper())
    private val tick = object : Runnable {
        override fun run() { refresh(); h.postDelayed(this, 1000) }
    }
    private val autoListener = CompoundButton.OnCheckedChangeListener { _, on ->
        Cleaner.prefs(this).edit().putBoolean("auto", on).apply()
        setAuto(on)
    }
    private val shizukuListener = CompoundButton.OnCheckedChangeListener { _, on ->
        val p = Cleaner.prefs(this)
        if (!on) {
            p.edit().putBoolean("shizuku", false).apply()
        } else when (ShizukuHelper.state()) {
            ShizukuHelper.State.READY -> p.edit().putBoolean("shizuku", true).apply()
            ShizukuHelper.State.NEEDS_PERMISSION -> {
                ShizukuHelper.requestPermission()      // result arrives in permListener
                h.post { syncShizukuSwitch() }
            }
            ShizukuHelper.State.NOT_RUNNING -> {
                val open = packageManager.getLaunchIntentForPackage(ShizukuHelper.PKG)
                if (open != null) {
                    toast("Start Shizuku first, then come back")
                    startActivity(open)
                } else {
                    toast("Install and start Shizuku first")
                }
                h.post { syncShizukuSwitch() }
            }
        }
    }
    private val permListener = Shizuku.OnRequestPermissionResultListener { _, result ->
        runOnUiThread {
            val ok = result == PackageManager.PERMISSION_GRANTED
            Cleaner.prefs(this).edit().putBoolean("shizuku", ok).apply()
            syncShizukuSwitch()
            if (!ok) toast("Shizuku permission denied")
        }
    }

    private fun px(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_LONG).show()

    private fun section(root: LinearLayout, title: String) {
        root.addView(TextView(this).apply {
            text = title; setTextColor(0xFF38BDF8.toInt()); textSize = 13f
            setPadding(0, px(24), 0, px(4))
        })
    }

    private fun button(root: LinearLayout, label: String, onClick: () -> Unit): Button {
        val b = Button(this).apply { text = label; setOnClickListener { onClick() } }
        root.addView(b)
        return b
    }

    private fun prefSwitch(root: LinearLayout, label: String, key: String): Switch {
        val s = Switch(this).apply {
            text = label; setTextColor(Color.WHITE)
            setPadding(0, px(12), 0, px(4))
            isChecked = Cleaner.prefs(this@MainActivity).getBoolean(key, false)
            setOnCheckedChangeListener { _, on ->
                Cleaner.prefs(this@MainActivity).edit().putBoolean(key, on).apply()
            }
        }
        root.addView(s)
        return s
    }

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        val p = Cleaner.prefs(this)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(px(24), px(48), px(24), px(24))
        }
        wave = WaveView(this)
        root.addView(wave, LinearLayout.LayoutParams(px(260), px(260)))

        info = TextView(this).apply {
            setTextColor(Color.WHITE); textSize = 16f; gravity = Gravity.CENTER
            setPadding(0, px(20), 0, px(20))
        }
        root.addView(info)

        cleanBtn = button(root, "Clean now") {
            cleanBtn.isEnabled = false
            toast("Cleaning...")
            Cleaner.clean(this) { freed ->
                cleanBtn.isEnabled = true
                toast(if (freed > 0) "Freed $freed MB" else "Nothing more to free - Android is already managing memory well")
                refresh()
            }
        }
        button(root, "Protected apps") { pickApps("Never close these apps", "prot") }

        // ---- Shizuku smart clean
        section(root, "SMART CLEAN")
        shizukuSw = Switch(this).apply {
            text = "Smart clean with Shizuku"
            setTextColor(Color.WHITE)
            setPadding(0, px(12), 0, 0)
        }
        root.addView(shizukuSw)
        button(root, "Top memory apps (Shizuku)") { showTopApps() }

        // ---- deep clean
        section(root, "DEEP CLEAN  (needs Shizuku)")
        button(root, "Deep clean now") { deepCleanNow() }
        prefSwitch(root, "Auto deep clean when I reach home and RAM is low", "autoDeep")
        prefSwitch(root, "Also clear cache of all apps (max every 30 min)", "trim")
        scopeBtn = button(root, "") { toggleScope() }
        updateScopeText()
        button(root, "Pick apps to force-stop") { pickApps("Force-stop these apps", "fsel") }

        // ---- auto clean
        section(root, "AUTO CLEAN")
        sw = Switch(this).apply {
            text = "Auto clean"
            setTextColor(Color.WHITE)
            setPadding(0, px(12), 0, px(12))
        }
        root.addView(sw)
        button(root, "Keep running in background") {
            toast(Device.openKeepAlive(this))
        }

        limitLabel = TextView(this).apply {
            setTextColor(0xFF94A3B8.toInt()); textSize = 13f
            setPadding(0, px(12), 0, 0)
        }
        root.addView(limitLabel)
        val sb = SeekBar(this).apply { max = 1200; progress = Cleaner.userLimit(this@MainActivity) - 300 }
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(b: SeekBar?, v: Int, user: Boolean) {
                if (!user) return
                p.edit().putInt("limit", v + 300).apply(); refresh()
            }
            override fun onStartTrackingTouch(b: SeekBar?) {}
            override fun onStopTrackingTouch(b: SeekBar?) {}
        })
        root.addView(sb, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))

        // ---- launcher
        section(root, "LAUNCHER")
        button(root, "Set WaterBoost as home app") {
            try {
                startActivity(Intent(Settings.ACTION_HOME_SETTINGS))
            } catch (e: Exception) {
                startActivity(Intent(Settings.ACTION_SETTINGS))
            }
        }
        button(root, "Preview launcher") { startActivity(Intent(this, HomeActivity::class.java)) }

        root.addView(TextView(this).apply {
            setTextColor(0xFF64748B.toInt()); textSize = 12f; gravity = Gravity.CENTER
            setPadding(0, px(20), 0, 0)
            text = Device.name() + if (Device.isColorOsFamily)
                "\nRealme UI tuning on. Tip: lock WaterBoost in Recents (card menu > Lock)." else ""
        })

        runCatching { Shizuku.addRequestPermissionResultListener(permListener) }

        // ScrollView keeps everything reachable in landscape / on small screens.
        setContentView(ScrollView(this).apply {
            setBackgroundColor(0xFF0B1220.toInt())
            isFillViewport = true
            addView(root)
        })
    }

    private fun setAuto(on: Boolean) {
        if (!on) { stopService(Intent(this, CleanerService::class.java)); return }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        CleanerService.start(this)
    }

    private fun syncShizukuSwitch() {
        shizukuSw.setOnCheckedChangeListener(null)
        shizukuSw.isChecked = Cleaner.prefs(this).getBoolean("shizuku", false) &&
            ShizukuHelper.state() == ShizukuHelper.State.READY
        shizukuSw.setOnCheckedChangeListener(shizukuListener)
    }

    private fun showTopApps() {
        Thread {
            val list = Cleaner.topApps(this)
            h.post {
                if (list == null || list.isEmpty()) {
                    toast("Turn on Shizuku first")
                } else {
                    AlertDialog.Builder(this)
                        .setTitle("Using the most memory")
                        .setItems(list.map { "${it.first} - ${it.second} MB" }.toTypedArray(), null)
                        .setPositiveButton("Close", null)
                        .show()
                }
            }
        }.start()
    }

    private fun deepCleanNow() {
        val p = Cleaner.prefs(this)
        if (ShizukuHelper.state() != ShizukuHelper.State.READY) {
            toast("Deep clean needs Shizuku running and allowed")
        } else if (!Cleaner.forceAll(this) && Cleaner.forcePicked(this).isEmpty() && !p.getBoolean("trim", false)) {
            toast("Pick apps to force-stop first (or turn on cache clearing)")
        } else {
            toast("Deep cleaning...")
            Cleaner.deepClean(this) { freed ->
                toast("Deep clean done - freed $freed MB of RAM")
                refresh()
            }
        }
    }

    private fun updateScopeText() {
        scopeBtn.text = if (Cleaner.forceAll(this)) "Force-stop scope: every app except protected"
        else "Force-stop scope: only apps I pick"
    }

    private fun toggleScope() {
        val p = Cleaner.prefs(this)
        if (Cleaner.forceAll(this)) {
            p.edit().putString("fsMode", "picked").apply()
            updateScopeText()
        } else {
            AlertDialog.Builder(this)
                .setTitle("Force-stop every app?")
                .setMessage(
                    "A force-stopped app stops receiving notifications until you open it again, and its " +
                        "alarms, reminders and music stop. Add your messaging, alarm and music apps to " +
                        "\"Protected apps\" first."
                )
                .setPositiveButton("Use every app") { _, _ ->
                    p.edit().putString("fsMode", "all").apply()
                    updateScopeText()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
    }

    private fun pickApps(title: String, key: String) {
        val apps = Cleaner.launchableApps(this)
        val sel = HashSet(Cleaner.prefs(this).getStringSet(key, emptySet())!!)
        val checked = BooleanArray(apps.size) { apps[it].pkg in sel }
        AlertDialog.Builder(this)
            .setTitle(title)
            .setMultiChoiceItems(apps.map { it.label }.toTypedArray(), checked) { _, i, on ->
                if (on) sel.add(apps[i].pkg) else sel.remove(apps[i].pkg)
            }
            .setPositiveButton("Save") { _, _ ->
                Cleaner.prefs(this).edit().putStringSet(key, HashSet(sel)).apply()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun refresh() {
        val m = Cleaner.info(this)
        val p = Cleaner.prefs(this)
        wave.target = 1f - m.availMem.toFloat() / m.totalMem
        wave.contentDescription = "RAM used ${(wave.target * 100).toInt()} percent"
        val last = if (p.contains("freed"))
            "\nLast clean freed ${p.getLong("freed", 0)} MB (${p.getString("mode", "standard")})" else ""
        val shizuku = when (ShizukuHelper.state()) {
            ShizukuHelper.State.READY -> "ready"
            ShizukuHelper.State.NEEDS_PERMISSION -> "needs permission"
            ShizukuHelper.State.NOT_RUNNING ->
                if (ShizukuHelper.isInstalled(this)) "not running" else "not installed"
        }
        info.text = "Free ${m.availMem shr 20} MB of ${m.totalMem shr 20} MB$last\nShizuku: $shizuku"
        limitLabel.text = "Clean when free RAM is below ${Cleaner.limitMb(this)} MB (300 - 1500)"
    }

    override fun onResume() {
        super.onResume()
        // Sync the switch with stored state (the notification's "Turn off" button can change it).
        sw.setOnCheckedChangeListener(null)
        val on = Cleaner.prefs(this).getBoolean("auto", false)
        sw.isChecked = on
        sw.setOnCheckedChangeListener(autoListener)
        syncShizukuSwitch()
        if (on) CleanerService.start(this)
        h.post(tick)
    }

    override fun onPause() { h.removeCallbacks(tick); super.onPause() }

    override fun onDestroy() {
        runCatching { Shizuku.removeRequestPermissionResultListener(permListener) }
        super.onDestroy()
    }
}
