package com.waterboost.app

import android.content.Context
import android.graphics.*
import android.view.View
import kotlin.math.sin

class WaveView(c: Context) : View(c) {
    var target = 0f            // RAM used, 0..1
    var fullScreen = false     // true = plain full-screen waves (used as the launcher fallback)
    private var level = 0f
    private var phase = 0f
    private val d = resources.displayMetrics.density
    private val back = Paint(Paint.ANTI_ALIAS_FLAG)
    private val front = Paint(Paint.ANTI_ALIAS_FLAG)
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 4 * d; color = 0x8838BDF8.toInt()
    }
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; textAlign = Paint.Align.CENTER }
    private val sub = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xCCFFFFFF.toInt(); textAlign = Paint.Align.CENTER }
    private val path = Path()
    private val clip = Path()

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        txt.textSize = w * 0.2f
        sub.textSize = w * 0.07f
        clip.reset(); clip.addCircle(w / 2f, h / 2f, w / 2f - 4 * d, Path.Direction.CW)
    }

    override fun onDraw(cv: Canvas) {
        level += (target.coerceIn(0f, 1f) - level) * 0.08f   // smooth rise and fall
        phase += 0.1f
        // Water turns blue -> amber -> red as memory fills up.
        back.color = tint(level, 0xAA38BDF8.toInt(), 0xAAFBBF24.toInt(), 0xAAF87171.toInt())
        front.color = tint(level, 0xCC0EA5E9.toInt(), 0xCCF59E0B.toInt(), 0xCCEF4444.toInt())

        if (fullScreen) {
            wave(cv, back, phase, 0.02f)
            wave(cv, front, -phase * 1.3f + 1f, 0.016f)
        } else {
            val r = width / 2f
            cv.save(); cv.clipPath(clip)
            wave(cv, back, phase, 0.035f)
            wave(cv, front, -phase * 1.3f + 1f, 0.028f)
            cv.restore()
            cv.drawCircle(r, r, r - 4 * d, ring)
            val y = r + txt.textSize / 3
            cv.drawText("${(level * 100).toInt()}%", r, y, txt)
            cv.drawText("RAM used", r, y + sub.textSize * 1.8f, sub)
        }
        postInvalidateDelayed(32)   // ~30 fps: plenty for a wave, easier on budget GPUs
    }

    private fun wave(cv: Canvas, p: Paint, ph: Float, amp: Float) {
        val w = width.toFloat(); val h = height.toFloat()
        val y0 = h * (1 - level)
        path.reset(); path.moveTo(0f, h)
        var x = 0f
        while (x <= w + 8f) {
            path.lineTo(x, y0 + sin(x / w * 9.42f + ph) * h * amp)
            x += 8f
        }
        path.lineTo(w, h); path.close()
        cv.drawPath(path, p)
    }

    private fun tint(level: Float, blue: Int, amber: Int, red: Int): Int {
        // Phones with 4 GB normally sit around 60-75% used, so only warn from ~65% upward.
        val a = mix(blue, amber, (level - 0.65f) / 0.15f)
        return mix(a, red, (level - 0.80f) / 0.12f)
    }

    private fun mix(a: Int, b: Int, t: Float): Int {
        val k = t.coerceIn(0f, 1f)
        fun ch(s: Int): Int {
            val x = (a shr s) and 0xFF
            val y = (b shr s) and 0xFF
            return (x + (y - x) * k).toInt()
        }
        return (ch(24) shl 24) or (ch(16) shl 16) or (ch(8) shl 8) or ch(0)
    }
}
