package com.waterboost.app

import android.opengl.GLES20
import android.opengl.GLSurfaceView
import java.nio.ByteBuffer
import java.nio.ByteOrder
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10
import kotlin.math.sqrt

/**
 * Real-time 3D water drawn by one fragment shader: a perspective camera looks at the sea, every pixel is
 * ray-cast onto the water plane, bent by four travelling waves, and lit with fresnel reflection, a sun glint
 * and foam. The horizon height is the RAM level and the colour goes blue -> amber -> red as RAM runs low.
 * If the shader fails to compile on some GPU, [onFail] is called and the launcher switches to a 2D wave.
 */
class WaterRenderer(private val onFail: () -> Unit) : GLSurfaceView.Renderer {
    @Volatile var used = 0.5f      // RAM used, 0..1
    @Volatile var upX = 0f         // direction of "up" on screen from the accelerometer (water stays level)
    @Volatile var upY = 1f

    private var prog = 0
    private var aPos = 0
    private var uRes = 0; private var uTime = 0; private var uLevel = 0; private var uUp = 0
    private var uDeep = 0; private var uShallow = 0; private var uChop = 0
    private var w = 1f
    private var h = 1f
    private var level = 0.5f
    private var sx = 0f
    private var sy = 1f
    private val t0 = System.nanoTime()
    private val deep = FloatArray(3)
    private val shallow = FloatArray(3)
    private val tmp = FloatArray(3)
    private val quad = ByteBuffer.allocateDirect(32).order(ByteOrder.nativeOrder()).asFloatBuffer().apply {
        put(floatArrayOf(-1f, -1f, 1f, -1f, -1f, 1f, 1f, 1f)); position(0)
    }

    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        prog = link(VERTEX, FRAGMENT)
        if (prog == 0) { onFail(); return }
        aPos = GLES20.glGetAttribLocation(prog, "aPos")
        uRes = GLES20.glGetUniformLocation(prog, "uRes")
        uTime = GLES20.glGetUniformLocation(prog, "uTime")
        uLevel = GLES20.glGetUniformLocation(prog, "uLevel")
        uUp = GLES20.glGetUniformLocation(prog, "uUp")
        uDeep = GLES20.glGetUniformLocation(prog, "uDeep")
        uShallow = GLES20.glGetUniformLocation(prog, "uShallow")
        uChop = GLES20.glGetUniformLocation(prog, "uChop")
    }

    override fun onSurfaceChanged(gl: GL10?, width: Int, height: Int) {
        GLES20.glViewport(0, 0, width, height)
        w = width.toFloat(); h = height.toFloat()
    }

    override fun onDrawFrame(gl: GL10?) {
        if (prog == 0) {
            GLES20.glClearColor(0.04f, 0.07f, 0.13f, 1f)
            GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT)
            return
        }
        level += (used.coerceIn(0f, 1f) - level) * 0.05f
        sx += (upX - sx) * 0.15f
        sy += (upY - sy) * 0.15f
        val m = sqrt(sx * sx + sy * sy).let { if (it < 0.01f) 1f else it }

        // Blue while there is plenty of RAM, amber getting low, red when almost out.
        val t1 = clamp01((level - 0.65f) / 0.15f)
        val t2 = clamp01((level - 0.80f) / 0.12f)
        mix3(BLUE_D, AMBER_D, t1, tmp); mix3(tmp, RED_D, t2, deep)
        mix3(BLUE_S, AMBER_S, t1, tmp); mix3(tmp, RED_S, t2, shallow)

        GLES20.glUseProgram(prog)
        GLES20.glUniform2f(uRes, w, h)
        GLES20.glUniform1f(uTime, (((System.nanoTime() - t0) / 1_000_000_000.0) % 3600.0).toFloat())
        GLES20.glUniform1f(uLevel, level.coerceIn(0.12f, 0.97f))
        GLES20.glUniform2f(uUp, sx / m, sy / m)
        GLES20.glUniform3f(uDeep, deep[0], deep[1], deep[2])
        GLES20.glUniform3f(uShallow, shallow[0], shallow[1], shallow[2])
        GLES20.glUniform1f(uChop, 0.6f + 0.9f * level)   // rougher sea when RAM is tight
        GLES20.glEnableVertexAttribArray(aPos)
        GLES20.glVertexAttribPointer(aPos, 2, GLES20.GL_FLOAT, false, 0, quad)
        GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
    }

    private fun clamp01(x: Float) = if (x < 0f) 0f else if (x > 1f) 1f else x

    private fun mix3(a: FloatArray, b: FloatArray, t: Float, out: FloatArray) {
        for (i in 0..2) out[i] = a[i] + (b[i] - a[i]) * t
    }

    private fun compile(type: Int, src: String): Int {
        val s = GLES20.glCreateShader(type)
        GLES20.glShaderSource(s, src)
        GLES20.glCompileShader(s)
        val ok = IntArray(1)
        GLES20.glGetShaderiv(s, GLES20.GL_COMPILE_STATUS, ok, 0)
        if (ok[0] == 0) { GLES20.glDeleteShader(s); return 0 }
        return s
    }

    private fun link(vs: String, fs: String): Int {
        val v = compile(GLES20.GL_VERTEX_SHADER, vs)
        val f = compile(GLES20.GL_FRAGMENT_SHADER, fs)
        if (v == 0 || f == 0) return 0
        val p = GLES20.glCreateProgram()
        GLES20.glAttachShader(p, v)
        GLES20.glAttachShader(p, f)
        GLES20.glLinkProgram(p)
        val ok = IntArray(1)
        GLES20.glGetProgramiv(p, GLES20.GL_LINK_STATUS, ok, 0)
        if (ok[0] == 0) { GLES20.glDeleteProgram(p); return 0 }
        return p
    }

    companion object {
        private val BLUE_D = floatArrayOf(0.02f, 0.18f, 0.42f)
        private val BLUE_S = floatArrayOf(0.08f, 0.62f, 0.85f)
        private val AMBER_D = floatArrayOf(0.45f, 0.28f, 0.02f)
        private val AMBER_S = floatArrayOf(0.98f, 0.70f, 0.10f)
        private val RED_D = floatArrayOf(0.45f, 0.03f, 0.05f)
        private val RED_S = floatArrayOf(0.95f, 0.22f, 0.20f)

        private const val VERTEX = "attribute vec2 aPos;\nvoid main() { gl_Position = vec4(aPos, 0.0, 1.0); }\n"

        private val FRAGMENT = """
#ifdef GL_FRAGMENT_PRECISION_HIGH
precision highp float;
#else
precision mediump float;
#endif
uniform vec2 uRes;
uniform float uTime;
uniform float uLevel;
uniform vec2 uUp;
uniform vec3 uDeep;
uniform vec3 uShallow;
uniform float uChop;

void addWave(vec2 p, vec2 d, float f, float s, float a, inout float h, inout vec2 g) {
    float ph = dot(d, p) * f + uTime * s;
    h += a * sin(ph);
    g += d * (a * f * cos(ph));
}

vec3 sky(vec3 d, vec3 haze) {
    float t = clamp(d.y * 1.8, 0.0, 1.0);
    vec3 top = uDeep * 0.12 + vec3(0.01, 0.015, 0.03);
    return mix(haze, top, sqrt(t));
}

void main() {
    float aspect = uRes.x / uRes.y;
    vec2 c = (gl_FragCoord.xy / uRes - 0.5) * vec2(aspect, 1.0);
    // Rotate the view so the water stays level when the phone is tilted.
    float x = c.x * uUp.y - c.y * uUp.x;
    float y = c.x * uUp.x + c.y * uUp.y;
    float hz = uLevel - 0.5;
    vec3 rd = vec3(x, y - hz, -0.9);
    vec3 haze = mix(uShallow, vec3(0.85, 0.9, 1.0), 0.25) * 0.55;
    vec3 L = normalize(vec3(0.12, 0.28, -0.9));
    vec3 col;
    if (rd.y >= -0.002) {
        vec3 d = normalize(rd);
        col = sky(d, haze);
        float glow = pow(max(dot(d, L), 0.0), 48.0);
        col += uShallow * glow * 0.6;
    } else {
        float s = 2.5 / (-rd.y);
        vec2 p = vec2(rd.x, rd.z) * s;
        float h = 0.0;
        vec2 g = vec2(0.0);
        addWave(p, normalize(vec2(1.0, 0.6)), 1.7, 1.1, 0.30 * uChop, h, g);
        addWave(p, normalize(vec2(-0.7, 1.0)), 2.9, 1.5, 0.18 * uChop, h, g);
        addWave(p, normalize(vec2(0.3, -1.0)), 4.6, 2.1, 0.10 * uChop, h, g);
        addWave(p, normalize(vec2(-1.0, -0.4)), 7.3, 2.8, 0.05 * uChop, h, g);
        float fade = exp(-s * 0.035);
        g *= fade;
        vec3 n = normalize(vec3(-g.x, 1.0, -g.y));
        vec3 v = normalize(-rd);
        vec3 r = reflect(-v, n);
        float fres = 0.04 + 0.96 * pow(1.0 - max(dot(n, v), 0.0), 5.0);
        vec3 refl = sky(vec3(r.x, abs(r.y), r.z), haze);
        float hh = clamp(0.5 + h * 1.4 * fade, 0.0, 1.0);
        vec3 body = mix(uDeep, uShallow, hh);
        float spec = pow(max(dot(r, L), 0.0), 120.0);
        float foam = smoothstep(0.62, 0.9, hh) * fade;
        col = mix(body, refl, fres) + vec3(1.0, 0.96, 0.88) * spec * 1.2 * fade + vec3(0.9) * foam * 0.25;
        col = mix(col, haze, 1.0 - exp(-s * 0.045));
    }
    gl_FragColor = vec4(col, 1.0);
}
""".trimIndent()
    }
}
