# WaterBoost

Tiny Android RAM monitor. A water-filled circle shows how much RAM is used; "Clean now" (or auto mode)
asks Android to stop background processes of your apps.

* **Clean now** - stops background processes of launchable user apps, reports MB actually freed.
* **Auto clean** - foreground service checks every 30 s; cleans when free RAM < limit (cooldown adapts).
* **Protected apps** - apps that are never touched (launcher, keyboard, SMS, dialer are always protected).
* **Shizuku (optional)** - measures each app's real memory, closes only the heaviest ones and stops once
  enough is freed. Also shows a "Top memory apps" list. Falls back to normal mode if Shizuku isn't running.
* **Launcher** - WaterBoost can be your home screen: GPU-rendered 3D water (horizon height = RAM used, blue ->
  amber -> red as RAM runs low, rougher sea when memory is tight, stays level when you tilt the phone), clock,
  dock, searchable app drawer, long-press app menu. Falls back to a 2D wave if the GPU can't run the shader.
* **Deep clean (Shizuku)** - force-stops chosen apps (or all non-protected ones) and clears every app's cache
  (`pm trim-caches`). Auto mode runs when you reach the home screen and RAM is low. Never touches app data.
* **Realme / OPPO tuning** (tested target: Realme Narzo 50A Prime, 4 GB, Android 11, Realme UI) - default
  limit scales with RAM, Google/Realme system helpers are never closed, auto mode pauses with the screen
  off, "Keep running in background" opens Realme UI's auto-start screen. Device code lives in Device.kt.
* Build: push to GitHub, run the "Build APK" workflow, download the debug APK artifact.
