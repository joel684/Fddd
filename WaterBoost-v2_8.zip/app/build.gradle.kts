plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.waterboost.app"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.waterboost.app"
        minSdk = 24
        targetSdk = 34
        versionCode = 14
        versionName = "2.8"
    }
    // One fixed key for every build. The automatic debug key is created fresh on each GitHub runner, so every APK got
    // a different signature and Android refused to install a new build over the old one.
    signingConfigs {
        create("wb") {
            storeFile = file("waterboost.p12")
            storeType = "pkcs12"
            storePassword = "waterboost"
            keyAlias = "waterboost"
            keyPassword = "waterboost"
        }
    }
    buildTypes {
        debug {
            signingConfig = signingConfigs.getByName("wb")
        }
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
            signingConfig = signingConfigs.getByName("wb")   // installable without setting up your own keystore
        }
    }
    lint { checkReleaseBuilds = false; abortOnError = false }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures { aidl = true }
}

dependencies {
    implementation("dev.rikka.shizuku:api:13.1.5")
    implementation("dev.rikka.shizuku:provider:13.1.5")
}
