package com.waterboost.app

import android.app.*
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.graphics.drawable.Icon
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock

class CleanerService : Service() {
    companion object {
        const val ACTION_STOP = "com.waterboost.app.STOP"
        private const val CHANNEL = "w2"            // new id: the old MIN-importance channel could be throttled by Realme UI
        private const val TICK_MS = 30_000L
        private const val WATCHDOG_MS = 5 * 60_000L

        fun start(c: Context) {
            val i = Intent(c, CleanerService::class.java)
            try {
                if (Build.VERSION.SDK_INT >= 26) c.startForegroundService(i) else c.startService(i)
            } catch (e: Exception) {
                // Background start not allowed right now; the watchdog alarm or next app open will retry.
            }
        }

        /** The restart alarm's PendingIntent. Built in one place so that cancelling it really cancels the armed one. */
        private fun watchdogPi(c: Context): PendingIntent {
            val i = Intent(c, CleanerService::class.java)
            val flags = PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            return if (Build.VERSION.SDK_INT >= 26) PendingIntent.getForegroundService(c, 2, i, flags)
            else PendingIntent.getService(c, 2, i, flags)
        }

        /** Switches auto mode off for good: the setting, the pending restart alarm and the service itself. */
        fun stop(c: Context) {
            val app = c.applicationContext
            Cleaner.prefs(app).edit().putBoolean("auto", false).apply()
            try { (app.getSystemService(Context.ALARM_SERVICE) as AlarmManager).cancel(watchdogPi(app)) } catch (e: Exception) { }
            app.stopService(Intent(app, CleanerService::class.java))
        }
    }

    private val h = Handler(Looper.getMainLooper())
    private var failed = false

    // The loop re-arms itself even if a check throws, so it can never die silently.
    private val tick = object : Runnable {
        override fun run() {
            // Auto mode was switched off while a restart alarm was still pending: don't keep running.
            if (!Cleaner.prefs(this@CleanerService).getBoolean("auto", false)) { shutDown(); return }
            try { Cleaner.auto(this@CleanerService) } catch (e: Throwable) { }
            armWatchdog()
            // Battery saver on: check half as often.
            val saver = try { (getSystemService(Context.POWER_SERVICE) as PowerManager).isPowerSaveMode } catch (e: Exception) { false }
            h.postDelayed(this, if (saver) TICK_MS * 2 else TICK_MS)
        }
    }

    private val screenReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            // Screen on / unlocked: forget the back-off and check again soon.
            Cleaner.resetCooldown(c)
            h.removeCallbacks(tick)
            h.postDelayed(tick, 4_000)
        }
    }

    private fun watchdogIntent(): PendingIntent = watchdogPi(this)

    private fun shutDown() {
        cancelWatchdog()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    // If Realme UI kills our process, this alarm (kept by the system) starts the service again.
    private fun armWatchdog() {
        try {
            val am = getSystemService(Context.ALARM_SERVICE) as AlarmManager
            am.setAndAllowWhileIdle(
                AlarmManager.ELAPSED_REALTIME, SystemClock.elapsedRealtime() + WATCHDOG_MS, watchdogIntent()
            )
        } catch (e: Exception) { }
    }

    private fun cancelWatchdog() {
        try { (getSystemService(Context.ALARM_SERVICE) as AlarmManager).cancel(watchdogIntent()) } catch (e: Exception) { }
    }

    override fun onCreate() {
        super.onCreate()
        if (Build.VERSION.SDK_INT >= 26) {
            getSystemService(NotificationManager::class.java).createNotificationChannel(
                NotificationChannel(CHANNEL, "Auto cleaner", NotificationManager.IMPORTANCE_LOW)
            )
        }
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val stop = PendingIntent.getService(
            this, 1, Intent(this, CleanerService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CHANNEL) else Notification.Builder(this)
        val n = b.setContentTitle("WaterBoost auto mode on")
            .setContentText("Cleans when free RAM drops below your limit")
            .setSmallIcon(R.drawable.ic_stat_drop)
            .setContentIntent(open)
            .setOngoing(true)
            .addAction(
                Notification.Action.Builder(
                    Icon.createWithResource(this, R.drawable.ic_stat_drop), "Turn off", stop
                ).build()
            )
            .build()

        try {
            if (Build.VERSION.SDK_INT >= 34) {
                startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
            } else {
                startForeground(1, n)
            }
        } catch (e: Throwable) {
            // Android 12+ can refuse a foreground start from the background (e.g. from the restart alarm).
            failed = true
            stopSelf()
            return
        }

        registerReceiver(screenReceiver, IntentFilter().apply {
            addAction(Intent.ACTION_SCREEN_ON)
            addAction(Intent.ACTION_USER_PRESENT)
        })
    }

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        if (failed) return START_NOT_STICKY
        if (i?.action == ACTION_STOP) {
            Cleaner.prefs(this).edit().putBoolean("auto", false).apply()
            shutDown()
            return START_NOT_STICKY
        }
        if (!Cleaner.prefs(this).getBoolean("auto", false)) {   // woken by an old restart alarm after auto mode was turned off
            shutDown()
            return START_NOT_STICKY
        }
        h.removeCallbacks(tick)
        h.post(tick)
        return START_STICKY
    }

    // Swiping WaterBoost out of recents must not end auto mode.
    override fun onTaskRemoved(rootIntent: Intent?) {
        if (Cleaner.prefs(this).getBoolean("auto", false)) {
            try {
                (getSystemService(Context.ALARM_SERVICE) as AlarmManager).set(
                    AlarmManager.ELAPSED_REALTIME, SystemClock.elapsedRealtime() + 3_000, watchdogIntent()
                )
            } catch (e: Exception) { }
        }
        super.onTaskRemoved(rootIntent)
    }

    override fun onDestroy() {
        h.removeCallbacks(tick)
        if (!failed) runCatching { unregisterReceiver(screenReceiver) }
        super.onDestroy()
    }

    override fun onBind(i: Intent?): IBinder? = null
}
