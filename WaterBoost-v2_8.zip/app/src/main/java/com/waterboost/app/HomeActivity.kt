package com.waterboost.app

import android.app.Activity
import android.app.AlertDialog
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.net.Uri
import android.opengl.GLSurfaceView
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.os.Process
import android.provider.MediaStore
import android.provider.Settings
import android.text.Editable
import android.text.TextUtils
import android.text.TextWatcher
import android.view.GestureDetector
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.BaseAdapter
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.GridView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextClock
import android.widget.TextView
import android.widget.Toast
import kotlin.math.abs
import kotlin.math.hypot

private class AppItem(val pkg: String, val label: String, val cn: ComponentName, val icon: Drawable)

private class AppAdapter(val ctx: Context) : BaseAdapter() {
    var all: List<AppItem> = emptyList()
    var shown: List<AppItem> = emptyList()

    fun set(list: List<AppItem>) { all = list; filter("") }

    fun filter(q: String) {
        val t = q.trim().lowercase()
        shown = if (t.isEmpty()) all else all.filter { it.label.lowercase().contains(t) }
        notifyDataSetChanged()
    }

    override fun getCount() = shown.size
    override fun getItem(i: Int): Any = shown[i]
    override fun getItemId(i: Int) = i.toLong()

    override fun getView(i: Int, v: View?, p: ViewGroup?): View {
        val d = ctx.resources.displayMetrics.density
        val cell = (v as? LinearLayout) ?: LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(0, (10 * d).toInt(), 0, (10 * d).toInt())
            addView(ImageView(ctx), LinearLayout.LayoutParams((48 * d).toInt(), (48 * d).toInt()))
            addView(TextView(ctx).apply {
                setTextColor(Cyber.TEXT); textSize = 10f; gravity = Gravity.CENTER
                typeface = Cyber.MONO; setAllCaps(true)
                maxLines = 1; ellipsize = TextUtils.TruncateAt.END
                setShadowLayer(4f, 0f, 1f, 0xAA000000.toInt())
            })
        }
        val a = shown[i]
        (cell.getChildAt(0) as ImageView).setImageDrawable(a.icon)
        (cell.getChildAt(1) as TextView).text = a.label
        return cell
    }
}

/**
 * The home screen, cyberpunk style: a neon city and sea fill the background (its height is your RAM level, the whole scene shifts
 * cyan/magenta -> yellow -> red as RAM runs low, and it stays level when you tilt the phone). A HUD panel shows RAM, tap it to clean.
 * Swipe up for the app drawer, long-press app icons for options.
 */
class HomeActivity : Activity(), SensorEventListener {
    private val h = Handler(Looper.getMainLooper())
    private val renderer = WaterRenderer { h.post { useFallback() } }
    private val appAdapter = AppAdapter(this)
    private val sm by lazy { getSystemService(SENSOR_SERVICE) as SensorManager }

    private lateinit var root: FrameLayout
    private lateinit var bgHolder: FrameLayout
    private lateinit var content: LinearLayout
    private lateinit var drawer: LinearLayout
    private lateinit var search: EditText
    private lateinit var ramText: TextView
    private lateinit var ramLabel: TextView
    private lateinit var ramPct: TextView
    private lateinit var hud: HudBar
    private lateinit var dock: LinearLayout
    private lateinit var detector: GestureDetector
    private var gl: GLSurfaceView? = null
    private var fallback: WaveView? = null
    private var apps: List<AppItem> = emptyList()
    @Volatile private var resumed = false   // read from the cleaner thread
    private var ax = 0f
    private var ay = 9.8f

    private val tick = object : Runnable {
        override fun run() { refreshStats(); h.postDelayed(this, 1000) }
    }
    // Quality ladder for the water: 30 fps -> 24 fps -> 20 fps at a lower resolution. It only steps down
    // if the measured frame rate really falls behind (a Mali-G57 MP1 on a 1080x2408 screen is easy to overload).
    private var level = 0
    private var div = 3
    private var powerSave = false
    private fun frameDelay(): Long {
        val d = when (level) { 0 -> 33L; 1 -> 42L; else -> 50L }
        return if (powerSave) maxOf(d, 50L) else d
    }
    private fun applyResolution(d: Int) {
        gl?.let { g -> g.holder.setFixedSize(maxOf(g.width / d, 2), maxOf(g.height / d, 2)) }
    }
    private val frame = object : Runnable {
        override fun run() {
            // Skip drawing while the (mostly opaque) drawer covers the water.
            if (drawer.visibility != View.VISIBLE) gl?.requestRender()
            h.postDelayed(this, frameDelay())
        }
    }
    private val deepRun = Runnable { Cleaner.autoDeep(this) { resumed } }
    private val pkgReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) { loadApps(true) }
    }

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        window.setBackgroundDrawable(ColorDrawable(Cyber.BG))
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.TRANSPARENT

        val d = resources.displayMetrics.density
        fun px(v: Int) = (v * d).toInt()
        val match = ViewGroup.LayoutParams.MATCH_PARENT
        val wrap = ViewGroup.LayoutParams.WRAP_CONTENT

        root = FrameLayout(this)
        bgHolder = FrameLayout(this)
        root.addView(bgHolder, FrameLayout.LayoutParams(match, match))
        startWater()

        // ---- home page (cyberpunk HUD layout)
        content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.START
            setPadding(px(22), px(30), px(22), px(8))
        }
        header.addView(TextView(this).apply {
            text = "// WATERBOOST_OS  v${Device.versionName(this@HomeActivity)}"
            typeface = Cyber.MONO; textSize = 11f; letterSpacing = 0.15f
            setTextColor(Cyber.MAGENTA)
        })
        // Two clocks stacked with a small offset: the magenta one behind gives the "glitch" edge.
        val clockBox = FrameLayout(this)
        clockBox.addView(TextClock(this).apply {
            format12Hour = "h:mm"; format24Hour = "HH:mm"
            typeface = Cyber.CONDENSED; textSize = 84f; includeFontPadding = false
            setTextColor(Cyber.MAGENTA)
            translationX = px(3).toFloat(); translationY = px(1).toFloat(); alpha = 0.85f
        })
        clockBox.addView(TextClock(this).apply {
            format12Hour = "h:mm"; format24Hour = "HH:mm"
            typeface = Cyber.CONDENSED; textSize = 84f; includeFontPadding = false
            setTextColor(0xFFEFFFFF.toInt())
            setShadowLayer(22f, 0f, 0f, Cyber.CYAN)
        })
        header.addView(clockBox, LinearLayout.LayoutParams(wrap, wrap))
        header.addView(TextClock(this).apply {
            format12Hour = "EEEE '//' dd.MM.yyyy"; format24Hour = "EEEE '//' dd.MM.yyyy"
            setAllCaps(true)
            typeface = Cyber.MONO; textSize = 13f; letterSpacing = 0.12f
            setTextColor(Cyber.CYAN)
        })

        val ramPanel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(px(14), px(10), px(14), px(10))
            background = Cyber.cut(Cyber.PANEL, Cyber.CYAN, d)
            setOnClickListener { quickClean() }
            setOnLongClickListener { openSettings(); true }
        }
        val ramRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        ramLabel = TextView(this).apply {
            text = "RAM_USAGE"
            typeface = Cyber.MONO; textSize = 12f; letterSpacing = 0.15f
            setTextColor(Cyber.CYAN)
        }
        ramPct = TextView(this).apply {
            typeface = Cyber.MONO; textSize = 20f
            setTextColor(Cyber.CYAN)
        }
        ramRow.addView(ramLabel, LinearLayout.LayoutParams(0, wrap, 1f))
        ramRow.addView(ramPct, LinearLayout.LayoutParams(wrap, wrap))
        ramPanel.addView(ramRow, LinearLayout.LayoutParams(match, wrap))
        hud = HudBar(this)
        ramPanel.addView(hud, LinearLayout.LayoutParams(match, px(10)).apply {
            topMargin = px(6); bottomMargin = px(6)
        })
        ramText = TextView(this).apply {
            typeface = Cyber.MONO; textSize = 11f; letterSpacing = 0.08f
            setTextColor(Cyber.DIM)
        }
        ramPanel.addView(ramText)
        header.addView(ramPanel, LinearLayout.LayoutParams(px(270), wrap).apply { topMargin = px(18) })
        content.addView(header, LinearLayout.LayoutParams(match, wrap))
        content.addView(View(this), LinearLayout.LayoutParams(match, 0, 1f))

        dock = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(px(12), px(12), px(12), px(12))
            background = Cyber.cut(Cyber.PANEL, Cyber.MAGENTA, d, 1.5f, 14f)
        }
        content.addView(dock, LinearLayout.LayoutParams(wrap, wrap).apply {
            gravity = Gravity.CENTER_HORIZONTAL; bottomMargin = px(12)
        })
        content.addView(TextView(this).apply {
            text = "\u25B2  ALL_APPS"
            typeface = Cyber.MONO; textSize = 12f; letterSpacing = 0.18f; gravity = Gravity.CENTER
            setTextColor(Cyber.YELLOW)
            setPadding(px(24), px(9), px(24), px(9))
            background = Cyber.cut(0xCC07080F.toInt(), Cyber.YELLOW, d, 1.2f, 8f)
            setOnClickListener { openDrawer() }
        }, LinearLayout.LayoutParams(wrap, wrap).apply {
            gravity = Gravity.CENTER_HORIZONTAL; bottomMargin = px(8)
        })

        detector = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent): Boolean = true
            override fun onFling(e1: MotionEvent?, e2: MotionEvent, vx: Float, vy: Float): Boolean {
                if (vy < -900f && abs(vy) > abs(vx)) { openDrawer(); return true }
                return false
            }
            override fun onLongPress(e: MotionEvent) { openSettings() }
        })
        content.setOnTouchListener { _, e -> detector.onTouchEvent(e) }
        root.addView(content, FrameLayout.LayoutParams(match, match))
        root.addView(ScanlineView(this), FrameLayout.LayoutParams(match, match))

        // ---- app drawer
        drawer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xF5060812.toInt())
            visibility = View.GONE
        }
        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(px(16), px(16), px(8), px(8))
        }
        search = EditText(this).apply {
            hint = "> SEARCH_APPS"
            setHintTextColor(Cyber.DIM); setTextColor(Cyber.CYAN)
            typeface = Cyber.MONO; textSize = 14f
            background = Cyber.cut(Cyber.FIELD, Cyber.CYAN, d, 1.2f, 8f)
            setPadding(px(14), px(10), px(14), px(10))
            setSingleLine(); imeOptions = EditorInfo.IME_ACTION_SEARCH
            addTextChangedListener(object : TextWatcher {
                override fun afterTextChanged(s: Editable?) { appAdapter.filter(s?.toString() ?: "") }
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            })
            setOnEditorActionListener { _, _, _ ->
                if (appAdapter.shown.size == 1) launch(appAdapter.shown[0])
                true
            }
        }
        top.addView(search, LinearLayout.LayoutParams(0, wrap, 1f))
        top.addView(TextView(this).apply {
            text = "\u2715"; textSize = 20f; setTextColor(Cyber.MAGENTA); typeface = Cyber.MONO
            setPadding(px(16), px(8), px(16), px(8))
            setOnClickListener { closeDrawer() }
        })
        drawer.addView(top, LinearLayout.LayoutParams(match, wrap))
        drawer.addView(Cyber.neonLine(this), LinearLayout.LayoutParams(match, px(2)))
        val grid = GridView(this)
        grid.numColumns = 4
        grid.adapter = appAdapter
        grid.setSelector(ColorDrawable(Color.TRANSPARENT))
        grid.isVerticalScrollBarEnabled = false
        grid.setPadding(px(8), 0, px(8), px(8))
        grid.setOnItemClickListener { _, _, pos, _ -> launch(appAdapter.shown[pos]) }
        grid.setOnItemLongClickListener { _, _, pos, _ -> showMenu(appAdapter.shown[pos]); true }
        drawer.addView(grid, LinearLayout.LayoutParams(match, 0, 1f))
        root.addView(drawer, FrameLayout.LayoutParams(match, match))

        root.setOnApplyWindowInsetsListener { _, ins ->
            val l = ins.systemWindowInsetLeft; val t = ins.systemWindowInsetTop
            val r = ins.systemWindowInsetRight; val b = ins.systemWindowInsetBottom
            content.setPadding(l, t, r, b)
            drawer.setPadding(l, t, r, b)
            ins
        }
        setContentView(root)
        loadApps(true)
    }

    // ---------------------------------------------------------------- water

    private fun startWater() {
        try {
            val g = GLSurfaceView(this)
            g.setEGLContextClientVersion(2)
            g.setEGLConfigChooser(false)   // no depth buffer: the water is 2D, so skip memory bandwidth it never uses
            g.setRenderer(renderer)
            g.renderMode = GLSurfaceView.RENDERMODE_WHEN_DIRTY
            // Aim for about 360 px across (1080 px screen -> one third), so the GPU shades ~1/9 of the pixels.
            g.post {
                div = maxOf(2, Math.ceil(g.width / 380.0).toInt())
                applyResolution(div)
            }
            gl = g
            bgHolder.addView(g, FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        } catch (e: Throwable) {
            useFallback()
        }
    }

    /** Used only if the GPU can't run the 3D shader: plain 2D waves instead. */
    private fun useFallback() {
        if (fallback != null) return
        gl = null
        bgHolder.removeAllViews()
        val w = WaveView(this).apply { fullScreen = true }
        fallback = w
        bgHolder.addView(w, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
    }

    private fun refreshStats() {
        powerSave = try { (getSystemService(POWER_SERVICE) as PowerManager).isPowerSaveMode } catch (e: Exception) { false }
        val ms = renderer.measuredMs
        if (ms > 0f && level < 2 && drawer.visibility != View.VISIBLE && ms > frameDelay() * 1.4f) {
            level++
            if (level == 2) applyResolution(div + 1)
            renderer.resetStats()
        }
        val m = Cleaner.info(this)
        val used = 1f - m.availMem.toFloat() / m.totalMem
        renderer.used = used
        fallback?.target = used
        val col = Cyber.alertColor(used)
        ramPct.text = "${(used * 100).toInt()}%"
        ramPct.setTextColor(col)
        ramLabel.setTextColor(col)
        hud.value = used
        ramText.text = "${m.availMem shr 20} MB FREE // TAP TO PURGE"
    }

    // ---------------------------------------------------------------- apps

    private fun toBitmapDrawable(src: Drawable, size: Int): Drawable {
        val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        src.setBounds(0, 0, size, size)
        src.draw(Canvas(bmp))
        return BitmapDrawable(resources, bmp)
    }

    // The built-in Control Panel tile: dark disc, neon ring (magenta ghost + cyan) and a cyan water drop.
    private fun controlIcon(size: Int): Drawable {
        val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val cv = Canvas(bmp)
        val sz = size.toFloat()
        val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF0A0F1E.toInt() }
        cv.drawCircle(sz / 2f, sz / 2f, sz / 2f, fill)
        val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = sz * 0.07f }
        val r = sz / 2f - sz * 0.06f
        ring.color = Cyber.MAGENTA
        cv.drawCircle(sz / 2f + sz * 0.03f, sz / 2f + sz * 0.02f, r, ring)
        ring.color = Cyber.CYAN
        cv.drawCircle(sz / 2f, sz / 2f, r, ring)
        getDrawable(R.drawable.ic_stat_drop)?.mutate()?.let {
            it.setTint(Cyber.CYAN)
            val pad = (sz * 0.27f).toInt()
            it.setBounds(pad, pad, size - pad, size - pad)
            it.draw(cv)
        }
        return BitmapDrawable(resources, bmp)
    }

    private fun isControl(a: AppItem) = a.cn.className == MainActivity::class.java.name

    @Volatile private var appSig = ""    // which launcher activities the current list was built from
    private var loading = false
    private var reloadWanted = false
    private var reloadForce = false

    /**
     * Reads the launchable apps in the background. Without [force] it does nothing when the set of apps is the same as
     * last time, so it is cheap to call whenever the home screen comes back: the install/uninstall receiver is only
     * registered while the screen is visible, so changes made in the meantime (Play Store, Settings) were missed.
     */
    private fun loadApps(force: Boolean = false) {
        if (loading) { reloadWanted = true; reloadForce = reloadForce || force; return }
        loading = true
        Thread {
            Process.setThreadPriority(Process.THREAD_PRIORITY_BACKGROUND)
            try {
                val pm = packageManager
                val found = pm.queryIntentActivities(
                    Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0
                ).filter { it.activityInfo.packageName != packageName }
                val sig = found.map { it.activityInfo.packageName + "/" + it.activityInfo.name }.sorted().joinToString(",")
                if (force || sig != appSig) {
                    val size = (48 * resources.displayMetrics.density).toInt()
                    val control = AppItem(
                        packageName, "Control Panel",
                        ComponentName(packageName, MainActivity::class.java.name), controlIcon(size)
                    )
                    val others = found.map { ri ->
                        AppItem(
                            ri.activityInfo.packageName,
                            ri.loadLabel(pm).toString(),
                            ComponentName(ri.activityInfo.packageName, ri.activityInfo.name),
                            toBitmapDrawable(ri.loadIcon(pm), size)
                        )
                    }.sortedBy { it.label.lowercase() }
                    val list = listOf(control) + others   // Control Panel is always the first tile in the drawer
                    h.post { apps = list; appSig = sig; appAdapter.set(list); renderDock() }
                }
            } catch (e: Throwable) {
                // keep showing the list we already have
            } finally {
                h.post {
                    loading = false
                    if (reloadWanted) {
                        val f = reloadForce
                        reloadWanted = false; reloadForce = false
                        loadApps(f)
                    }
                }
            }
        }.start()
    }

    private fun launch(a: AppItem) {
        closeDrawer()
        try {
            startActivity(
                Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER).setComponent(a.cn)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
            )
        } catch (e: Exception) {
            Toast.makeText(this, "Can't open ${a.label}", Toast.LENGTH_SHORT).show()
        }
    }

    private fun defaultDock(): List<String> {
        val pm = packageManager
        val intents = listOf(
            Intent(Intent.ACTION_DIAL),
            Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:")),
            Intent(Intent.ACTION_VIEW, Uri.parse("https://example.com")),
            Intent(MediaStore.ACTION_IMAGE_CAPTURE)
        )
        return intents
            .mapNotNull { pm.resolveActivity(it, PackageManager.MATCH_DEFAULT_ONLY)?.activityInfo?.packageName }
            .filter { it != "android" }
            .distinct()
    }

    private fun dockPkgs(): List<String> =
        Cleaner.prefs(this).getString("dock", null)?.split(",")?.filter { it.isNotEmpty() } ?: defaultDock()

    private fun renderDock() {
        dock.removeAllViews()
        val d = resources.displayMetrics.density
        // The Control Panel is permanently first in the dock; up to four more apps can follow it.
        val control = apps.firstOrNull { isControl(it) }
        val items = ArrayList<AppItem>()
        if (control != null) items.add(control)
        for (p in dockPkgs().filter { it != packageName }.take(4)) {
            apps.firstOrNull { it.pkg == p }?.let { items.add(it) }
        }
        for (a in items) {
            val iv = ImageView(this).apply {
                setImageDrawable(a.icon)
                contentDescription = a.label
                setOnClickListener { launch(a) }
                setOnLongClickListener { showMenu(a); true }
            }
            dock.addView(iv, LinearLayout.LayoutParams((52 * d).toInt(), (52 * d).toInt()).apply {
                setMargins((6 * d).toInt(), 0, (6 * d).toInt(), 0)
            })
        }
    }

    private fun showMenu(a: AppItem) {
        if (isControl(a)) {
            AlertDialog.Builder(this).setTitle("WaterBoost Control Panel")
                .setItems(arrayOf("Open control panel", "Clean RAM now")) { _, which ->
                    if (which == 0) openSettings() else quickClean()
                }.show()
            return
        }
        val p = Cleaner.prefs(this)
        val prot = Cleaner.protectedApps(this)
        val dockList = dockPkgs()
        val inDock = a.pkg in dockList
        val items = arrayOf(
            "App info",
            "Uninstall",
            if (a.pkg in prot) "Allow WaterBoost to close it" else "Never close this app",
            if (inDock) "Remove from dock" else "Add to dock"
        )
        AlertDialog.Builder(this).setTitle(a.label).setItems(items) { _, which ->
            when (which) {
                0 -> try {
                    startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${a.pkg}")))
                } catch (e: Exception) { Toast.makeText(this, "Can't open App info", Toast.LENGTH_SHORT).show() }
                1 -> try {
                    startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:${a.pkg}")))
                } catch (e: Exception) { Toast.makeText(this, "Can't uninstall ${a.label}", Toast.LENGTH_SHORT).show() }
                2 -> {
                    val set = HashSet(prot)
                    if (!set.add(a.pkg)) set.remove(a.pkg)
                    p.edit().putStringSet("prot", set).apply()
                }
                3 -> {
                    val l = dockList.toMutableList()
                    if (inDock) l.remove(a.pkg) else { if (l.size >= 4) l.removeAt(0); l.add(a.pkg) }
                    p.edit().putString("dock", l.joinToString(",")).apply()
                    renderDock()
                }
            }
        }.show()
    }

    // ---------------------------------------------------------------- drawer & actions

    // "Open" is tracked apart from visibility: the drawer stays visible while it slides away, and tapping ALL_APPS
    // during that slide used to leave it hidden when the animation ended.
    private var drawerOpen = false

    private fun openDrawer() {
        if (drawerOpen) return
        drawerOpen = true
        drawer.animate().cancel()   // a cancelled slide-away does not run its end action
        search.setText("")
        if (drawer.visibility != View.VISIBLE) {
            drawer.visibility = View.VISIBLE
            drawer.translationY = root.height.toFloat()
        }
        drawer.animate().translationY(0f).setDuration(220).start()
    }

    private fun closeDrawer() {
        if (!drawerOpen) return
        drawerOpen = false
        (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager)
            .hideSoftInputFromWindow(search.windowToken, 0)
        drawer.animate().translationY(drawer.height.toFloat()).setDuration(180)
            .withEndAction {
                drawer.visibility = View.GONE
                renderer.resetStats()   // the water was paused behind the drawer: that gap is not a slow frame
            }.start()
    }

    private fun openSettings() {
        startActivity(Intent(this, MainActivity::class.java))
    }

    private fun quickClean() {
        Toast.makeText(this, "Cleaning...", Toast.LENGTH_SHORT).show()
        Cleaner.clean(this) { freed ->
            val msg = Cleaner.special(freed) ?: if (freed > 0) "Freed $freed MB" else "Nothing more to free"
            Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        // A launcher never exits; back just closes the drawer.
        if (drawerOpen) closeDrawer()
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        closeDrawer()   // pressing Home again returns to the main page
    }

    // ---------------------------------------------------------------- lifecycle & sensor

    override fun onStart() {
        super.onStart()
        registerReceiver(pkgReceiver, IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED)
            addAction(Intent.ACTION_PACKAGE_REMOVED)
            addAction(Intent.ACTION_PACKAGE_REPLACED)
            addDataScheme("package")
        })
        loadApps()   // catches anything installed or removed while we were stopped
    }

    override fun onStop() {
        runCatching { unregisterReceiver(pkgReceiver) }
        super.onStop()
    }

    override fun onResume() {
        super.onResume()
        resumed = true
        gl?.onResume()
        renderer.resetStats()   // a pause is not a slow frame
        h.post(tick)
        h.post(frame)
        sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)?.let {
            sm.registerListener(this, it, SensorManager.SENSOR_DELAY_UI)
        }
        if (Cleaner.prefs(this).getBoolean("auto", false)) CleanerService.start(this)
        h.postDelayed(deepRun, 2500)   // auto deep clean, only if you're still on the home screen
    }

    override fun onPause() {
        resumed = false
        h.removeCallbacks(tick)
        h.removeCallbacks(frame)
        h.removeCallbacks(deepRun)
        sm.unregisterListener(this)
        gl?.onPause()
        super.onPause()
    }

    override fun onSensorChanged(e: SensorEvent) {
        ax += (e.values[0] - ax) * 0.12f
        ay += (e.values[1] - ay) * 0.12f
        val m = hypot(ax, ay)
        if (m > 3f) { renderer.upX = ax / m; renderer.upY = ay / m }   // ignore when the phone lies flat
    }

    override fun onAccuracyChanged(s: Sensor?, accuracy: Int) {}
}
