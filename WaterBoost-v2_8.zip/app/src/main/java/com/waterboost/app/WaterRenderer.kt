package com.waterboost.app

import android.opengl.GLES20
import android.opengl.GLSurfaceView
import java.nio.ByteBuffer
import java.nio.ByteOrder
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10
import kotlin.math.sqrt

/**
 * Cyberpunk backdrop drawn by one cheap fragment shader: dark night sky with stars, a striped neon sun, a lit city skyline
 * on the horizon and five layers of neon-edged waves below it. The horizon height is the RAM level, and the whole palette
 * changes with it: cyan + magenta while RAM is fine -> yellow when it gets low -> red alert when almost out (with a little
 * screen glitch). If the shader fails to compile on some GPU, [onFail] is called and the launcher switches to a 2D wave.
 */
class WaterRenderer(private val onFail: () -> Unit) : GLSurfaceView.Renderer {
    @Volatile var used = 0.5f      // RAM used, 0..1
    @Volatile var upX = 0f         // direction of "up" on screen from the accelerometer (water stays level)
    @Volatile var upY = 1f

    // Average time between frames, so the launcher can lower quality by itself if this GPU can't keep up.
    private var lastNs = 0L
    private var frames = 0
    private var avgMs = 0f
    val measuredMs: Float get() = if (frames >= 20) avgMs else 0f
    fun resetStats() { lastNs = 0L; frames = 0; avgMs = 0f }

    private var prog = 0
    private var aPos = 0
    private var uRes = 0; private var uTime = 0; private var uLevel = 0; private var uUp = 0
    private var uDeep = 0; private var uShallow = 0; private var uChop = 0
    private var uSkyTop = 0; private var uSkyLow = 0
    private var w = 1f
    private var h = 1f
    private var level = 0.5f
    private var sx = 0f
    private var sy = 1f
    private val t0 = System.nanoTime()
    private val deep = FloatArray(3)
    private val shallow = FloatArray(3)
    private val skyTop = FloatArray(3)
    private val skyLow = FloatArray(3)
    private val tmp = FloatArray(3)
    private val quad = ByteBuffer.allocateDirect(32).order(ByteOrder.nativeOrder()).asFloatBuffer().apply {
        put(floatArrayOf(-1f, -1f, 1f, -1f, -1f, 1f, 1f, 1f)); position(0)
    }

    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        prog = link(VERTEX, FRAGMENT)
        if (prog == 0) { onFail(); return }
        aPos = GLES20.glGetAttribLocation(prog, "aPos")
        uRes = GLES20.glGetUniformLocation(prog, "uRes")
        uTime = GLES20.glGetUniformLocation(prog, "uTime")
        uLevel = GLES20.glGetUniformLocation(prog, "uLevel")
        uUp = GLES20.glGetUniformLocation(prog, "uUp")
        uDeep = GLES20.glGetUniformLocation(prog, "uDeep")
        uShallow = GLES20.glGetUniformLocation(prog, "uShallow")
        uSkyTop = GLES20.glGetUniformLocation(prog, "uSkyTop")
        uSkyLow = GLES20.glGetUniformLocation(prog, "uSkyLow")
        uChop = GLES20.glGetUniformLocation(prog, "uChop")
    }

    override fun onSurfaceChanged(gl: GL10?, width: Int, height: Int) {
        GLES20.glViewport(0, 0, width, height)
        w = width.toFloat(); h = height.toFloat()
    }

    override fun onDrawFrame(gl: GL10?) {
        val now = System.nanoTime()
        if (lastNs != 0L) {
            val d = (now - lastNs) / 1_000_000f
            if (d < 500f) { frames++; avgMs = if (frames <= 1) d else avgMs * 0.9f + d * 0.1f }   // ignore pauses
        }
        lastNs = now
        if (prog == 0) {
            GLES20.glClearColor(0.03f, 0.03f, 0.06f, 1f)
            GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT)
            return
        }
        level += (used.coerceIn(0f, 1f) - level) * 0.05f
        sx += (upX - sx) * 0.15f
        sy += (upY - sy) * 0.15f
        val m = sqrt(sx * sx + sy * sy).let { if (it < 0.01f) 1f else it }

        // Cyan + magenta while there is plenty of RAM, yellow when it gets low, red alert when almost out.
        val t1 = clamp01((level - 0.65f) / 0.15f)
        val t2 = clamp01((level - 0.80f) / 0.12f)
        palette(CALM_D, WARN_D, ALERT_D, t1, t2, deep)
        palette(CALM_S, WARN_S, ALERT_S, t1, t2, shallow)
        palette(CALM_ST, WARN_ST, ALERT_ST, t1, t2, skyTop)
        palette(CALM_SL, WARN_SL, ALERT_SL, t1, t2, skyLow)

        GLES20.glUseProgram(prog)
        GLES20.glUniform2f(uRes, w, h)
        GLES20.glUniform1f(uTime, (((System.nanoTime() - t0) / 1_000_000_000.0) % 3600.0).toFloat())
        GLES20.glUniform1f(uLevel, level.coerceIn(0.12f, 0.97f))
        GLES20.glUniform2f(uUp, sx / m, sy / m)
        GLES20.glUniform3f(uDeep, deep[0], deep[1], deep[2])
        GLES20.glUniform3f(uShallow, shallow[0], shallow[1], shallow[2])
        GLES20.glUniform3f(uSkyTop, skyTop[0], skyTop[1], skyTop[2])
        GLES20.glUniform3f(uSkyLow, skyLow[0], skyLow[1], skyLow[2])
        GLES20.glUniform1f(uChop, 0.7f + 0.8f * level)   // livelier waves when RAM is tight
        GLES20.glEnableVertexAttribArray(aPos)
        GLES20.glVertexAttribPointer(aPos, 2, GLES20.GL_FLOAT, false, 0, quad)
        GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
    }

    private fun clamp01(x: Float) = if (x < 0f) 0f else if (x > 1f) 1f else x

    private fun mix3(a: FloatArray, b: FloatArray, t: Float, out: FloatArray) {
        for (i in 0..2) out[i] = a[i] + (b[i] - a[i]) * t
    }

    private fun palette(a: FloatArray, b: FloatArray, c: FloatArray, t1: Float, t2: Float, out: FloatArray) {
        mix3(a, b, t1, tmp); mix3(tmp, c, t2, out)
    }

    private fun compile(type: Int, src: String): Int {
        val s = GLES20.glCreateShader(type)
        GLES20.glShaderSource(s, src)
        GLES20.glCompileShader(s)
        val ok = IntArray(1)
        GLES20.glGetShaderiv(s, GLES20.GL_COMPILE_STATUS, ok, 0)
        if (ok[0] == 0) { GLES20.glDeleteShader(s); return 0 }
        return s
    }

    private fun link(vs: String, fs: String): Int {
        val v = compile(GLES20.GL_VERTEX_SHADER, vs)
        val f = compile(GLES20.GL_FRAGMENT_SHADER, fs)
        if (v == 0 || f == 0) {   // one may have compiled: don't leak it
            if (v != 0) GLES20.glDeleteShader(v)
            if (f != 0) GLES20.glDeleteShader(f)
            return 0
        }
        val p = GLES20.glCreateProgram()
        GLES20.glAttachShader(p, v)
        GLES20.glAttachShader(p, f)
        GLES20.glLinkProgram(p)
        GLES20.glDeleteShader(v)   // flagged for deletion: freed together with the program
        GLES20.glDeleteShader(f)
        val ok = IntArray(1)
        GLES20.glGetProgramiv(p, GLES20.GL_LINK_STATUS, ok, 0)
        if (ok[0] == 0) { GLES20.glDeleteProgram(p); return 0 }
        return p
    }

    companion object {
        // D = dark liquid fill, S = neon A (lines, windows), ST = sky top, SL = horizon glow / neon B
        private val CALM_D = floatArrayOf(0.015f, 0.030f, 0.100f)
        private val CALM_S = floatArrayOf(0.00f, 0.94f, 1.00f)
        private val CALM_ST = floatArrayOf(0.020f, 0.015f, 0.090f)
        private val CALM_SL = floatArrayOf(1.00f, 0.10f, 0.62f)

        private val WARN_D = floatArrayOf(0.070f, 0.045f, 0.010f)
        private val WARN_S = floatArrayOf(0.99f, 0.93f, 0.04f)
        private val WARN_ST = floatArrayOf(0.080f, 0.040f, 0.020f)
        private val WARN_SL = floatArrayOf(1.00f, 0.45f, 0.05f)

        private val ALERT_D = floatArrayOf(0.090f, 0.010f, 0.030f)
        private val ALERT_S = floatArrayOf(1.00f, 0.18f, 0.30f)
        private val ALERT_ST = floatArrayOf(0.120f, 0.010f, 0.060f)
        private val ALERT_SL = floatArrayOf(1.00f, 0.05f, 0.25f)

        private const val VERTEX = "attribute vec2 aPos;\nvoid main() { gl_Position = vec4(aPos, 0.0, 1.0); }\n"

        private val FRAGMENT = """
#ifdef GL_FRAGMENT_PRECISION_HIGH
precision highp float;
#else
precision mediump float;
#endif
uniform vec2 uRes;
uniform float uTime;
uniform float uLevel;
uniform vec2 uUp;
uniform vec3 uDeep;
uniform vec3 uShallow;
uniform vec3 uSkyTop;
uniform vec3 uSkyLow;
uniform float uChop;

float hash(float n) { return fract(sin(n * 127.1) * 43758.5453); }

void main() {
    float aspect = uRes.x / uRes.y;
    vec2 c = (gl_FragCoord.xy / uRes - 0.5) * vec2(aspect, 1.0);
    // Rotate the view so the horizon stays level when the phone is tilted.
    float x = c.x * uUp.y - c.y * uUp.x;
    float y = c.x * uUp.x + c.y * uUp.y;
    float hz = uLevel - 0.5;
    float t = uTime;
    float aa = 1.2 / uRes.y;

    // Glitch: when memory is tight, some rows jump sideways for a moment.
    float gl = smoothstep(1.34, 1.48, uChop);
    float gt = floor(t * 7.0);
    float gb = floor(y * 36.0);
    x += step(0.93, hash(gb * 1.7 + gt * 3.1)) * (hash(gt + gb) - 0.5) * 0.05 * gl;

    // ---- night sky: dark gradient, glow at the horizon, a few twinkling stars
    float up = clamp((y - hz) * 1.6, 0.0, 1.0);
    vec3 col = mix(uSkyLow * 0.50, uSkyTop, smoothstep(0.0, 1.0, up));
    col += uSkyLow * exp(-max(y - hz, 0.0) * 9.0) * 0.45;
    float st = step(0.9965, hash(floor(x * 170.0) + 91.0 * floor(y * 170.0)));
    col += vec3(0.8, 0.95, 1.0) * st * (0.5 + 0.5 * sin(t * 2.0 + x * 400.0)) * step(hz + 0.12, y);

    // ---- striped neon sun
    vec2 sp = vec2(0.09, hz + 0.25);
    float sr = 0.115;
    float sd = length(vec2(x, y) - sp);
    float k = clamp((sp.y - y) / sr, 0.0, 1.0);
    float slit = step(k * 0.72, fract(y * 26.0 - t * 0.05));
    float disc = (1.0 - smoothstep(sr - aa, sr + aa, sd)) * slit;
    vec3 sunCol = mix(uSkyLow * 1.1 + 0.08, vec3(1.0, 0.93, 0.45), clamp((y - (sp.y - sr)) / (sr * 2.0), 0.0, 1.0));
    col += uSkyLow * exp(-sd * 7.0) * 0.28;
    col = mix(col, sunCol, disc);

    // ---- city skyline on the horizon with lit windows
    float bw = 0.030;
    float bx = (x + 1.0) / bw;
    float bid = floor(bx);
    float bh = 0.028 + 0.085 * hash(bid) + step(0.84, hash(bid + 7.0)) * 0.075;
    float inb = step(hz, y) * step(y, hz + bh);
    float wy = (y - hz) / 0.0125;
    float wx = fract(bx);
    float winCell = hash(bid * 13.0 + floor(wy));
    float lit = step(0.70, winCell) * step(0.22, wx) * step(wx, 0.72) * step(fract(wy), 0.55);
    vec3 winCol = mix(uShallow, uSkyLow, step(0.5, hash(bid * 3.0 + floor(wy) * 0.37)));
    vec3 bCol = uSkyTop * 0.5 + uSkyLow * 0.04;
    bCol += uSkyLow * 0.35 * exp(-(y - hz) * 22.0);        // glow at the foot of the buildings
    bCol += winCol * lit * 0.85;
    col = mix(col, bCol, inb);

    // ---- neon sea: five dark layers, each with a glowing crest line, painted far -> near
    float gap = clamp(uLevel * 0.16, 0.025, 0.09);
    for (int i = 0; i < 5; i++) {
        float fk = float(i);
        float dir = (mod(fk, 2.0) < 1.0) ? 1.0 : -1.0;
        float amp = (0.007 + 0.005 * fk) * uChop;
        float f = 26.0 - fk * 3.0;
        float sp2 = 0.6 + 0.22 * fk;
        float edge = hz - 0.012 - fk * gap
            + amp * sin(x * f + t * sp2 * dir + fk * 2.0)
            + amp * 0.5 * sin(x * f * 2.3 - t * sp2 * 0.7 + fk * 1.7);
        float m = 1.0 - smoothstep(edge - aa, edge + aa, y);
        vec3 lc = mix(uShallow, uSkyLow, fk / 4.0);                // far lines cyan, near lines magenta
        vec3 fillc = mix(uDeep * 1.7, uDeep * 0.6, fk / 4.0);
        fillc += lc * 0.20 * exp(-(edge - y) * 20.0);              // each layer glows just under its crest
        col = mix(col, fillc, m);
        float dd = abs(y - edge);
        float core = 1.0 - smoothstep(0.0, aa * 2.4, dd);
        float glow = exp(-dd * 90.0);
        col += lc * (core * 1.15 + glow * 0.30);
        float g = step(0.987, sin(x * (41.0 + fk * 7.0) + t * (1.1 + fk * 0.2)) * sin(y * 90.0 + fk * 3.0 - t * 0.4));
        col += lc * g * m * step(y, edge - 0.02) * step(1.5, fk) * 0.8;   // little data sparks in the near layers
    }
    gl_FragColor = vec4(col, 1.0);
}
""".trimIndent()
    }
}
