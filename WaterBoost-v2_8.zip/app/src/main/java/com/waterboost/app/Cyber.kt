package com.waterboost.app

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Bitmap
import android.graphics.BitmapShader
import android.graphics.Canvas
import android.graphics.ColorFilter
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.StateListDrawable
import android.view.View
import android.widget.Button
import android.widget.SeekBar
import android.widget.Switch

/** The cyberpunk look shared by the launcher and the Control Panel: neon on near-black, cut corners, mono type. */
object Cyber {
    val BG = 0xFF07080F.toInt()
    val PANEL = 0xE80A0E1A.toInt()
    val FIELD = 0xFF0C1222.toInt()
    val CYAN = 0xFF00F0FF.toInt()
    val MAGENTA = 0xFFFF2E97.toInt()
    val YELLOW = 0xFFFCEE0A.toInt()
    val RED = 0xFFFF3355.toInt()
    val GREEN = 0xFF39FF88.toInt()
    val TEXT = 0xFFE6FBFF.toInt()
    val DIM = 0xFF7F8BB0.toInt()

    val MONO: Typeface = Typeface.create("monospace", Typeface.BOLD)
    val CONDENSED: Typeface = Typeface.create("sans-serif-condensed", Typeface.BOLD)

    fun alpha(c: Int, a: Int): Int = (c and 0x00FFFFFF) or (a shl 24)

    fun mix(a: Int, b: Int, t: Float): Int {
        val k = t.coerceIn(0f, 1f)
        fun ch(s: Int): Int {
            val x = (a shr s) and 0xFF
            val y = (b shr s) and 0xFF
            return (x + (y - x) * k).toInt()
        }
        return (ch(24) shl 24) or (ch(16) shl 16) or (ch(8) shl 8) or ch(0)
    }

    /** Cyan while RAM is fine, yellow when it gets low, red when nearly out (same steps as the background). */
    fun alertColor(used: Float): Int {
        val a = mix(CYAN, YELLOW, (used - 0.65f) / 0.15f)
        return mix(a, RED, (used - 0.80f) / 0.12f)
    }

    /** A panel with two cut (chamfered) corners and a thin neon outline. [d] is the screen density. */
    fun cut(fill: Int, stroke: Int, d: Float, strokeDp: Float = 1.5f, cutDp: Float = 10f): Drawable =
        CutDrawable(fill, stroke, strokeDp * d, cutDp * d)

    fun neonLine(c: Context): View = View(c).apply {
        background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(CYAN, MAGENTA))
    }

    fun styleButton(b: Button, accent: Int = CYAN) {
        val d = b.resources.displayMetrics.density
        b.background = StateListDrawable().apply {
            addState(intArrayOf(android.R.attr.state_pressed), cut(alpha(accent, 0x55), accent, d, 1.5f, 8f))
            addState(intArrayOf(), cut(FIELD, accent, d, 1.5f, 8f))
        }
        b.typeface = MONO
        b.setAllCaps(true)
        b.textSize = 12.5f
        b.letterSpacing = 0.08f
        b.setTextColor(ColorStateList(
            arrayOf(intArrayOf(-android.R.attr.state_enabled), intArrayOf()),
            intArrayOf(DIM, accent)
        ))
        b.stateListAnimator = null
        b.minHeight = 0
        b.minimumHeight = (46 * d).toInt()
    }

    fun styleSwitch(s: Switch) {
        s.typeface = Typeface.MONOSPACE
        s.setTextColor(TEXT)
        s.textSize = 13.5f
        val on = arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf())
        s.thumbTintList = ColorStateList(on, intArrayOf(CYAN, 0xFF5B6585.toInt()))
        s.trackTintList = ColorStateList(on, intArrayOf(alpha(CYAN, 0x66), 0xFF1A2038.toInt()))
    }

    fun styleSeek(s: SeekBar) {
        s.progressTintList = ColorStateList.valueOf(MAGENTA)
        s.thumbTintList = ColorStateList.valueOf(CYAN)
    }
}

/** Rectangle with the top-left and bottom-right corners cut off. */
class CutDrawable(fill: Int, stroke: Int, private val strokeW: Float, private val cut: Float) : Drawable() {
    private val path = Path()
    private val pf = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL; color = fill }
    private val ps = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; color = stroke; strokeWidth = strokeW; strokeJoin = Paint.Join.MITER
    }

    override fun onBoundsChange(b: Rect) {
        val i = strokeW / 2f
        val l = b.left + i
        val t = b.top + i
        val r = b.right - i
        val bt = b.bottom - i
        path.reset()
        path.moveTo(l + cut, t)
        path.lineTo(r, t)
        path.lineTo(r, bt - cut)
        path.lineTo(r - cut, bt)
        path.lineTo(l, bt)
        path.lineTo(l, t + cut)
        path.close()
    }

    override fun draw(canvas: Canvas) {
        canvas.drawPath(path, pf)
        if (strokeW > 0f) canvas.drawPath(path, ps)
    }

    override fun setAlpha(alpha: Int) {}
    override fun setColorFilter(colorFilter: ColorFilter?) {}
    @Suppress("OVERRIDE_DEPRECATION")
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
}

/** Segmented, slanted RAM bar: lit segments take the alert colour (cyan / yellow / red). */
class HudBar(c: Context) : View(c) {
    var value = 0f
        set(v) {
            val n = v.coerceIn(0f, 1f)
            if (n != field) { field = n; invalidate() }
        }
    private val d = resources.displayMetrics.density
    private val on = Paint(Paint.ANTI_ALIAS_FLAG)
    private val off = Paint(Paint.ANTI_ALIAS_FLAG)
    private val seg = Path()

    override fun onDraw(cv: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val n = 24
        val gap = 2.5f * d
        val sk = h * 0.45f
        val sw = (w - sk - gap * (n - 1)) / n
        val lit = Math.round(value * n)
        val col = Cyber.alertColor(value)
        on.color = col
        off.color = Cyber.alpha(col, 0x30)
        for (i in 0 until n) {
            val x = i * (sw + gap)
            seg.reset()
            seg.moveTo(x + sk, 0f)
            seg.lineTo(x + sk + sw, 0f)
            seg.lineTo(x + sw, h)
            seg.lineTo(x, h)
            seg.close()
            cv.drawPath(seg, if (i < lit) on else off)
        }
    }
}

/** Faint CRT scanlines over the whole screen. Static, never intercepts touches. */
class ScanlineView(c: Context) : View(c) {
    private val p = Paint()

    init {
        val d = resources.displayMetrics.density
        val pitch = maxOf(4, (3 * d).toInt())
        val bmp = Bitmap.createBitmap(1, pitch, Bitmap.Config.ARGB_8888)
        for (y in 0 until maxOf(1, (d * 0.8f).toInt())) bmp.setPixel(0, y, 0x2E000000)
        p.shader = BitmapShader(bmp, Shader.TileMode.REPEAT, Shader.TileMode.REPEAT)
        isClickable = false
        isFocusable = false
    }

    override fun onDraw(cv: Canvas) {
        cv.drawRect(0f, 0f, width.toFloat(), height.toFloat(), p)
    }
}
