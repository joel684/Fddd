# WaterBoost

Tiny Android RAM monitor. A water-filled circle shows how much RAM is used; "Clean now" (or auto mode)
asks Android to stop background processes of your apps.

* **Clean now** - stops background processes of launchable user apps, reports MB actually freed.
* **Auto clean** - foreground service checks every 30 s; cleans when free RAM < limit (cooldown adapts).
* **Protected apps** - apps that are never touched (launcher, keyboard, SMS, dialer are always protected).
* **Shizuku (optional)** - measures each app's real memory, closes only the heaviest ones and stops once
  enough is freed. Also shows a "Top memory apps" list. Falls back to normal mode if Shizuku isn't running.
* **Launcher** - WaterBoost can be your home screen: Ghibli-style painted sea (horizon height = RAM used; sky, sun, clouds and waves shift blue ->
  sunset gold -> rose red as RAM runs low, livelier waves when memory is tight, stays level when you tilt the phone), clock,
  dock, searchable app drawer, long-press app menu. Falls back to a 2D wave if the GPU can't run the shader.
* **Deep clean (Shizuku)** - force-stops chosen apps (or all non-protected ones) and clears every app's cache
  (`pm trim-caches`). Auto mode runs when you reach the home screen and RAM is low. Never touches app data.
* **Realme / OPPO tuning** (tested target: Realme Narzo 50A Prime, 4 GB, Android 11, Realme UI) - default
  limit scales with RAM, Google/Realme system helpers are never closed, auto mode pauses with the screen
  off, "Keep running in background" opens Realme UI's auto-start screen. Device code lives in Device.kt.
* Build: push to GitHub, run the "Build APK" workflow, download the debug APK artifact.

## 2.1 fixes (auto mode stopping + lag)
* Back-off no longer climbs to 15 min (max 3 min) and resets when the screen turns on.
* A stuck clean/shell call can no longer block cleaning forever (timeouts + busy watchdog).
* App list is cached, no more loading every app label on each clean.
* Kill batches capped to the 12 heaviest apps; auto deep clean throttled to once per 5 min.
* Service loop survives errors, restarts via an alarm if Realme UI kills it, survives swiping from recents.
* Launcher water renders at 1/3 resolution and ~22 fps.

## 2.2 Ghibli water
* New cheap toon shader: pastel sky, sun, drifting clouds, five flat wave layers with foam lines and sparkles.
* Whole scene palette follows RAM: calm blue -> golden sunset -> rose-red dusk.
* Rendering pauses while the app drawer covers the screen.

## 2.3 Built-in Control Panel
* The launcher now has its own Control Panel tile: always first in the app drawer and permanently first in the dock
  (a round water-drop badge). Tap it to open the settings/cleaner screen; long-press for "Open control panel" / "Clean RAM now".
* The separate WaterBoost entry no longer shows up as a normal app in the drawer. Dock holds the Control Panel plus up to 4 apps.

## 2.4 Shizuku connection card
* Control Panel has a "SHIZUKU CONNECTION" card: live status (connected / permission needed / not running / not installed),
  a hint for the next step, and one button that does it (get Shizuku, open it to start, ask permission, or connect and test).
* Updates instantly when Shizuku starts or stops.

## 2.5 Tuned for realme narzo 50A Prime (Unisoc T612, Mali-G57, 4 GB, 1080x2408)
* Water renders at ~360 px wide with no depth buffer, and steps down by itself (30 -> 24 -> 20 fps, lower resolution)
  if the measured frame rate falls behind. Battery saver caps it at 20 fps and halves the auto-clean check rate.
* Cleaning and app loading run at background thread priority so they never fight the UI on the A55 cores.
* Default RAM trigger is 22% of total (~800 MB). Shizuku itself is never closed.
* Control Panel shows chip and RAM, and has a "Battery: allow unrestricted" button (Realme UI kills optimised apps).
* Android 12+ refusing a background foreground-start no longer crashes the service.
* Build now makes an optimised, shrunk release APK next to the debug one. If the release APK ever misbehaves,
  install the debug APK from the same artifact.

## 2.6 Cyberpunk
* New look for the launcher and the Control Panel: neon cyan / magenta / yellow on near-black, cut corners, monospace type, faint scanlines.
* Home screen is now a HUD: glitch-style clock, date line, and a RAM panel with a segmented bar (tap it to clean, long-press for the Control Panel).
* Background is a neon city and sea. The horizon height is still your RAM level. Palette: cyan + magenta (fine) -> yellow (low) -> red alert with a little screen glitch (almost out).
* Dock, "ALL_APPS" button, app drawer search and the Control Panel tile were restyled to match. Rendering cost is about the same as 2.5.

## 2.7 Force-stop helper (no Shizuku, no root)
* Android only lets the shell (Shizuku / root) force-stop other apps silently. Without them there are two options, and WaterBoost now uses both:
  * **Quiet clean** (always on, nothing on screen): stops background processes of your apps, skips apps that are already stopped, and
    kills twice about a second apart so sticky services restart later.
  * **Force-stop helper** (new, optional): an Accessibility service that opens each app's App info page in Settings and taps
    Force stop and OK, the way you would. Turn it on in Control Panel > FORCE-STOP HELPER, then switch on
    "WaterBoost force-stop helper" in Accessibility settings (Android 13+: first App info > three dots > Allow restricted settings).
* It is used by **Deep clean now** and by **auto deep clean when you reach home** whenever Shizuku is not ready, with the same
  "Pick apps to force-stop" list / scope and the same Protected apps list.
* It cannot run invisibly: the screen must be on and unlocked, and a cover screen (tap it to cancel) hides Settings for about 2-3 s per app.
  Max 8 apps per sweep; apps already in the stopped state are skipped, so later sweeps move on to the next ones; apps whose Force stop button
  is greyed out are remembered and skipped. It will not start during a call or on the lock screen, auto mode also skips while music plays and waits
  at least 10 min between sweeps, and a sweep aborts after two failures in a row. The Control Panel shows the result of the last sweep.
* It acts only while Settings is the top window and presses only Force stop, OK and Back. WaterBoost still has no internet permission.

## 2.7.2 Bug fixes (no new features, look unchanged)
* **Auto clean switch now really switches it off.** Before, the restart alarm stayed armed and could bring the service (and its
  notification) back a few minutes later with the switch showing off. Turning it off now cancels the alarm, and a stale alarm
  is ignored when auto mode is off.
* **Updates install over the old version.** Debug and release APKs are now signed with one fixed key (`app/waterboost.p12`).
  The automatic debug key was created fresh on every GitHub run, so each APK had a different signature and Android refused the
  update. **Uninstall WaterBoost once before installing 2.7.2**; every build after that updates in place.
  (The key and its password are public in this project. To use your own, replace the file and the `signingConfigs` block in `app/build.gradle.kts`.)
* **Launcher:** apps installed or removed while the home screen was in the background (Play Store, Settings) now show up when you
  come back. Tapping ALL_APPS while the drawer is still sliding away no longer leaves it hidden. App info / Uninstall can no longer
  crash the launcher. The `v2.x` label now follows the real version.
* **Water:** the glitch effect starts when RAM is nearly full (about 80% used); it used to begin around 56%, which is the
  normal level on a 4 GB phone. A short pause (or the drawer) no longer counts as slow frames, so the quality ladder isn't
  tripped by it. Shader objects are released after linking.
* **Cleaning:** two cleans can no longer overlap (deep clean gets a longer lock, and a run that timed out can't release a
  newer run's lock). If a clean is skipped because one is already running, you now get "Already cleaning" instead of
  "Nothing more to free" / "freed 0 MB", and it no longer starts the auto-mode cooldown.
* **Force-stop helper:** an app whose Force stop button was grey is tried again after 6 h (it used to be skipped until
  WaterBoost restarted), and an app that is simply not running is not blacklisted. The Control Panel says why a sweep did
  not start, and Settings' button labels are re-read for each sweep, so a language change is picked up.
* **Control Panel:** the app pickers open without freezing and only list apps WaterBoost can actually touch (system apps are
  never touched). The Shizuku test counts real processes instead of accepting an empty reply.

## 2.8 Final fixes (no new features, look unchanged)
* **Auto deep clean never cuts music or a call.** With the helper it already waited while music played; now it also waits
  during calls and voice chats, and the same check applies when Shizuku does the force-stop.
* **Your next alarm is safe.** The app that owns your next alarm joins the always-protected apps (launcher, keyboard, SMS,
  dialer), because force-stopping an app cancels its alarms. It is looked up at most once a minute.
* **Cancel means cancel.** If you tap the cover screen to stop a force-stop sweep, auto deep clean now waits an hour before
  trying again (it used to come back after 10 minutes).
* **Auto mode survives an update.** Installing a new WaterBoost stops the running service; it is now restarted by itself
  (also after a "fast boot") if Auto clean was on.
* **Shizuku:** a shell command that hangs can no longer leave its reader stuck. Shizuku restarts WaterBoost's helper
  process once because of this.
* **Control Panel:** the Auto clean switch follows the notification's "Turn off" button while the panel is open, the app
  lists can't crash if you rotate the phone while they load, and the dock icons have names for TalkBack.
* A clean with nothing to kill no longer waits for its second pass.
* Coming from 2.7.1 or older: uninstall WaterBoost once (the signing key changed in 2.7.2). From 2.7.2 on, updates install in place.
