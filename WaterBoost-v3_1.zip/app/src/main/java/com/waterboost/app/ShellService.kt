package com.waterboost.app

import android.content.Context
import kotlin.system.exitProcess

/** Runs in Shizuku's process with shell (adb) privileges - NOT in the app's own process. */
class ShellService : IShell.Stub {
    constructor() : super()
    constructor(@Suppress("UNUSED_PARAMETER") context: Context) : super()

    private val validPkg = Regex("[A-Za-z0-9._]+")

    override fun destroy() { exitProcess(0) }

    override fun processList(): String = run("ps -A -o RSS,NAME", 8_000)

    // "am kill" only kills processes the system considers safe to kill (never the app you're using).
    override fun killPackages(pkgs: Array<String>) = each("am kill", pkgs)

    // Hard stop: also cancels the app's alarms, jobs and notifications until it is opened again.
    override fun forceStop(pkgs: Array<String>) = each("am force-stop", pkgs)

    // Asks Android to free cached data of every app (same mechanism as Settings > Storage > Cached data).
    override fun trimCaches() { run("pm trim-caches 999G", 60_000) }

    // Fully precompiles one app's code. A sideloaded app is installed only "verified": its code is interpreted and then
    // JIT-compiled until Android's idle job gets to it, and every update resets that. On a budget phone that is jank.
    override fun compileApp(pkg: String): String =
        if (validPkg.matches(pkg)) run("cmd package compile -m speed -f $pkg", 180_000) else ""

    // One shell for the whole batch is much faster than one per package.
    private fun each(cmd: String, pkgs: Array<String>) {
        val ok = pkgs.filter { validPkg.matches(it) }
        if (ok.isNotEmpty()) run(ok.joinToString("; ") { "$cmd $it" }, 25_000)
    }

    // A command that hangs is killed after [timeoutMs], so one bad call can never freeze cleaning for good.
    private fun run(cmd: String, timeoutMs: Long): String = try {
        val proc = ProcessBuilder("sh", "-c", cmd).redirectErrorStream(true).start()
        val watchdog = Thread {
            try {
                Thread.sleep(timeoutMs)
                proc.destroy()
                // A child of sh can keep the output pipe open after sh itself is gone; closing our end wakes the reader below.
                try { proc.inputStream.close() } catch (e: Exception) { }
            } catch (e: InterruptedException) { }
        }
        watchdog.isDaemon = true
        watchdog.start()
        val out = proc.inputStream.bufferedReader().readText()
        proc.waitFor()
        watchdog.interrupt()
        out
    } catch (e: Exception) {
        ""
    }
}
