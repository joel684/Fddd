package com.waterboost.app

import android.accessibilityservice.AccessibilityService
import android.app.KeyguardManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.res.Resources
import android.graphics.PixelFormat
import android.media.AudioManager
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.LinearLayout
import android.widget.TextView
import java.util.concurrent.ConcurrentHashMap

/**
 * Force-stop without Shizuku or root.
 *
 * Android only lets the shell (Shizuku / root) force-stop other apps. What any app can do, once the user has switched on
 * its Accessibility service, is what the user would do by hand: open the app's "App info" page in Settings and tap
 * "Force stop", then "OK". That is all this service does, and only while a sweep started by WaterBoost is running.
 *
 *  - It acts only while Settings is the top window, and it presses nothing else.
 *  - A cover screen hides the Settings pages (and blocks stray taps on them). Tap it to cancel.
 *  - Button names are read from Settings' own resources, so it works in any language.
 *  - It needs the screen on and unlocked, so it cannot run invisibly in the background like Shizuku can.
 */
class ForceStopService : AccessibilityService() {

    companion object {
        @Volatile private var inst: ForceStopService? = null

        // Packages whose Force stop button stayed greyed out (protected apps), and when that was seen.
        private val skippedAt = ConcurrentHashMap<String, Long>()
        private const val SKIP_TTL = 6 * 60 * 60_000L   // tried again after 6 h: a grey button can also be a passing state

        /** True if this app's Force stop button was greyed out recently, so it isn't tried again for a while. */
        fun isSkipped(pkg: String): Boolean {
            val t = skippedAt[pkg] ?: return false
            if (SystemClock.elapsedRealtime() - t > SKIP_TTL) { skippedAt.remove(pkg); return false }
            return true
        }

        /** True while Android has this service connected and ready. */
        fun ready(): Boolean = inst != null

        /** True if the switch is on in Accessibility settings (Android can take a moment to connect it). */
        fun enabledInSettings(c: Context): Boolean = try {
            val me = ComponentName(c, ForceStopService::class.java)
            (Settings.Secure.getString(c.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: "")
                .split(':').any { ComponentName.unflattenFromString(it) == me }
        } catch (e: Exception) {
            false
        }

        /**
         * Blocking, so call it from a background thread. Force-stops each package through its App info page.
         * Returns how many were stopped, or -1 if the helper isn't connected.
         */
        fun sweep(pkgs: List<String>): Int = inst?.runSweep(pkgs) ?: -1
    }

    private enum class R(val why: String) {
        STOPPED(""), SKIPPED(""),
        NO_PAGE("could not open App info"),
        NO_BUTTON("Force stop button not found"),
        NO_CONFIRM("confirm dialog not found")
    }

    private val main = Handler(Looper.getMainLooper())
    @Volatile private var cancelled = false
    @Volatile private var userCancelled = false   // the cover screen was tapped (not a system interrupt)
    @Volatile private var sweeping = false
    private var overlay: View? = null
    private var overlayLine: TextView? = null

    // Filled in when the service connects, from Settings' own (translated) resources.
    private var settingsPkg = "com.android.settings"
    private var forceLabels: List<String> = listOf("Force stop")
    private var confirmLabels: List<String> = listOf("OK")
    private var dialogTitle = ""

    override fun onServiceConnected() {
        super.onServiceConnected()
        inst = this
        loadSettingsInfo()
        // This service never needs events from any app except Settings, so only ask for those.
        runCatching {
            val i = serviceInfo
            if (i != null) {
                i.packageNames = arrayOf(settingsPkg)
                serviceInfo = i
            }
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}   // everything is driven by runSweep()

    override fun onInterrupt() { cancelled = true }

    override fun onUnbind(intent: Intent?): Boolean {
        cancelled = true
        if (inst === this) inst = null
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        cancelled = true
        if (inst === this) inst = null
        super.onDestroy()
    }

    private fun loadSettingsInfo() {
        runCatching {
            val probe = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))
            val all = packageManager.queryIntentActivities(probe, 0)
            val sys = all.firstOrNull { (it.activityInfo.applicationInfo.flags and ApplicationInfo.FLAG_SYSTEM) != 0 }
            (sys ?: all.firstOrNull())?.activityInfo?.packageName?.let { settingsPkg = it }
        }
        val force = LinkedHashSet<String>()
        val ok = LinkedHashSet<String>()
        try {
            val r = packageManager.getResourcesForApplication(settingsPkg)
            fun str(name: String): String? = try {
                val id = r.getIdentifier(name, "string", settingsPkg)
                if (id != 0) r.getString(id) else null
            } catch (e: Exception) {
                null
            }
            str("force_stop")?.let { force.add(it) }
            str("dlg_ok")?.let { ok.add(it) }
            str("force_stop_dlg_title")?.let { dialogTitle = it }
        } catch (e: Exception) {
            // keep the English defaults below
        }
        runCatching { ok.add(Resources.getSystem().getString(android.R.string.ok)) }
        force.add("Force stop")
        ok.add("OK")
        forceLabels = force.toList()
        confirmLabels = ok.toList()
    }

    // ------------------------------------------------------------------ the sweep

    private fun runSweep(pkgs: List<String>): Int {
        if (pkgs.isEmpty() || sweeping) return 0
        if (!canStart()) {
            Cleaner.prefs(this).edit()
                .putString("sweepReport", "not started (screen off or locked, a call is active, or Settings is open)").apply()
            return 0
        }
        loadSettingsInfo()   // cheap, and picks up a language change made since the helper connected
        sweeping = true
        cancelled = false
        userCancelled = false
        var stopped = 0
        var skippedNow = 0
        var failed = 0
        var misses = 0
        var lastWhy = ""
        showOverlay()
        try {
            for ((i, pkg) in pkgs.withIndex()) {
                if (cancelled || !stillIdle()) break
                setOverlay("${i + 1} / ${pkgs.size}", labelOf(pkg))
                val r = stopOne(pkg)
                when (r) {
                    R.STOPPED -> { stopped++; misses = 0 }
                    R.SKIPPED -> { skippedNow++; misses = 0 }
                    else -> {
                        failed++; misses++; lastWhy = r.why
                        if (misses >= 2) break   // Settings doesn't look the way we expect: stop instead of tapping around
                    }
                }
            }
        } finally {
            leaveSettings()
            hideOverlay()
            sweeping = false
            val text = buildString {
                append("stopped $stopped, skipped $skippedNow")
                if (failed > 0) append(", failed $failed ($lastWhy)")
                if (cancelled) append(", cancelled")
            }
            val e = Cleaner.prefs(this).edit().putString("sweepReport", text)
            if (userCancelled) e.putLong("sweepCancelledAt", System.currentTimeMillis())   // auto deep clean then waits an hour
            e.apply()
        }
        return stopped
    }

    private fun stopOne(pkg: String): R {
        if (!leaveSettings()) return R.NO_PAGE
        try {
            startActivity(
                Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$pkg"))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_NO_ANIMATION)
            )
        } catch (e: Exception) {
            return R.NO_PAGE
        }
        var btn = waitFor(5_000) { findLabel(it, forceLabels) } ?: return R.NO_BUTTON   // Settings can be slow to start
        if (!btn.isEnabled) {
            // Settings enables the button a moment after the page opens; if it stays grey, the app can't be stopped.
            btn = waitFor(1_200) { r -> findLabel(r, forceLabels)?.takeIf { n -> n.isEnabled } }
                ?: run {
                    // Nothing to stop if the app isn't running; otherwise Android doesn't let this one be stopped.
                    if (!isStopped(pkg)) skippedAt[pkg] = SystemClock.elapsedRealtime()
                    return R.SKIPPED
                }
        }
        if (!click(btn)) return R.NO_BUTTON
        val ok = waitFor(2_500) { r -> if (dialogShowing(r)) findConfirm(r) else null } ?: return R.NO_CONFIRM
        if (!click(ok)) return R.NO_CONFIRM
        SystemClock.sleep(400)   // let Android finish stopping it
        return R.STOPPED
    }

    // ------------------------------------------------------------------ safety checks

    private fun idleAudio(): Boolean =
        (getSystemService(Context.AUDIO_SERVICE) as AudioManager).mode == AudioManager.MODE_NORMAL   // no call / ringing

    private fun stillIdle(): Boolean =
        (getSystemService(Context.POWER_SERVICE) as PowerManager).isInteractive && idleAudio()

    private fun canStart(): Boolean {
        val keys = getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
        return stillIdle() && !keys.isKeyguardLocked && !settingsOnTop()   // never start while you're in Settings yourself
    }

    private fun settingsOnTop(): Boolean = rootInActiveWindow?.packageName?.toString() == settingsPkg

    /** Presses Back until no Settings page is on top. It only ever presses Back while Settings is on top. */
    private fun leaveSettings(): Boolean {
        repeat(4) {
            if (!settingsOnTop()) {
                SystemClock.sleep(200)
                if (!settingsOnTop()) return true
            } else {
                performGlobalAction(GLOBAL_ACTION_BACK)
                SystemClock.sleep(450)
            }
        }
        return !settingsOnTop()
    }

    // ------------------------------------------------------------------ finding and tapping buttons

    private fun <T : Any> waitFor(timeoutMs: Long, probe: (AccessibilityNodeInfo) -> T?): T? {
        val end = SystemClock.elapsedRealtime() + timeoutMs
        while (!cancelled && SystemClock.elapsedRealtime() < end) {
            val root = rootInActiveWindow
            if (root != null && root.packageName?.toString() == settingsPkg) {
                val hit = probe(root)
                if (hit != null) return hit
            }
            SystemClock.sleep(150)
        }
        return null
    }

    private fun same(a: CharSequence?, b: String): Boolean = a?.toString()?.trim().equals(b, ignoreCase = true)

    private fun findLabel(root: AccessibilityNodeInfo, labels: List<String>): AccessibilityNodeInfo? {
        for (l in labels) {
            val want = l.trim()
            if (want.isEmpty()) continue
            val hit = root.findAccessibilityNodeInfosByText(want)
                ?.firstOrNull { same(it.text, want) || same(it.contentDescription, want) }
            if (hit != null) return hit
        }
        return null
    }

    private fun dialogShowing(root: AccessibilityNodeInfo): Boolean =
        !root.findAccessibilityNodeInfosByViewId("android:id/button1").isNullOrEmpty() ||
            (dialogTitle.isNotBlank() && !root.findAccessibilityNodeInfosByText(dialogTitle).isNullOrEmpty())

    private fun findConfirm(root: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        root.findAccessibilityNodeInfosByViewId("android:id/button1")?.firstOrNull { it.isEnabled }?.let { return it }
        return findLabel(root, confirmLabels + forceLabels)
    }

    /** Taps the node, or the nearest clickable parent (the label is often a child of the real button). */
    private fun click(n: AccessibilityNodeInfo): Boolean {
        var x: AccessibilityNodeInfo? = n
        var hops = 0
        while (x != null && hops < 4) {
            if (x.isClickable && x.isEnabled && x.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
            x = x.parent
            hops++
        }
        return false
    }

    private fun isStopped(pkg: String): Boolean = try {
        (packageManager.getApplicationInfo(pkg, 0).flags and ApplicationInfo.FLAG_STOPPED) != 0
    } catch (e: Exception) {
        false
    }

    private fun labelOf(pkg: String): String = try {
        packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
    } catch (e: Exception) {
        pkg
    }

    // ------------------------------------------------------------------ cover screen

    private fun showOverlay() {
        main.post {
            try {
                val ctx: Context = this@ForceStopService
                val d = resources.displayMetrics.density

                val box = LinearLayout(ctx)
                box.orientation = LinearLayout.VERTICAL
                box.gravity = Gravity.CENTER
                box.setBackgroundColor(Cyber.alpha(Cyber.BG, 0xF5))
                box.isClickable = true
                box.setOnClickListener { userCancelled = true; cancelled = true }   // any tap cancels, and no tap reaches the Settings page below

                val title = TextView(ctx)
                title.text = "// FORCE-STOP SWEEP"
                title.typeface = Cyber.MONO
                title.textSize = 15f
                title.letterSpacing = 0.14f
                title.gravity = Gravity.CENTER
                title.setTextColor(Cyber.CYAN)
                title.setShadowLayer(14f, 0f, 0f, Cyber.CYAN)
                box.addView(title)

                val line = TextView(ctx)
                line.typeface = Cyber.MONO
                line.textSize = 13f
                line.gravity = Gravity.CENTER
                line.setTextColor(Cyber.TEXT)
                line.setPadding(0, (18 * d).toInt(), 0, (18 * d).toInt())
                box.addView(line)

                val hint = TextView(ctx)
                hint.text = "TAP ANYWHERE TO CANCEL"
                hint.typeface = Cyber.MONO
                hint.textSize = 11f
                hint.letterSpacing = 0.12f
                hint.gravity = Gravity.CENTER
                hint.setTextColor(Cyber.DIM)
                box.addView(hint)

                val lp = WindowManager.LayoutParams(
                    WindowManager.LayoutParams.MATCH_PARENT,
                    WindowManager.LayoutParams.MATCH_PARENT,
                    WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                        WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                        WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                    PixelFormat.TRANSLUCENT
                )
                (getSystemService(Context.WINDOW_SERVICE) as WindowManager).addView(box, lp)
                overlay = box
                overlayLine = line
            } catch (e: Throwable) {
                overlay = null   // no cover screen is not fatal: the sweep still works, you just see Settings flash by
            }
        }
    }

    private fun setOverlay(count: String, name: String) {
        main.post { overlayLine?.text = "$count\n$name" }
    }

    private fun hideOverlay() {
        main.post {
            overlay?.let { v -> runCatching { (getSystemService(Context.WINDOW_SERVICE) as WindowManager).removeView(v) } }
            overlay = null
            overlayLine = null
        }
    }
}
