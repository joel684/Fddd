package com.waterboost.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/**
 * Restarts auto mode if the user had it switched on, after a reboot and also after WaterBoost itself was updated
 * (installing a new APK stops the running service, and nothing else would start it again until you open the app).
 */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val a = i.action
        val wanted = a == Intent.ACTION_BOOT_COMPLETED || a == Intent.ACTION_MY_PACKAGE_REPLACED ||
            a == "android.intent.action.QUICKBOOT_POWERON"   // sent by some phones after a "fast boot"
        if (wanted && Cleaner.prefs(c).getBoolean("auto", false)) CleanerService.start(c)
    }
}
