package com.waterboost.app

import android.app.ActivityManager
import android.app.AlarmManager
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.media.AudioManager
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.os.Process
import android.os.SystemClock
import android.provider.Settings
import android.provider.Telephony
import android.telecom.TelecomManager

object Cleaner {
    private const val MIN_COOLDOWN = 60_000L
    private const val MAX_COOLDOWN = 3 * 60_000L   // was 15 min: that is why auto mode seemed to "stop working"
    private const val BUSY_TIMEOUT = 60_000L       // a stuck clean can never block auto mode forever
    private const val CACHE_TTL = 60_000L          // app list is re-read at most once a minute
    private const val MAX_KILL_BATCH = 12          // each `am` call starts a process, so keep batches small
    private const val DEEP_THROTTLE = 5 * 60_000L
    private const val USEFUL_MB = 50L          // a clean that frees less than this is "not worth it"
    private const val MIN_HEAVY_MB = 40L       // Shizuku mode ignores apps using less than this
    private const val MIN_STOP_MB = 20L         // deep clean only force-stops apps that really are running
    private const val TRIM_EVERY = 30 * 60_000L // cache trimming is slow and apps rebuild caches, so rarely
    private const val HELPER_THROTTLE = 10 * 60_000L // the helper covers the screen for a few seconds, so not too often
    private const val MAX_SWEEP = 8                  // apps per helper sweep (about 2 s each)
    private const val RETRY_PASS_MS = 1_200L         // pause before the second quiet kill pass
    private const val DEEP_BUSY_TIMEOUT = 150_000L   // force-stop + cache trim, or a helper sweep, legitimately takes longer
    private const val CANCEL_BACKOFF = 60 * 60_000L  // after you tap the cover screen to cancel a sweep, auto deep clean waits this long

    /** Besides "MB freed", the [clean] / [deepClean] callbacks can get one of these. */
    const val SKIPPED = -1L   // another clean was still running, so nothing was done
    const val FAILED = -2L    // something went wrong

    @Volatile private var touchAt = 0L
    private const val TOUCH_QUIET_MS = 2_500L

    /**
     * The home screen calls this on every touch. Auto cleaning waits while you are swiping, because killing apps (and
     * Android restarting some of them) loads the whole phone, and that is exactly when a dropped frame shows.
     */
    fun noteTouch() { touchAt = SystemClock.elapsedRealtime() }

    /** True while something is playing or a call is active: the auto force-stop leaves everything alone then. */
    fun audioBusy(c: Context): Boolean = try {
        val am = c.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        am.isMusicActive || am.mode != AudioManager.MODE_NORMAL
    } catch (e: Exception) {
        false
    }

    /** A message for those two cases, or null for a normal result. */
    fun special(freed: Long): String? = when (freed) {
        SKIPPED -> "Already cleaning - try again in a moment"
        FAILED -> "Clean failed - try again"
        else -> null
    }

    @Volatile private var busy = false
    @Volatile private var busySince = 0L
    @Volatile private var busyLimit = BUSY_TIMEOUT
    private var runId = 0L      // who holds the lock: a run that was given up on must not release a newer run's lock

    /** Returns this run's id, or 0 if another clean is still running. */
    @Synchronized private fun begin(limit: Long = BUSY_TIMEOUT): Long {
        val now = SystemClock.elapsedRealtime()
        if (busy && now - busySince < busyLimit) return 0L
        busy = true; busySince = now; busyLimit = limit
        runId++
        return runId
    }

    @Synchronized private fun end(id: Long) { if (id == runId) busy = false }

    /**
     * Milliseconds since [then] (a wall-clock time kept in the settings). If the phone's clock was set back since, [then] is
     * in the future: that counts as "long ago", so a throttle can never get stuck until the clock catches up again.
     */
    private fun since(now: Long, then: Long): Long = if (then > now) Long.MAX_VALUE else now - then

    /** Called when the screen turns on: start from the short cooldown again. */
    fun resetCooldown(c: Context) { prefs(c).edit().putLong("cool", MIN_COOLDOWN).apply() }

    class App(val pkg: String, val label: String, val isSystem: Boolean)

    fun prefs(c: Context): SharedPreferences = c.getSharedPreferences("p", 0)

    fun info(c: Context): ActivityManager.MemoryInfo {
        val m = ActivityManager.MemoryInfo()
        (c.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager).getMemoryInfo(m)
        return m
    }

    // Default trigger = 22% of total RAM (about 800 MB on the 4 GB Narzo 50A Prime). Realme UI keeps free RAM
    // fairly low on purpose, so a higher default would make it clean (and apps restart) all the time.
    fun defaultLimitMb(c: Context): Int =
        ((info(c).totalMem shr 20) * 22 / 100).toInt().coerceIn(300, 1500)

    fun userLimit(c: Context): Int = prefs(c).getInt("limit", defaultLimitMb(c)).coerceIn(300, 1500)

    // Lower of the slider value and 45% of total RAM, so 2 GB phones work.
    fun limitMb(c: Context): Long {
        val total = info(c).totalMem shr 20
        return minOf(userLimit(c).toLong(), total * 45 / 100)
    }

    // Never closed: Google services that deliver notifications, plus Realme/OPPO/Unisoc system helpers.
    private val neverKill = setOf(
        "com.google.android.gms", "com.google.android.gsf", "com.android.vending",
        "moe.shizuku.privileged.api"   // stopping Shizuku would cut the connection WaterBoost depends on
    )
    private val vendorPrefixes = listOf(
        "com.coloros.", "com.oplus.", "com.oppo.", "com.realme.", "com.heytap.", "com.nearme.",
        "com.unisoc.", "com.sprd."
    )

    /** Every app that has a launcher icon (except WaterBoost itself), sorted by name. */
    fun launchableApps(c: Context): List<App> {
        val pm = c.packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return pm.queryIntentActivities(intent, 0)
            .map {
                val f = it.activityInfo.applicationInfo.flags
                val pureSystem = (f and ApplicationInfo.FLAG_SYSTEM) != 0 &&
                    (f and ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) == 0
                App(it.activityInfo.packageName, it.loadLabel(pm).toString(), pureSystem)
            }
            .filter { it.pkg != c.packageName }
            .distinctBy { it.pkg }
            .sortedBy { it.label.lowercase() }
    }

    fun protectedApps(c: Context): Set<String> = HashSet(prefs(c).getStringSet("prot", emptySet())!!)

    fun forcePicked(c: Context): Set<String> = HashSet(prefs(c).getStringSet("fsel", emptySet())!!)

    fun forceAll(c: Context): Boolean = prefs(c).getString("fsMode", "picked") == "all"

    private class Lite(val pkg: String, val isSystem: Boolean)
    @Volatile private var liteCache: List<Lite> = emptyList()
    @Volatile private var criticalCache: Set<String> = emptySet()
    @Volatile private var cacheAt = 0L

    // Apps that would break the phone experience if killed: launcher, keyboard, SMS, dialer, and whichever app
    // owns your next alarm (force-stopping an app cancels its alarms).
    private fun computeCritical(c: Context): Set<String> {
        val s = HashSet<String>()
        runCatching {
            (c.getSystemService(Context.ALARM_SERVICE) as AlarmManager).nextAlarmClock
                ?.showIntent?.creatorPackage?.let { s.add(it) }
        }
        runCatching {
            c.packageManager.resolveActivity(
                Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME),
                PackageManager.MATCH_DEFAULT_ONLY
            )?.activityInfo?.packageName?.let { s.add(it) }
        }
        runCatching {
            Settings.Secure.getString(c.contentResolver, Settings.Secure.DEFAULT_INPUT_METHOD)
                ?.substringBefore('/')?.let { s.add(it) }
        }
        runCatching { Telephony.Sms.getDefaultSmsPackage(c)?.let { s.add(it) } }
        runCatching {
            (c.getSystemService(Context.TELECOM_SERVICE) as? TelecomManager)
                ?.defaultDialerPackage?.let { s.add(it) }
        }
        return s
    }

    // Package names only (no labels/icons): the old code loaded every app's label on every clean, which
    // burned CPU on a budget phone. Cached for a minute.
    private fun refreshCache(c: Context) {
        val now = SystemClock.elapsedRealtime()
        if (liteCache.isNotEmpty() && now - cacheAt < CACHE_TTL) return
        val pm = c.packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        liteCache = pm.queryIntentActivities(intent, 0)
            .map {
                val f = it.activityInfo.applicationInfo.flags
                val pureSystem = (f and ApplicationInfo.FLAG_SYSTEM) != 0 &&
                    (f and ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) == 0
                Lite(it.activityInfo.packageName, pureSystem)
            }
            .filter { it.pkg != c.packageName }
            .distinctBy { it.pkg }
        criticalCache = computeCritical(c)
        cacheAt = now
    }

    private fun targets(c: Context): List<String> {
        refreshCache(c)
        val skip = criticalCache + protectedApps(c)
        return liteCache
            .filter { a ->
                !a.isSystem && a.pkg !in skip && a.pkg !in neverKill &&
                    vendorPrefixes.none { a.pkg.startsWith(it) }
            }
            .map { it.pkg }
    }

    /**
     * Shizuku mode: measure each app's real memory use, then close only the heaviest ones,
     * stopping once roughly [needMb] has been covered (null = close every heavy app).
     * Returns false if Shizuku isn't usable, so the caller falls back to the normal method.
     */
    private fun smartKill(c: Context, pkgs: List<String>, needMb: Long?): Boolean {
        val sh = ShizukuHelper.connect(c) ?: return false
        return try {
            val mem = ShizukuHelper.memoryByPackage(sh, pkgs.toSet())
            if (mem.isEmpty()) return false
            val chosen = ArrayList<String>()
            var sum = 0L
            for (e in mem.entries.filter { it.value >= MIN_HEAVY_MB }.sortedByDescending { it.value }) {
                if (needMb != null && sum >= needMb) break
                if (chosen.size >= MAX_KILL_BATCH) break
                chosen.add(e.key); sum += e.value
            }
            if (chosen.isNotEmpty()) sh.killPackages(chosen.toTypedArray())
            true
        } catch (e: Throwable) {
            false
        }
    }

    /** Shizuku only: the heaviest apps by real memory use (name, MB), or null if Shizuku isn't ready. */
    fun topApps(c: Context): List<Pair<String, Long>>? {
        val sh = ShizukuHelper.connect(c) ?: return null
        return try {
            val names = launchableApps(c).associate { it.pkg to it.label }
            ShizukuHelper.memoryByPackage(sh, names.keys)
                .entries.sortedByDescending { it.value }.take(15)
                .map { (names[it.key] ?: it.key) to it.value }
        } catch (e: Throwable) {
            null
        }
    }

    /**
     * Stops background processes of the chosen apps and clears our own cache. Never touches app data.
     * [done] is called on the main thread with the MB of RAM that actually became free (or [SKIPPED] / [FAILED]).
     * Returns false if nothing was started because another clean is still running.
     */
    fun clean(c: Context, needMb: Long? = null, done: ((Long) -> Unit)? = null): Boolean {
        val id = begin()
        if (id == 0L) { done?.let { Handler(Looper.getMainLooper()).post { it(SKIPPED) } }; return false }
        val ctx = c.applicationContext
        Thread {
            Process.setThreadPriority(Process.THREAD_PRIORITY_BACKGROUND)   // never compete with the UI on the T612
            try {
                val before = info(ctx).availMem
                val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
                val list = targets(ctx)
                val smart = prefs(ctx).getBoolean("shizuku", false) && smartKill(ctx, list, needMb)
                if (!smart) {
                    // An app in the "stopped" state has no process, so there is nothing to kill there.
                    val live = list.filter { !isStopped(ctx, it) }
                    live.forEach { am.killBackgroundProcesses(it) }
                    if (live.isNotEmpty()) {
                        // Second pass: sticky services restart about a second after they are killed. Killing them again
                        // makes Android wait longer before each further restart (1 s, 4 s, 16 s ...), so RAM stays free longer.
                        Thread.sleep(RETRY_PASS_MS)
                        live.forEach { am.killBackgroundProcesses(it) }
                    }
                }
                ctx.cacheDir.deleteRecursively()
                ctx.externalCacheDir?.deleteRecursively()

                Thread.sleep(1500)   // give the system a moment to reclaim the memory
                val freed = ((info(ctx).availMem - before) shr 20).coerceAtLeast(0)

                // Adaptive back-off: if cleaning achieves little (apps just restart), wait longer next time.
                val p = prefs(ctx)
                val cool = p.getLong("cool", MIN_COOLDOWN)
                val next = if (freed < USEFUL_MB) minOf(cool * 2, MAX_COOLDOWN) else MIN_COOLDOWN
                p.edit().putLong("freed", freed).putLong("cool", next)
                    .putString("mode", if (smart) "Shizuku" else "standard").apply()

                Handler(Looper.getMainLooper()).post { done?.invoke(freed) }
            } catch (e: Throwable) {
                done?.let { Handler(Looper.getMainLooper()).post { it(FAILED) } }
            } finally {
                end(id)
            }
        }.start()
        return true
    }

    // Apps eligible for force-stop: the user's own list, or every non-protected app if scope is "all".
    private fun forceTargets(c: Context): List<String> {
        val all = targets(c)
        if (forceAll(c)) return all
        val picked = forcePicked(c)
        return all.filter { it in picked }
    }

    private fun isStopped(c: Context, pkg: String): Boolean = try {
        (c.packageManager.getApplicationInfo(pkg, 0).flags and ApplicationInfo.FLAG_STOPPED) != 0
    } catch (e: Exception) {
        false
    }

    // What the helper may force-stop now: in scope, and not already in the stopped state (nothing runs there).
    // Each sweep marks its apps as stopped, so the next sweep moves on to the next ones.
    private fun helperTargets(c: Context): List<String> =
        forceTargets(c)
            .filter { !isStopped(c, it) && !ForceStopService.isSkipped(it) }
            .take(MAX_SWEEP)

    /**
     * Deep clean. With Shizuku: force-stops the chosen apps that are really running and, if enabled, clears the cache
     * of all apps. Without Shizuku: a quiet clean of everything, then - if the force-stop helper (accessibility) is
     * on - the chosen apps are force-stopped through Settings. [canRun] is checked right before anything is stopped,
     * so an app the user just opened is never hit. [done] gets the MB freed, on the main thread.
     */
    fun deepClean(c: Context, canRun: () -> Boolean = { true }, done: ((Long) -> Unit)? = null): Boolean {
        val id = begin(DEEP_BUSY_TIMEOUT)
        if (id == 0L) { done?.let { Handler(Looper.getMainLooper()).post { it(SKIPPED) } }; return false }
        val ctx = c.applicationContext
        Thread {
            Process.setThreadPriority(Process.THREAD_PRIORITY_BACKGROUND)   // never compete with the UI on the T612
            try {
                val p = prefs(ctx)
                val before = info(ctx).availMem
                var mode = "standard"
                val sh = ShizukuHelper.connect(ctx)
                if (sh != null && canRun()) {
                    try {
                        val running = ShizukuHelper.memoryByPackage(sh, forceTargets(ctx).toSet())
                        val stop = running.filter { it.value >= MIN_STOP_MB }.entries
                            .sortedByDescending { it.value }.take(MAX_KILL_BATCH)
                            .map { it.key }.toTypedArray()
                        if (stop.isNotEmpty() && canRun()) sh.forceStop(stop)
                        val now = System.currentTimeMillis()
                        if (p.getBoolean("trim", false) && since(now, p.getLong("lastTrim", 0)) > TRIM_EVERY) {
                            sh.trimCaches()
                            p.edit().putLong("lastTrim", now).apply()
                        }
                        mode = "deep clean"
                    } catch (e: Throwable) {
                        mode = "standard"
                    }
                }
                if (mode == "standard" && canRun()) {
                    // Quiet pass first (instant, nothing on screen) ...
                    val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
                    targets(ctx).forEach { am.killBackgroundProcesses(it) }
                    // ... then, without Shizuku, the helper force-stops the chosen apps through Settings.
                    if (sh == null && ForceStopService.ready() && canRun()) {
                        val live = helperTargets(ctx)
                        if (live.isNotEmpty() && ForceStopService.sweep(live) > 0) mode = "force-stop helper"
                    }
                }
                Thread.sleep(1500)
                val freed = ((info(ctx).availMem - before) shr 20).coerceAtLeast(0)
                p.edit().putLong("freed", freed).putString("mode", mode).apply()
                Handler(Looper.getMainLooper()).post { done?.invoke(freed) }
            } catch (e: Throwable) {
                done?.let { Handler(Looper.getMainLooper()).post { it(FAILED) } }
            } finally {
                end(id)
            }
        }.start()
        return true
    }

    /** Called by the launcher shortly after you reach the home screen. Acts only if RAM is actually low. */
    fun autoDeep(c: Context, canRun: () -> Boolean) {
        val p = prefs(c)
        if (!p.getBoolean("autoDeep", false)) return
        val now = System.currentTimeMillis()
        if ((info(c).availMem shr 20) >= limitMb(c)) return
        // Force-stopping would cut music or a call. (The Shizuku path has no cover screen, but it does exactly that.)
        if (audioBusy(c)) return
        val last = p.getLong("lastDeep", 0)
        val viaHelper = ShizukuHelper.state() != ShizukuHelper.State.READY && ForceStopService.ready()
        if (viaHelper) {
            // The helper covers the screen for a few seconds: not too often, and not again soon after you cancelled one.
            if (since(now, last) < HELPER_THROTTLE) return
            if (since(now, p.getLong("sweepCancelledAt", 0)) < CANCEL_BACKOFF) return
        } else if (since(now, last) < DEEP_THROTTLE) {
            return   // was 2 min: force-stop loops made the phone lag
        }
        if (deepClean(c, canRun)) p.edit().putLong("lastDeep", now).apply()
    }

    // Cleans only if free RAM is under the limit and the (adaptive) cooldown has passed.
    fun auto(c: Context) {
        // Nothing to gain while the screen is off, and Realme UI already trims apps then.
        if (!(c.getSystemService(Context.POWER_SERVICE) as PowerManager).isInteractive) return
        if (SystemClock.elapsedRealtime() - touchAt < TOUCH_QUIET_MS) return   // you are swiping: try again next tick
        val p = prefs(c)
        val now = System.currentTimeMillis()
        val free = info(c).availMem shr 20
        val cool = p.getLong("cool", MIN_COOLDOWN)
        if (free < limitMb(c) && since(now, p.getLong("last", 0)) > cool) {
            // only close about as much as we're short; the timestamp is only kept if a clean really started
            if (clean(c, needMb = (limitMb(c) - free) * 3 / 2)) p.edit().putLong("last", now).apply()
        }
    }
}
