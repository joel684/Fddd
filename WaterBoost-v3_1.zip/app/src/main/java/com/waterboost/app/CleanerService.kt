package com.waterboost.app

import android.app.*
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.graphics.drawable.Icon
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.Process
import android.os.SystemClock
import android.view.View
import android.widget.RemoteViews

class CleanerService : Service() {
    companion object {
        const val ACTION_STOP = "com.waterboost.app.STOP"

        /** True while the service is alive, so the home screen can skip a pointless start call each time you come back. */
        @Volatile var running = false

        private const val CHANNEL = "w2"            // new id: the old MIN-importance channel could be throttled by Realme UI
        private const val TICK_MS = 30_000L
        private const val WATCHDOG_MS = 5 * 60_000L

        fun start(c: Context) {
            val i = Intent(c, CleanerService::class.java)
            try {
                if (Build.VERSION.SDK_INT >= 26) c.startForegroundService(i) else c.startService(i)
            } catch (e: Exception) {
                // Background start not allowed right now; the watchdog alarm or next app open will retry.
            }
        }

        /** The restart alarm's PendingIntent. Built in one place so that cancelling it really cancels the armed one. */
        private fun watchdogPi(c: Context): PendingIntent {
            val i = Intent(c, CleanerService::class.java)
            val flags = PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            return if (Build.VERSION.SDK_INT >= 26) PendingIntent.getForegroundService(c, 2, i, flags)
            else PendingIntent.getService(c, 2, i, flags)
        }

        /** Switches auto mode off for good: the setting, the pending restart alarm and the service itself. */
        fun stop(c: Context) {
            val app = c.applicationContext
            Cleaner.prefs(app).edit().putBoolean("auto", false).apply()
            try { (app.getSystemService(Context.ALARM_SERVICE) as AlarmManager).cancel(watchdogPi(app)) } catch (e: Exception) { }
            app.stopService(Intent(app, CleanerService::class.java))
        }
    }

    private val h = Handler(Looper.getMainLooper())
    private var failed = false
    private var ticking = false
    private var worker: HandlerThread? = null      // builds the notification, so the main thread never pays for it
    private var wh: Handler? = null
    private var live = true
    private val notifyLock = Any()

    // The loop re-arms itself even if a check throws, so it can never die silently.
    private val tick = object : Runnable {
        override fun run() {
            // Auto mode was switched off while a restart alarm was still pending: don't keep running.
            if (!Cleaner.prefs(this@CleanerService).getBoolean("auto", false)) { shutDown(); return }
            try { Cleaner.auto(this@CleanerService) } catch (e: Throwable) { }
            refreshNotification()
            armWatchdog()
            // Battery saver on: check half as often.
            val saver = try { (getSystemService(Context.POWER_SERVICE) as PowerManager).isPowerSaveMode } catch (e: Exception) { false }
            h.postDelayed(this, if (saver) TICK_MS * 2 else TICK_MS)
        }
    }

    private val screenReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            // Screen on / unlocked: forget the back-off and check again soon.
            Cleaner.resetCooldown(c)
            refreshNotification()
            h.removeCallbacks(tick)
            h.postDelayed(tick, 4_000)
        }
    }

    private fun watchdogIntent(): PendingIntent = watchdogPi(this)

    private fun shutDown() {
        synchronized(notifyLock) { live = false }   // no refresh still queued may put the notification back
        cancelWatchdog()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    // If Realme UI kills our process, this alarm (kept by the system) starts the service again.
    private fun armWatchdog() {
        try {
            val am = getSystemService(Context.ALARM_SERVICE) as AlarmManager
            am.setAndAllowWhileIdle(
                AlarmManager.ELAPSED_REALTIME, SystemClock.elapsedRealtime() + WATCHDOG_MS, watchdogIntent()
            )
        } catch (e: Exception) { }
    }

    private fun cancelWatchdog() {
        try { (getSystemService(Context.ALARM_SERVICE) as AlarmManager).cancel(watchdogIntent()) } catch (e: Exception) { }
    }

    private lateinit var openPi: PendingIntent
    private lateinit var stopPi: PendingIntent

    private fun builder(): Notification.Builder =
        if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CHANNEL) else Notification.Builder(this)

    private fun stopAction(): Notification.Action =
        Notification.Action.Builder(Icon.createWithResource(this, R.drawable.ic_stat_neon), "Turn off", stopPi).build()

    /** The plain notification: the fallback if the neon one can't be built for any reason. */
    private fun plainNotification(): Notification = builder()
        .setContentTitle("WaterBoost auto mode on")
        .setContentText("Cleans when free RAM drops below your limit")
        .setSmallIcon(R.drawable.ic_stat_neon)
        .setColor(Cyber.CYAN)
        .setContentIntent(openPi)
        .setOngoing(true)
        .addAction(stopAction())
        .build()

    /**
     * The neon notification: a translucent panel with a glowing live RAM bar. Android draws the card and the round
     * icon itself, so this styles what is inside it, the icon and the accent colour.
     */
    private fun hudNotification(): Notification {
        val m = Cleaner.info(this)
        val used = (1f - m.availMem.toFloat() / m.totalMem).coerceIn(0f, 1f)
        val pct = Math.round(used * 100)
        val freeMb = m.availMem shr 20
        val limit = Cleaner.limitMb(this)
        val col = Cyber.alertColor(used)
        val bar = Cyber.hudBitmap(used)
        val p = Cleaner.prefs(this)
        val last = if (p.contains("freed")) "LAST CLEAN  +${p.getLong("freed", 0)} MB // ${p.getString("mode", "standard")}"
        else "LAST CLEAN  --"
        val shz = if (ShizukuHelper.state() == ShizukuHelper.State.READY) "ready" else "off"
        val tools = "SHIZUKU $shz  //  HELPER ${if (ForceStopService.ready()) "on" else "off"}"

        fun body(expanded: Boolean) = RemoteViews(packageName, R.layout.notif_hud).apply {
            setTextViewText(R.id.hud_pct, "$pct%")
            setTextColor(R.id.hud_pct, col)
            setImageViewBitmap(R.id.hud_bar, bar)
            setTextViewText(R.id.hud_info, "FREE $freeMb MB  //  CLEANS BELOW $limit MB")
            if (expanded) {
                setViewVisibility(R.id.hud_extra1, View.VISIBLE)
                setTextViewText(R.id.hud_extra1, last)
                setViewVisibility(R.id.hud_extra2, View.VISIBLE)
                setTextViewText(R.id.hud_extra2, tools)
            }
        }

        return builder()
            .setSmallIcon(R.drawable.ic_stat_neon)
            .setColor(Cyber.CYAN)
            .setContentTitle("WaterBoost auto mode on")
            .setContentText("$pct% RAM used, $freeMb MB free")
            .setStyle(Notification.DecoratedCustomViewStyle())
            .setCustomContentView(body(false))
            .setCustomBigContentView(body(true))
            .setContentIntent(openPi)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setShowWhen(false)
            .addAction(stopAction())
            .build()
    }

    private fun notification(): Notification =
        try { hudNotification() } catch (e: Throwable) { plainNotification() }

    private val refreshJob = Runnable { doRefresh(false) }
    private val forcedRefreshJob = Runnable { doRefresh(true) }

    /** Redraws the notification on a background thread: the bar bitmap and layouts must never cost the home screen a frame. */
    private fun refreshNotification(force: Boolean = false) {
        val hh = wh ?: return
        val job = if (force) forcedRefreshJob else refreshJob
        hh.removeCallbacks(job)
        hh.post(job)
    }

    private fun doRefresh(force: Boolean) {
        try {
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            if (!force) {
                // Only with the screen on, and only if it is still showing (Android 14+ lets you swipe it away).
                if (!(getSystemService(Context.POWER_SERVICE) as PowerManager).isInteractive) return
                if (nm.activeNotifications.none { it.id == 1 }) return
            }
            val n = notification()
            synchronized(notifyLock) { if (live) nm.notify(1, n) }
        } catch (e: Throwable) { }
    }

    override fun onCreate() {
        super.onCreate()
        running = true
        if (Build.VERSION.SDK_INT >= 26) {
            getSystemService(NotificationManager::class.java).createNotificationChannel(
                NotificationChannel(CHANNEL, "Auto cleaner", NotificationManager.IMPORTANCE_LOW)
            )
        }
        openPi = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        stopPi = PendingIntent.getService(
            this, 1, Intent(this, CleanerService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        // A foreground service must show a notification at once, so the cheap plain one goes up first; the neon one is
        // built on the worker thread right after.
        worker = HandlerThread("wb-notify", Process.THREAD_PRIORITY_BACKGROUND).also { it.start() }
        wh = Handler(worker!!.looper)
        val n = plainNotification()

        try {
            if (Build.VERSION.SDK_INT >= 34) {
                startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
            } else {
                startForeground(1, n)
            }
        } catch (e: Throwable) {
            // Android 12+ can refuse a foreground start from the background (e.g. from the restart alarm).
            failed = true
            stopSelf()
            return
        }

        registerReceiver(screenReceiver, IntentFilter().apply {
            addAction(Intent.ACTION_SCREEN_ON)
            addAction(Intent.ACTION_USER_PRESENT)
        })
        refreshNotification(force = true)
    }

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        if (failed) return START_NOT_STICKY
        if (i?.action == ACTION_STOP) {
            Cleaner.prefs(this).edit().putBoolean("auto", false).apply()
            shutDown()
            return START_NOT_STICKY
        }
        if (!Cleaner.prefs(this).getBoolean("auto", false)) {   // woken by an old restart alarm after auto mode was turned off
            shutDown()
            return START_NOT_STICKY
        }
        // The home screen starts us on every return: only the first start needs to kick off the loop.
        if (!ticking) { ticking = true; h.post(tick) }
        return START_STICKY
    }

    // Swiping WaterBoost out of recents must not end auto mode.
    override fun onTaskRemoved(rootIntent: Intent?) {
        if (Cleaner.prefs(this).getBoolean("auto", false)) {
            try {
                (getSystemService(Context.ALARM_SERVICE) as AlarmManager).set(
                    AlarmManager.ELAPSED_REALTIME, SystemClock.elapsedRealtime() + 3_000, watchdogIntent()
                )
            } catch (e: Exception) { }
        }
        super.onTaskRemoved(rootIntent)
    }

    override fun onDestroy() {
        synchronized(notifyLock) { live = false }
        running = false
        ticking = false
        h.removeCallbacks(tick)
        worker?.quitSafely()
        if (!failed) runCatching { unregisterReceiver(screenReceiver) }
        // A refresh that was already queued must not leave a stray notification behind once the service is gone.
        runCatching { (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).cancel(1) }
        super.onDestroy()
    }

    override fun onBind(i: Intent?): IBinder? = null
}
