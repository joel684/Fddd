package com.waterboost.app

/**
 * The arithmetic of the side panel (where the handle sits, how tall the panel may be, how the play time reads).
 * No Android classes, so it can be tested on any computer. All sizes are pixels.
 */
object PanelGeometry {
    /** Top edge for a view of [viewH] when the handle sits at [frac] (0 = top, 1 = bottom) of the room the screen leaves it. */
    fun yFor(frac: Float, screenH: Int, viewH: Int): Int {
        val room = (screenH - viewH).coerceAtLeast(0)
        return (frac.coerceIn(0f, 1f) * room).toInt()
    }

    /** The other way round: where a dragged handle ended up, as a fraction that survives a rotation. */
    fun fracFor(y: Int, screenH: Int, viewH: Int): Float {
        val room = screenH - viewH
        return if (room <= 0) 0f else (y.toFloat() / room).coerceIn(0f, 1f)
    }

    /** The panel is as tall as its content, but never taller than the screen minus [margin] (it scrolls then). */
    fun panelHeight(contentH: Int, screenH: Int, margin: Int): Int =
        contentH.coerceAtMost((screenH - margin).coerceAtLeast(0))

    /** 0:00, 12:34, 1:02:03 */
    fun playTime(ms: Long): String {
        val total = (ms / 1000).coerceAtLeast(0)
        val h = total / 3600
        val m = (total % 3600) / 60
        val s = total % 60
        return if (h > 0) "%d:%02d:%02d".format(h, m, s) else "%d:%02d".format(m, s)
    }
}
