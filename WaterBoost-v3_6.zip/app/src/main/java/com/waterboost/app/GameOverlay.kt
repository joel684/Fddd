package com.waterboost.app

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.PixelFormat
import android.graphics.Point
import android.graphics.drawable.GradientDrawable
import android.media.AudioManager
import android.os.BatteryManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast

/**
 * The game panel: a slim handle on the edge of the screen while you play, which fades to almost nothing after a few seconds.
 * Tap it and the panel slides out (RAM, heat, battery, play time, boost, notifications, volume); it closes again by itself
 * after a few seconds, or when you tap outside it. Drag the handle up or down to move it out of the way of the game's buttons.
 *
 * It is drawn over the game, which Android only allows with "Display over other apps". While it is only a handle there is no
 * timer running at all; while the panel is open it refreshes once a second. Everything runs on the main thread.
 */
class GameOverlay(context: Context, private val isPreview: Boolean = false) {
    companion object {
        private const val HANDLE_W = 22      // dp: the part of the game's screen the handle covers
        private const val HANDLE_H = 64
        private const val PANEL_W = 252
        private const val FADE_DELAY = 3_500L
        private const val FADE_ALPHA = 0.22f
        private const val IDLE_COLLAPSE = 8_000L
        private const val PREVIEW_MS = 20_000L
        private const val FLAGS = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN

        private var current: GameOverlay? = null   // the preview, if one is showing

        fun canDraw(c: Context): Boolean = try { Settings.canDrawOverlays(c) } catch (e: Exception) { false }

        /** Shows the panel for a few seconds without a game running, so it can be seen and placed. Main thread. */
        fun preview(c: Context) {
            endPreview()
            val o = GameOverlay(c, true)
            current = o
            o.start(true)
            Handler(Looper.getMainLooper()).postDelayed({ if (current === o) endPreview() }, PREVIEW_MS)
        }

        fun endPreview() {
            current?.stop()
            current = null
        }
    }

    private val ctx = context.applicationContext
    private val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val audio = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private val main = Handler(Looper.getMainLooper())
    private val d = ctx.resources.displayMetrics.density
    private fun px(v: Int) = (v * d).toInt()

    private var alive = false              // a game session (or the preview) is on
    private var force = false              // preview: show even if the option is off
    private var suppressed = false         // a WaterBoost screen is in front: do not draw over our own screens
    private var hiddenForSession = false   // "Hide" in the panel
    private var attached = false
    private var expanded = false
    private var onRight = true             // which screen edge (not called `right`: inside a View's apply{} that means View.getRight())
    private var boosting = false

    private var root: Root? = null
    private var lp: WindowManager.LayoutParams? = null
    private lateinit var handle: TextView
    private lateinit var panel: ScrollView
    private lateinit var ramLine: TextView
    private lateinit var ramBar: HudBar
    private lateinit var infoLine: TextView
    private lateinit var boostBtn: TextView
    private lateinit var dndBtn: TextView
    private lateinit var volBar: SeekBar

    private val statsRun = object : Runnable {
        override fun run() {
            if (!expanded || !attached) return
            refreshStats()
            main.postDelayed(this, 1000)
        }
    }
    private val fadeRun = Runnable { if (attached && !expanded) handle.animate().alpha(FADE_ALPHA).setDuration(500).start() }
    private val idleRun = Runnable { collapse() }

    // ------------------------------------------------------------------ lifecycle (called by GameService)

    fun start(forceShow: Boolean = false) {
        alive = true
        force = forceShow
        // Starting a game from the WaterBoost home screen: wait until the game is in front before drawing anything.
        suppressed = Games.uiVisible && !isPreview
        sync()
    }

    fun stop() {
        alive = false
        sync()
        main.removeCallbacksAndMessages(null)
    }

    /** True while a WaterBoost screen is in front. */
    fun setSuppressed(on: Boolean) {
        if (suppressed == on) return
        suppressed = on
        sync()
    }

    /** The phone was rotated: keep the handle at the same relative height; an open panel simply closes. */
    fun onConfigChanged() {
        if (!attached) return
        if (expanded) {
            collapse()
        } else {
            val l = lp ?: return
            l.y = PanelGeometry.yFor(savedFrac(), screen().y, px(HANDLE_H))
            try { wm.updateViewLayout(root, l) } catch (e: Exception) { }
        }
    }

    private fun sync() {
        val want = alive && !suppressed && !hiddenForSession && (force || Games.panelWanted(ctx)) && canDraw(ctx)
        if (want && !attached) attach() else if (!want && attached) detach()
    }

    // ------------------------------------------------------------------ window

    @Suppress("DEPRECATION")
    private fun screen(): Point {
        val p = Point()
        wm.defaultDisplay.getRealSize(p)
        return p
    }

    private fun savedFrac(): Float = Cleaner.prefs(ctx).getFloat(Games.K_PANEL_Y, 0.22f)

    private fun overlayType(): Int =
        if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE

    private fun attach() {
        try {
            onRight = !Cleaner.prefs(ctx).getBoolean(Games.K_PANEL_LEFT, false)
            build()   // fresh views each time: the side may have changed since last time
            val l = WindowManager.LayoutParams(px(HANDLE_W), px(HANDLE_H), overlayType(), FLAGS, PixelFormat.TRANSLUCENT)
            l.gravity = Gravity.TOP or (if (onRight) Gravity.END else Gravity.START)
            l.x = 0
            l.y = PanelGeometry.yFor(savedFrac(), screen().y, px(HANDLE_H))
            lp = l
            wm.addView(root, l)
            attached = true
            expanded = false
            scheduleFade()
        } catch (e: Exception) {
            // permission withdrawn, or the system refused: no panel, the game is unaffected
            attached = false
        }
    }

    private fun detach() {
        main.removeCallbacks(statsRun)
        main.removeCallbacks(fadeRun)
        main.removeCallbacks(idleRun)
        try { root?.let { wm.removeView(it) } } catch (e: Exception) { }
        attached = false
        expanded = false
    }

    // ------------------------------------------------------------------ handle <-> panel

    private fun scheduleFade() {
        main.removeCallbacks(fadeRun)
        if (Games.panelFade(ctx)) main.postDelayed(fadeRun, FADE_DELAY)
    }

    private fun bumpIdle() {
        main.removeCallbacks(idleRun)
        main.postDelayed(idleRun, IDLE_COLLAPSE)
    }

    private fun expand() {
        val r = root ?: return
        val l = lp ?: return
        if (expanded || !attached) return
        expanded = true
        main.removeCallbacks(fadeRun)
        refreshStats()
        refreshToggles()
        val s = screen()
        val w = px(PANEL_W)
        handle.visibility = View.GONE
        panel.visibility = View.VISIBLE
        panel.measure(
            View.MeasureSpec.makeMeasureSpec(w, View.MeasureSpec.EXACTLY),
            View.MeasureSpec.makeMeasureSpec(s.y - px(16), View.MeasureSpec.AT_MOST)
        )
        val h = PanelGeometry.panelHeight(panel.measuredHeight, s.y, px(16))
        l.width = w
        l.height = h
        l.y = PanelGeometry.yFor(savedFrac(), s.y, h)
        l.flags = FLAGS or WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH   // a tap outside closes it
        try {
            wm.updateViewLayout(r, l)
        } catch (e: Exception) {
            expanded = false
            return
        }
        panel.translationX = if (onRight) w.toFloat() else -w.toFloat()
        panel.animate().translationX(0f).setDuration(140).start()
        main.postDelayed(statsRun, 1000)
        bumpIdle()
    }

    private fun collapse() {
        val r = root ?: return
        val l = lp ?: return
        if (!expanded) return
        expanded = false
        main.removeCallbacks(statsRun)
        main.removeCallbacks(idleRun)
        panel.animate().cancel()
        panel.visibility = View.GONE
        handle.visibility = View.VISIBLE
        handle.alpha = 1f
        l.width = px(HANDLE_W)
        l.height = px(HANDLE_H)
        l.y = PanelGeometry.yFor(savedFrac(), screen().y, px(HANDLE_H))
        l.flags = FLAGS
        try { wm.updateViewLayout(r, l) } catch (e: Exception) { }
        scheduleFade()
    }

    // ------------------------------------------------------------------ views

    private inner class Root(c: Context) : FrameLayout(c) {
        override fun dispatchTouchEvent(e: MotionEvent): Boolean {
            if (e.actionMasked == MotionEvent.ACTION_OUTSIDE) {   // only sent while the panel is open
                if (expanded) collapse()
                return true
            }
            if (expanded) bumpIdle()
            return super.dispatchTouchEvent(e)
        }
    }

    private fun build() {
        val r = Root(ctx)
        val rad = px(10).toFloat()
        handle = TextView(ctx).apply {
            text = if (onRight) "\u2039" else "\u203A"
            gravity = Gravity.CENTER
            textSize = 22f
            setTextColor(Cyber.MAGENTA)
            background = GradientDrawable().apply {
                setColor(Cyber.PANEL)
                setStroke(px(1), Cyber.MAGENTA)
                // rounded on the side that faces the game, flat against the screen edge
                cornerRadii = if (onRight) floatArrayOf(rad, rad, 0f, 0f, 0f, 0f, rad, rad)
                else floatArrayOf(0f, 0f, rad, rad, rad, rad, 0f, 0f)
            }
            contentDescription = "Game panel"
        }
        handle.setOnTouchListener(handleTouch)
        r.addView(handle, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))
        panel = buildPanel()
        panel.visibility = View.GONE
        r.addView(panel, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))
        root = r
    }

    private fun chip(label: String, accent: Int, onClick: () -> Unit): TextView = TextView(ctx).apply {
        text = label
        typeface = Cyber.MONO; textSize = 12f; letterSpacing = 0.08f
        gravity = Gravity.CENTER
        setTextColor(accent)
        setPadding(px(8), px(11), px(8), px(11))
        background = Cyber.cut(Cyber.FIELD, accent, d, 1.2f, 6f)
        setOnClickListener { onClick() }
    }

    private fun buildPanel(): ScrollView {
        val lpMatch = { top: Int ->
            LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
                .apply { topMargin = px(top) }
        }
        val col = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(px(12), px(10), px(12), px(12))
            background = Cyber.cut(Cyber.PANEL, Cyber.MAGENTA, d, 1.5f, 10f)
        }
        val head = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        head.addView(TextView(ctx).apply {
            text = "GAME_ASSIST"; typeface = Cyber.MONO; textSize = 13f; letterSpacing = 0.15f; setTextColor(Cyber.MAGENTA)
        }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        head.addView(TextView(ctx).apply {
            text = "\u2715"; textSize = 16f; setTextColor(Cyber.DIM); gravity = Gravity.CENTER
            setPadding(px(12), px(4), px(4), px(4))
            contentDescription = "Close panel"
            setOnClickListener { collapse() }
        })
        col.addView(head)

        ramLine = TextView(ctx).apply { typeface = Cyber.MONO; textSize = 13f; setTextColor(Cyber.TEXT) }
        col.addView(ramLine, lpMatch(10))
        ramBar = HudBar(ctx)
        col.addView(ramBar, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, px(8)).apply { topMargin = px(6) })
        infoLine = TextView(ctx).apply { typeface = Cyber.MONO; textSize = 12f; setTextColor(Cyber.TEXT) }
        col.addView(infoLine, lpMatch(8))

        boostBtn = chip("BOOST RAM", Cyber.CYAN) { boost() }
        col.addView(boostBtn, lpMatch(12))
        dndBtn = chip("", Cyber.YELLOW) { toggleDnd() }
        col.addView(dndBtn, lpMatch(8))

        col.addView(TextView(ctx).apply {
            text = "MEDIA VOLUME"; typeface = Cyber.MONO; textSize = 11f; setTextColor(Cyber.DIM)
        }, lpMatch(12))
        volBar = SeekBar(ctx).apply {
            Cyber.styleSeek(this)
            max = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(b: SeekBar?, v: Int, user: Boolean) {
                    if (user) try { audio.setStreamVolume(AudioManager.STREAM_MUSIC, v, 0) } catch (e: Exception) { }
                }
                override fun onStartTrackingTouch(b: SeekBar?) {}
                override fun onStopTrackingTouch(b: SeekBar?) {}
            })
        }
        col.addView(volBar, lpMatch(2))

        val row = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
        row.addView(chip("HIDE", Cyber.DIM) { hideForSession() },
            LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply { marginEnd = px(4) })
        row.addView(chip("END MODE", Cyber.RED) {
            if (isPreview) Toast.makeText(ctx, "Game mode is not on: this is only a preview", Toast.LENGTH_SHORT).show()
            else GameService.stop(ctx)
        }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply { marginStart = px(4) })
        col.addView(row, lpMatch(12))

        return ScrollView(ctx).apply {
            isVerticalScrollBarEnabled = false
            addView(col)
        }
    }

    // ------------------------------------------------------------------ handle drag / tap

    private var downRawY = 0f
    private var downY = 0
    private var dragging = false

    private val handleTouch = View.OnTouchListener { _, e ->
        val l = lp
        val r = root
        if (l == null || r == null) return@OnTouchListener false
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downRawY = e.rawY; downY = l.y; dragging = false
                main.removeCallbacks(fadeRun)
                handle.animate().cancel()
                handle.alpha = 1f
                true
            }
            MotionEvent.ACTION_MOVE -> {
                val dy = e.rawY - downRawY
                if (!dragging && Math.abs(dy) > ViewConfiguration.get(ctx).scaledTouchSlop) dragging = true
                if (dragging) {
                    val room = (screen().y - px(HANDLE_H)).coerceAtLeast(0)
                    l.y = (downY + dy.toInt()).coerceIn(0, room)
                    try { wm.updateViewLayout(r, l) } catch (ex: Exception) { }
                }
                true
            }
            MotionEvent.ACTION_UP -> {
                if (dragging) {
                    val f = PanelGeometry.fracFor(l.y, screen().y, px(HANDLE_H))
                    Cleaner.prefs(ctx).edit().putFloat(Games.K_PANEL_Y, f).apply()
                    scheduleFade()
                } else {
                    handle.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
                    expand()
                }
                true
            }
            MotionEvent.ACTION_CANCEL -> { scheduleFade(); true }
            else -> false
        }
    }

    // ------------------------------------------------------------------ content

    private fun dndOn(): Boolean = Games.dndWanted(ctx) && Games.dndAccess(ctx)

    private fun refreshToggles() {
        if (isPreview) {
            dndBtn.text = "NOTIFICATIONS: NORMAL"
            dndBtn.setTextColor(Cyber.YELLOW)
        } else if (dndOn()) {
            dndBtn.text = "NOTIFICATIONS: SILENCED"
            dndBtn.setTextColor(Cyber.GREEN)
        } else {
            dndBtn.text = "NOTIFICATIONS: NORMAL"
            dndBtn.setTextColor(Cyber.YELLOW)
        }
        try { volBar.progress = audio.getStreamVolume(AudioManager.STREAM_MUSIC) } catch (e: Exception) { }
        if (!boosting) boostBtn.text = "BOOST RAM"
    }

    private fun refreshStats() {
        try {
            drawStats()
        } catch (e: Exception) {
            // a failed system call must never take the app down in the middle of a game: keep showing the last numbers
        }
    }

    private fun drawStats() {
        val m = Cleaner.info(ctx)
        val used = 1f - m.availMem.toFloat() / m.totalMem
        ramLine.stable = "RAM ${m.availMem shr 20} MB free (${100 - (used * 100).toInt()}%)"
        ramLine.setTextColor(Cyber.alertColor(used))
        ramBar.value = used

        val b = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val tenths = b?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, -1) ?: -1
        val level = b?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = b?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
        val pct = if (level >= 0 && scale > 0) level * 100 / scale else -1
        val started = GameService.startedAt
        val played = if (started > 0) System.currentTimeMillis() - started else 0L
        infoLine.stable = (if (tenths >= 0) "TEMP ${tenths / 10}\u00B0C" else "TEMP ?") +
            "  BAT " + (if (pct >= 0) "$pct%" else "?") +
            "  " + PanelGeometry.playTime(played)
        infoLine.setTextColor(
            when {
                tenths >= 450 -> Cyber.RED
                tenths >= 420 -> Cyber.YELLOW
                else -> Cyber.GREEN
            }
        )
    }

    private fun boost() {
        if (boosting) return
        boosting = true
        boostBtn.text = "BOOSTING..."
        // Mid-game: the quiet clean, plus clearing cached processes if you turned Extreme boost on. Never a force-stop here:
        // that could close a voice chat you are in.
        val extreme = Games.extremeWanted(ctx) && ShizukuHelper.state() == ShizukuHelper.State.READY
        Cleaner.boost(ctx, GameService.gamePkg, false, extreme, ready = {}) { freed ->
            boosting = false
            boostBtn.text = when {
                freed > 0 -> "BOOST RAM  (+$freed MB)"
                freed == 0L -> "RAM ALREADY CLEAR"
                else -> "BOOST RAM"
            }
            if (expanded) refreshStats()
        }
    }

    private fun toggleDnd() {
        if (isPreview) {
            Toast.makeText(ctx, "Works while a game is running", Toast.LENGTH_SHORT).show()
            return
        }
        if (!Games.dndAccess(ctx)) {
            Toast.makeText(ctx, "Allow Do Not Disturb access in Game Space first", Toast.LENGTH_LONG).show()
            return
        }
        val now = !Games.dndWanted(ctx)
        Cleaner.prefs(ctx).edit().putBoolean(Games.K_DND, now).apply()
        if (now) Games.applyDnd(ctx) else Games.restoreDnd(ctx)
        refreshToggles()
    }

    private fun hideForSession() {
        hiddenForSession = true
        sync()
        Toast.makeText(ctx, "Game panel hidden until your next game", Toast.LENGTH_SHORT).show()
    }
}
